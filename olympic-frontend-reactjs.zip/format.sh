./node_modules/.bin/prettier --single-quote --trailing-comma all --write "src/**/*.{js,jsx,css,json}"
./node_modules/.bin/prettier --single-quote --trailing-comma all --write "tools/**/*.{js,jsx,css,json}"
