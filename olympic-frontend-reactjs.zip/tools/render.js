/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import path from 'path';
import React from 'react';
import ReactDOM from 'react-dom/server';
import Html from '../src/components/Html';
import { writeFile, makeDir } from './lib/fs';

async function render() {
  const data = {
    title: 'Olympic',
    description: '',
    app: {},
    children: {},
    scripts: ['/assets/vendor.js', '/assets/client.js'],
  };

  const html = ReactDOM.renderToStaticMarkup(<Html {...data} />);
  const fileName = 'index.html';
  const dirName = path.join('build/public', '/');
  const dist = path.join(dirName, fileName);
  const text = `<!doctype html>${html}`;
  await makeDir(dirName);
  await writeFile(dist, text);
}

export default render;
