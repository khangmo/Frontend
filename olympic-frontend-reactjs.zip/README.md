### Getting Started

  * Follow the [getting started guide](./docs/getting-started.md) to download and run the project
    ([Node.js](https://nodejs.org/) >= 6.5)
  * Check the [code recipes](./docs/recipes) used in this boilerplate, or share yours
