export const ICON_TRANSIT = {
  DRIVING: 'http://img.allo.ua/media/catalog/category/Auto.png',
  WALKING: 'https://maps.gstatic.com/mapfiles/transit/iw2/6/walk.png',
  TRANSIT: 'https://maps.gstatic.com/mapfiles/transit/iw2/6/bus2.png',
  BICYCLING: 'http://www.iconsdb.com/icons/preview/gray/bicycle-2-xxl.png',
};

export const NEW_ICON_TRANSIT = {
  AIR_PLANE: 'https://maps.gstatic.com/mapfiles/transit/iw2/6/airplane.png',
  WALK: 'https://maps.gstatic.com/mapfiles/transit/iw2/6/walk.png',
  DRIVE: 'https://maps.gstatic.com/mapfiles/transit/iw2/6/drive.png',
  RAIL: 'https://maps.gstatic.com/mapfiles/transit/iw2/6/rail.png',
  BUS: 'https://maps.gstatic.com/mapfiles/transit/iw2/6/bus.png',
};
