import {
  GET_PLACE_START,
  GET_PLACE_SUCCESS,
  GET_PLACE_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../constants';

import { api } from '../../config';

import { get, getHeader } from '../../common/common';

import { GET_PLACE_DETAIL } from '../../common/path';

export default function httpGet(placeId, callback) {
  return async (dispatch, getState) => {
    dispatch({ type: GET_PLACE_START });
    dispatch({ type: SPINNER_SHOW });
    const header = getHeader(getState());
    get(`${api.apiServerUrl}${GET_PLACE_DETAIL}/${placeId}`, header)
      .then(places => {
        dispatch({ type: GET_PLACE_SUCCESS, payload: places });
        dispatch({ type: SPINNER_HIDE });
        callback(places);
      })
      .catch(error => {
        dispatch({ type: GET_PLACE_ERROR, payload: { error } });
        dispatch({ type: SPINNER_HIDE });
        callback(error);
      });
  };
}
