/**
 * Created by TungDK on 7/31/2017.
 */
import { ADD_PLACE_START, SPINNER_SHOW, SPINNER_HIDE } from '../../constants';
import { SAVE_PLACE } from '../../common/path';
import { post, getHeader } from '../../common/common';
import { api } from '../../config';

export default function createPlace(dataPost, dataStore, callback) {
  return async (dispatch, getState) => {
    dispatch({ type: SPINNER_SHOW });
    const header = getHeader(getState());
    post(`${api.apiServerUrl}${SAVE_PLACE}`, header, dataPost)
      .then(response => {
        if (response.placeId) {
          dataStore.placeId = response.placeId; //eslint-disable-line
          dispatch({ type: ADD_PLACE_START, destination: dataStore });
          dispatch({ type: SPINNER_HIDE });
          callback(response);
        }
      })
      .catch(error => {
        dispatch({ type: SPINNER_HIDE });
        callback(error);
      });
    return true;
  };
}
