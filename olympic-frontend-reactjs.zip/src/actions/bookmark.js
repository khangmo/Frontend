import {
  BOOKMARK_START,
  BOOKMARK_SUCCESS,
  BOOKMARK_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../constants';

import { GET_PLAN_DETAIL, GET_PLACE_DETAIL } from '../common/path';

import { api } from '../config';
import { post, del, getHeader } from '../common/common';

export default function bookmarkPost(itemId, action, item, callback) {
  return async (dispatch, getState) => {
    dispatch({ type: BOOKMARK_START });
    dispatch({ type: SPINNER_SHOW });
    const header = getHeader(getState());
    let url = GET_PLAN_DETAIL;
    if (item === 'places') {
      url = GET_PLACE_DETAIL;
    }

    if (action === 'ADD') {
      post(`${api.apiServerUrl}${url}/${itemId}/wishlists`, header, null)
        .then(response => {
          dispatch({ type: BOOKMARK_SUCCESS });
          dispatch({ type: SPINNER_HIDE });
          callback(response);
        })
        .catch(error => {
          dispatch({ type: BOOKMARK_ERROR, payload: { error } });
          dispatch({ type: SPINNER_HIDE });
          callback(error);
        });
    } else {
      del(`${api.apiServerUrl}${url}/${itemId}/wishlists`, header)
        .then(response => {
          dispatch({ type: BOOKMARK_SUCCESS });
          dispatch({ type: SPINNER_HIDE });
          callback(response);
        })
        .catch(error => {
          dispatch({ type: BOOKMARK_ERROR, payload: { error } });
          dispatch({ type: SPINNER_HIDE });
          callback(error);
        });
    }
    return true;
  };
}
