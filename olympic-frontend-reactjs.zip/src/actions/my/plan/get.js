import {
  GET_MY_PLAN_START,
  GET_MY_PLAN_SUCCESS,
  GET_MY_PLAN_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../../constants';
import { api } from '../../../config';
import { get, getHeader } from '../../../common/common';

export default function getMyPlan(callBack) {
  return async (dispatch, getState) => {
    dispatch({ type: GET_MY_PLAN_START });
    dispatch({ type: SPINNER_SHOW });
    const header = getHeader(getState());
    get(`${api.apiServerUrl}/api/v1/me/plans`, header)
      .then(data => {
        dispatch({ type: GET_MY_PLAN_SUCCESS, payload: data });
        dispatch({ type: SPINNER_HIDE });
        callBack(data);
      })
      .catch(error => {
        dispatch({ type: GET_MY_PLAN_ERROR, payload: { error } });
        dispatch({ type: SPINNER_HIDE });
      });
  };
}
