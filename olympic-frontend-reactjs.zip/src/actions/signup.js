import {
  SIGNUP_START,
  SIGNUP_SUCCESS,
  SIGNUP_ERROR,
  SIGNUP_CLEAR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../constants';

import Cognito from '../lib/Cognito';
import history from '../history';
import config from '../config';
import { LOGIN } from '../common/path';

const cognito = new Cognito(config);

// import { axios } from 'axios';

export default function signup({ username, email, password }) {
  return async dispatch => {
    dispatch({ type: SIGNUP_START });
    dispatch({ type: SPINNER_SHOW });
    try {
      return cognito
        .signupConito(username, email, password)
        .then(user => {
          dispatch({ type: SIGNUP_SUCCESS, payload: { user } });
          dispatch({ type: SPINNER_HIDE });
          history.push(LOGIN);
        })
        .catch(error => {
          dispatch({ type: SIGNUP_ERROR, payload: { error } });
          dispatch({ type: SPINNER_HIDE });
        });
    } catch (error) {
      dispatch({ type: SIGNUP_ERROR, payload: { error } });
      dispatch({ type: SPINNER_HIDE });
    }
    return true;
  };
}

export const clearSignup = () => async dispatch => {
  dispatch({ type: SIGNUP_CLEAR });
};
