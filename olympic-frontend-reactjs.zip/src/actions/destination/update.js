/**
 * Created by KhangNT on 8/9/2017.
 */
import { UPDATE_DESTINATION } from '../../constants'; //eslint-disable-line

export default function updateDestination(dataStore) {
  return async (dispatch, getState) => {
    dispatch({ type: UPDATE_DESTINATION, destination: dataStore });
  };
}
