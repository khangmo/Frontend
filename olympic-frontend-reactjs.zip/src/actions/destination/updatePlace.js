/**
 * Created by KhangNT on 8/9/2017.
 */
import { SPINNER_SHOW, SPINNER_HIDE } from '../../constants'; //eslint-disable-line
import { SAVE_DESTINATION } from '../../common/path';
import { post, getHeader } from '../../common/common';
import { api } from '../../config';

export default function addPlace(dataPost, callback) {
  return async (dispatch, getState) => {
    dispatch({ type: SPINNER_SHOW });
    const header = getHeader(getState());
    post(`${api.apiServerUrl}${SAVE_DESTINATION}`, header, dataPost)
      .then(response => {
        if (response.placeId) {
          dispatch({ type: SPINNER_HIDE });
          callback(response);
        }
      })
      .catch(error => {
        dispatch({ type: SPINNER_HIDE });
        callback(error);
      });
    return true;
  };
}
