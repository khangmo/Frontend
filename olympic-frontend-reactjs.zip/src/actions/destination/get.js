import {
  GET_DESTINATION_START,
  GET_DESTINATION_SUCCESS,
  GET_DESTINATION_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../constants';

import { api } from '../../config';
import { get, getHeader } from '../../common/common';

import { GET_DESTINATION_DETAIL } from '../../common/path';

export default function httpGet(destinationId, callback) {
  return async (dispatch, getState) => {
    dispatch({ type: GET_DESTINATION_START });
    dispatch({ type: SPINNER_SHOW });
    const header = getHeader(getState());
    get(`${api.apiServerUrl}${GET_DESTINATION_DETAIL}${destinationId}`, header)
      .then(response => {
        dispatch({ type: GET_DESTINATION_SUCCESS, payload: destinationId });
        dispatch({ type: SPINNER_HIDE });
        callback(response);
      })
      .catch(error => {
        dispatch({ type: GET_DESTINATION_ERROR, payload: { error } });
        dispatch({ type: SPINNER_HIDE });
        callback(error);
      });
    return true;
  };
}
