/**
 * Created by khangnt on 8/8/2017.
 */
import { ZENRIN_START, ZENRIN_SUCCESS, ZENRIN_ERROR } from '../../constants'; //eslint-disable-line

import { REQUEST_TRANSIT_ZENRIN } from '../../common/path';

import { api } from '../../config';
import { post, getHeader } from '../../common/common';

export default function postZenrin(data, callback) {
  return async (dispatch, getState) => {
    dispatch({ type: ZENRIN_START });

    const header = getHeader(getState());
    post(`${api.apiServerUrl}${REQUEST_TRANSIT_ZENRIN}`, header, data)
      .then(response => {
        dispatch({ type: ZENRIN_SUCCESS, payload: data });
        callback(response);
      })
      .catch(error => {
        dispatch({ type: ZENRIN_ERROR, payload: { error } });
        callback(error);
      });
    return true;
  };
}
