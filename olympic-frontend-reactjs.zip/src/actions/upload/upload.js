/**
 * Created by KhangNT on 8/1/2017.
 */
import {
  UPLOAD_START,
  UPLOAD_SUCCESS,
  UPLOAD_FAIL,
  SPINNER_SHOW,
  SPINNER_HIDE,
  PROFILE_SUCCESS,
  PROFILE_ERROR,
} from '../../constants';

import { api } from '../../config';

import dataSelect from '../../api/data_profile.json';

import { put, getHeader } from '../../common/common';

export default function uploadS3(post, file, imageName, directory, callback) {
  return async (dispatch, getState) => {
    dispatch({ type: UPLOAD_START });
    const header = getHeader(getState());
    post(file, imageName, directory, header, (error, response) => {
      if (error) {
        dispatch({ type: UPLOAD_FAIL });
      } else {
        dispatch({ type: UPLOAD_SUCCESS });
      }
      callback(error, response);
    });
  };
}
