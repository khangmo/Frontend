import {
  GET_PLAN_LIST_START,
  GET_PLAN_LIST_SUCCESS,
  GET_PLAN_LIST_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../../constants';
import { api } from '../../../config';
import { get, getHeader } from '../../../common/common';

export default function getPlanList(callBack) {
  return async (dispatch, getState) => {
    dispatch({ type: GET_PLAN_LIST_START });
    dispatch({ type: SPINNER_SHOW });
    const header = getHeader(getState());
    get(`${api.apiServerUrl}/api/v1/plans`, header)
      .then(data => {
        dispatch({ type: GET_PLAN_LIST_SUCCESS, payload: data });
        dispatch({ type: SPINNER_HIDE });
        callBack(data);
      })
      .catch(error => {
        dispatch({ type: GET_PLAN_LIST_ERROR, payload: { error } });
        dispatch({ type: SPINNER_HIDE });
      });
  };
}
