import {
  GET_PLACE_LIST_START,
  GET_PLACE_LIST_SUCCESS,
  GET_PLACE_LIST_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../../constants';

import { api } from '../../../config';
import { get, getHeader } from '../../../common/common';

export default function getMorePlace(pageNumber, size, cb) {
  return async (dispatch, getState) => {
    dispatch({
      type: GET_PLACE_LIST_START,
    });
    if (!size) {
      size = 12;
    }
    const header = getHeader(getState());

    dispatch({ type: SPINNER_SHOW });
    //# ?page=14&size=42
    get(
      `${api.apiServerUrl}api/v1/places?page=${pageNumber}&size=${size}`,
      header,
    )
      .then(resp => {
        dispatch({
          type: GET_PLACE_LIST_SUCCESS,
          payload: resp,
        });
        cb(resp);
        dispatch({ type: SPINNER_HIDE });
      })
      .catch(error => {
        dispatch({
          type: GET_PLACE_LIST_ERROR,
          payload: {
            error: `Backend error: ${error}`,
          },
        });
        dispatch({ type: SPINNER_HIDE });
        cb(error);
      });
  };
}
