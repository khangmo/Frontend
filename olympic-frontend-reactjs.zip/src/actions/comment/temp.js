/**
 * Created by KhangNT on 6/9/2017.
 */
import { COMMENT_ERROR, COMMENT_TEMP } from '../../constants';

export default function saveTemp(data) {
  return async dispatch => {
    try {
      dispatch({
        type: COMMENT_TEMP,
        dataTemp: data,
      });
    } catch (error) {
      dispatch({
        type: COMMENT_ERROR,
        payload: {
          error,
        },
      });
      return false;
    }
    return true;
  };
}
