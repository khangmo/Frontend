import {
  COMMENT_START,
  COMMENT_SUCCESS,
  COMMENT_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../constants';
import { api } from '../../config';
import { post, put, del, getHeader } from '../../common/common';
import { GET_PLACE_DETAIL, GET_PLAN_DETAIL } from '../../common/path';

export default function postComment(data, item, action, cb) {
  return async (dispatch, getState) => {
    dispatch({
      type: COMMENT_START,
    });

    let dataPost = {};
    if (action !== 'delete') {
      dataPost = {
        content: data.content,
        itemId: data.itemId,
        photo: data.photo,
        rating: data.rating,
      };
    }

    const header = getHeader(getState());
    let url = `${api.apiServerUrl}${GET_PLAN_DETAIL}`;
    if (item === 'places') {
      url = `${api.apiServerUrl}${GET_PLACE_DETAIL}`;
    }

    dispatch({ type: SPINNER_SHOW });

    switch (action) {
      case 'add':
        //# `${api.apiServerUrl}/api/v1/${item}/reviews/${data.itemId}`
        post(`${url}/${data.itemId}/reviews`, header, dataPost)
          .then(resp => {
            dispatch({ type: SPINNER_HIDE });
            cb(resp);
          })
          .catch(error => {
            dispatch({ type: COMMENT_ERROR, payload: { error } });
            dispatch({ type: SPINNER_HIDE });
            if (error.code) {
              bootbox.alert(error.message);
            }
          });
        break;

      case 'edit':
        //# http://10.17.23.39:9009/api/v1/places/{placeId}/reviews
        put(`${url}/${data.itemId}/reviews`, header, dataPost)
          .then(resp => {
            dispatch({ type: SPINNER_HIDE });
            cb(resp);
          })
          .catch(error => {
            dispatch({ type: COMMENT_ERROR, payload: { error } });
            dispatch({ type: SPINNER_HIDE });
            if (error.code) {
              bootbox.alert(error.message);
            }
          });
        break;

      case 'delete':
        //# `${api.apiServerUrl}/api/v1/${item}/${data.itemId}/reviews/${data.userId}`
        del(`${url}/${data.itemId}/reviews/${data.userId}`, header)
          .then(resp => {
            dispatch({ type: SPINNER_HIDE });
            cb(resp);
          })
          .catch(error => {
            dispatch({ type: COMMENT_ERROR, payload: { error } });
            dispatch({ type: SPINNER_HIDE });
            if (error.code) {
              bootbox.alert(error.message);
            }
          });
        break;

      default:
        break;
    }

    return true;
  };
}
