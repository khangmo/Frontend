import { COMMENT_CLEAR } from '../../constants';

export default function clear() {
  return async dispatch => {
    dispatch({
      type: COMMENT_CLEAR,
    });
  };
}
