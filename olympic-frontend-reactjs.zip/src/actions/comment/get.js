import {
  COMMENT_START,
  COMMENT_SUCCESS,
  COMMENT_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../constants';

import { api } from '../../config';

import { get, getHeader } from '../../common/common';

import { GET_PLACE_DETAIL, GET_PLAN_DETAIL } from '../../common/path';

export default function getComment(itemId, item, page, size, cb) {
  return async (dispatch, getState) => {
    dispatch({
      type: COMMENT_START,
    });
    if (!size) {
      size = 10;
    }
    const header = getHeader(getState());
    let url = `${api.apiServerUrl}${GET_PLAN_DETAIL}`;
    if (item === 'places') {
      url = `${api.apiServerUrl}${GET_PLACE_DETAIL}`;
    }

    dispatch({ type: SPINNER_SHOW });
    //# ?page=14&size=42
    get(`${url}/${itemId}/reviews?page=${page}&size=${size}`, header)
      .then(resp => {
        dispatch({
          type: COMMENT_SUCCESS,
          payload: resp,
        });
        cb(resp);
        dispatch({ type: SPINNER_HIDE });
      })
      .catch(error => {
        dispatch({
          type: COMMENT_ERROR,
          payload: {
            error: `Backend error: ${error}`,
          },
        });
        dispatch({ type: SPINNER_HIDE });
        cb(error);
      });
  };
}
