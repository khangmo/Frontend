import {
  LOGOUT_START,
  LOGOUT_SUCCESS,
  LOGOUT_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
  DESTINATION_CLEAR,
  PLAN_CLEAR,
  SIGNUP_CLEAR,
} from '../constants';

import Cognito from '../lib/Cognito';
import history from '../history';
import config from '../config';

import { LOGIN } from '../common/path';

const cognito = new Cognito(config);

export default function logout() {
  return async dispatch => {
    dispatch({ type: LOGOUT_START });
    dispatch({ type: SPINNER_SHOW });
    try {
      cognito
        .logoutCognitoUser()
        .then(user => {
          dispatch({ type: LOGOUT_SUCCESS, payload: { user } });
          dispatch({ type: DESTINATION_CLEAR });
          dispatch({ type: PLAN_CLEAR });
          dispatch({ type: SIGNUP_CLEAR });
          dispatch({ type: SPINNER_HIDE });
          history.push(LOGIN);
        })
        .catch(error => {
          dispatch({ type: LOGOUT_ERROR, payload: { error } });
          dispatch({ type: SPINNER_HIDE });
        });
    } catch (error) {
      dispatch({ type: LOGOUT_ERROR, payload: { error } });
      dispatch({ type: SPINNER_HIDE });
    }
  };
}
