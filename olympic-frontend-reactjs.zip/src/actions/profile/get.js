import {
  PROFILE_SUCCESS,
  PROFILE_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../constants';

import { api } from '../../config';

// import profile from '../../api/profile.json';
import dataSelect from '../../api/data_profile.json';

import { get, getHeader } from '../../common/common';
import history from '../../history';

export default function getProfile(userId, callback) {
  return async (dispatch, getState) => {
    if (!userId) {
      history.push('/login');
    }
    const header = getHeader(getState());
    dispatch({ type: SPINNER_SHOW });
    get(`${api.apiServerUrl}/api/v1/users/${userId}`, header)
      .then(profile => {
        dispatch({ type: PROFILE_SUCCESS, payload: { profile, dataSelect } });
        callback(profile);
        dispatch({ type: SPINNER_HIDE });
      })
      .catch(error => {
        dispatch({ type: PROFILE_ERROR, payload: { error } });
        callback(error);
        dispatch({ type: SPINNER_HIDE });
      });
  };
}
