import {
  PROFILE_SUCCESS,
  PROFILE_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../constants';

import { api } from '../../config';
import { put, getHeader } from '../../common/common';

import dataSelect from '../../api/data_profile.json';

export default function avatar(data, cb) {
  return async (dispatch, getState) => {
    const header = getHeader(getState());
    dispatch({ type: SPINNER_SHOW });
    const userId = getState().user.user.userId;
    put(`${api.apiServerUrl}/api/v1/users/${userId}/avatars`, header, data)
      .then(profile => {
        dispatch({
          type: PROFILE_SUCCESS,
          payload: { profile, dataSelect },
        });
        dispatch({ type: SPINNER_HIDE });
      })
      .catch(error => {
        dispatch({ type: PROFILE_ERROR, payload: { error } });
        dispatch({ type: SPINNER_HIDE });
      });
  };
}
