import {
  PROFILE_SUCCESS,
  PROFILE_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../constants';

import { api } from '../../config';
import { put, getHeader } from '../../common/common';

import dataSelect from '../../api/data_profile.json';

export default function httpPost(userId, data, cb) {
  return async (dispatch, getState) => {
    if (!userId) {
      history.push('/login');
    }
    const header = getHeader(getState());
    dispatch({ type: SPINNER_SHOW });
    put(`${api.apiServerUrl}/api/v1/users/${userId}`, header, data)
      .then(profile => {
        dispatch({ type: PROFILE_SUCCESS, payload: { profile, dataSelect } });
        dispatch({ type: SPINNER_HIDE });
        cb(profile);
      })
      .catch(error => {
        dispatch({ type: PROFILE_ERROR, payload: { error } });
        dispatch({ type: SPINNER_HIDE });
        cb(error);
      });
  };
}
