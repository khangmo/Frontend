/**
 * Created by KhangNT on 6/9/2017.
 */
import { UPDATE_DESTINATION, UPDATE_DESTINATION_ERROR } from '../constants';

export default function updateDestination(data) {
  return async dispatch => {
    try {
      dispatch({
        type: UPDATE_DESTINATION,
        destination: data,
      });
    } catch (error) {
      dispatch({
        type: UPDATE_DESTINATION_ERROR,
        payload: {
          error,
        },
      });
      return false;
    }
    return true;
  };
}
