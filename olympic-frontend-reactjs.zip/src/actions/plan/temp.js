/**
 * Created by KhangNT on 6/9/2017.
 */
import { PLAN_ERROR, PLAN_TEMP } from '../../constants';

export default function saveTemp(data) {
  return async dispatch => {
    try {
      dispatch({
        type: PLAN_TEMP,
        planData: data,
      });
    } catch (error) {
      dispatch({
        type: PLAN_ERROR,
        payload: {
          error,
        },
      });
      return false;
    }
    return true;
  };
}
