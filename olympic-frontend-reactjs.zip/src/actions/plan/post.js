import {
  PLAN_START,
  PLAN_SUCCESS,
  PLAN_ERROR,
  DESTINATION_CLEAR,
  PLAN_CLEAR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../constants';

import { SAVE_NEW_PLAN } from '../../common/path';

import { api } from '../../config';
import { post, getHeader } from '../../common/common';

export default function httpPost(data, callback) {
  return async (dispatch, getState) => {
    dispatch({ type: PLAN_START });
    dispatch({ type: SPINNER_SHOW });
    const header = getHeader(getState());
    post(`${api.apiServerUrl}${SAVE_NEW_PLAN}`, header, data)
      .then(response => {
        dispatch({ type: PLAN_SUCCESS, payload: data });
        dispatch({ type: DESTINATION_CLEAR });
        dispatch({ type: PLAN_CLEAR });
        dispatch({ type: SPINNER_HIDE });
        callback(response);
      })
      .catch(error => {
        dispatch({ type: PLAN_ERROR, payload: { error } });
        dispatch({ type: SPINNER_HIDE });
        callback(error);
      });
    return true;
  };
}
