/**
* Created by KhangNT on 8/19/2017.
*/
import { PLAN_ERROR, PLAN_EDIT } from '../../constants';

export default function editPlan(data) {
  return async dispatch => {
    try {
      dispatch({
        type: PLAN_EDIT,
        planEdit: data,
      });
    } catch (error) {
      dispatch({
        type: PLAN_ERROR,
        payload: {
          error,
        },
      });
      return false;
    }
    return true;
  };
};

