import {
  PLAN_START,
  PLAN_SUCCESS,
  PLAN_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../constants';

import { api } from '../../config';
import { get, getHeader } from '../../common/common';

import { GET_PLAN_DETAIL } from '../../common/path';

export default function httpGet(planId, callback) {
  return async (dispatch, getState) => {
    dispatch({ type: PLAN_START });
    dispatch({ type: SPINNER_SHOW });
    const header = getHeader(getState());
    get(`${api.apiServerUrl}${GET_PLAN_DETAIL}/${planId}`, header)
      .then(response => {
        dispatch({ type: PLAN_SUCCESS, payload: response });
        dispatch({ type: SPINNER_HIDE });
        callback(response);
      })
      .catch(error => {
        dispatch({ type: PLAN_ERROR, payload: { error } });
        dispatch({ type: SPINNER_HIDE });
        callback(error);
      });
    return true;
  };
}
