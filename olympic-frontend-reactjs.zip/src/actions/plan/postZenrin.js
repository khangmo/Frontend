import { //eslint-disable-line
  PLAN_ERROR,
  SPINNER_SHOW,
  SPINNER_HIDE,
} from '../../constants';

// import { SAVE_NEW_PLAN } from '../../common/path';

// import { api } from '../../config';
import { post, getHeader } from '../../common/common';

export default function httpPostZenrin(data, callback) {
  return async (dispatch, getState) => {
    dispatch({ type: SPINNER_SHOW });
    const header = getHeader(getState());
    // post(`${api.apiServerUrl}${SAVE_NEW_PLAN}`, header, data)
    post(`http://localhost:8888/api/v1/transits/edit`, header, data)
      .then(response => {
        dispatch({ type: SPINNER_HIDE });
        callback(response);
      })
      .catch(error => {
        dispatch({ type: PLAN_ERROR, payload: { error } });
        dispatch({ type: SPINNER_HIDE });
      });
    return true;
  };
}
