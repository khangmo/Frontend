import { DESTINATION_CLEAR, PLAN_CLEAR } from '../../constants';

export default function clearPlan() {
  return async dispatch => {
    dispatch({ type: DESTINATION_CLEAR });
    dispatch({ type: PLAN_CLEAR });
  };
}
