import {
  LOGIN_START,
  LOGIN_SUCCESS,
  LOGIN_ERROR,
  PROFILE_SUCCESS,
  SPINNER_SHOW,
  SPINNER_HIDE,
  MAPPING_START,
  MAPPING_SUCCESS,
  MAPPING_ERROR,
} from '../constants';

import Cognito from '../lib/Cognito';
import history from '../history';
import dataSelect from '../api/data_profile.json';

import config, { api } from '../config';
import { get, post } from '../common/common';
import { PLACES, SIGNUP } from '../common/path';

const cognito = new Cognito(config);

export function configure() {
  try {
    return cognito
      .getCurrentUser()
      .then(user => Promise.resolve(user))
      .catch(err => Promise.reject(err));
  } catch (error) {
    return Promise.reject(error);
  }
}

export function authenticate({ username, password }) {
  return dispatch => {
    dispatch({ type: LOGIN_START });
    dispatch({ type: SPINNER_SHOW });
    try {
      return cognito
        .login(username, password)
        .then(user => {
          // Create new user profile
          const header = {
            'X-Auth-Identity-Id': user.identityId,
            'X-Auth-Provider-Id': user.authenticator,
            'X-Auth-Token': user.userToken,
          };
          cognito.addEmailToLocalStore(user.email);
          cognito
            .getRecord()
            .then(data => {
              if (data.Records.length > 0) {
                let userId;
                let facebookId;
                let googleId;
                data.Records.map(record => {
                  if (record.Key === 'UserId') {
                    userId = record.Value;
                  }
                  if (record.Key === 'FacebookId') {
                    facebookId = record.Value;
                  }
                  if (record.Key === 'GoogleId') {
                    googleId = record.Value;
                  }
                });
                if (!userId) {
                  // When user profile not created
                  // Create new user profile
                  post(`${api.apiServerUrl}/api/v1/users`, header, { username })
                    .then(profile => {
                      if (!profile.code) {
                        const dateset = {
                          Key: 'UserId',
                          Value: profile.userId,
                          Op: 'replace', // required
                          SyncCount: data.DatasetSyncCount, // required
                        };
                        // Update metadata for login account
                        cognito.setRecord(dateset);
                        // Update user id in localstore
                        cognito.addUserIdToLocalStore(profile.userId);
                        cognito.addFacebookIdToLocalStore(facebookId);
                        cognito.addGoogleIdToLocalStore(googleId);
                        // Put user profile to state
                        dispatch({
                          type: PROFILE_SUCCESS,
                          payload: { profile, dataSelect },
                        });
                        user.userId = profile.userId;
                        user.facebookId = facebookId;
                        user.googleId = googleId;
                        dispatch({ type: LOGIN_SUCCESS, payload: { user } });
                        dispatch({ type: SPINNER_HIDE });
                        history.push(PLACES);
                      } else {
                        dispatch({
                          type: LOGIN_ERROR,
                          payload: { error: profile },
                        });
                        dispatch({ type: SPINNER_HIDE });
                      }
                    })
                    .catch(error => {
                      dispatch({ type: LOGIN_ERROR, payload: { error } });
                      dispatch({ type: SPINNER_HIDE });
                    });
                } else {
                  get(`${api.apiServerUrl}/api/v1/users/${userId}`, header)
                    .then(profile => {
                      // Update user id in localstore
                      cognito.addUserIdToLocalStore(profile.userId);
                      cognito.addFacebookIdToLocalStore(facebookId);
                      cognito.addGoogleIdToLocalStore(googleId);
                      // Put user profile to state
                      dispatch({
                        type: PROFILE_SUCCESS,
                        payload: { profile, dataSelect },
                      });
                      user.userId = profile.userId;
                      user.facebookId = facebookId;
                      user.googleId = googleId;
                      dispatch({ type: LOGIN_SUCCESS, payload: { user } });
                      dispatch({ type: SPINNER_HIDE });
                      history.push(PLACES);
                    })
                    .catch(error => {
                      dispatch({ type: LOGIN_ERROR, payload: { error } });
                      dispatch({ type: SPINNER_HIDE });
                    });
                }
              } else {
                // When user profile not created
                // Create new user profile
                post(`${api.apiServerUrl}/api/v1/users`, header, { username })
                  .then(profile => {
                    if (!profile.code) {
                      const dateset = {
                        Key: 'UserId',
                        Value: profile.userId,
                        Op: 'replace', // required
                        SyncCount: data.DatasetSyncCount, // required
                      };
                      // Update metadata for login account
                      cognito.setRecord(dateset);
                      // Update user id in localstore
                      cognito.addUserIdToLocalStore(profile.userId);
                      // Put user profile to state
                      dispatch({
                        type: PROFILE_SUCCESS,
                        payload: { profile, dataSelect },
                      });
                      user.userId = profile.userId;
                      dispatch({ type: LOGIN_SUCCESS, payload: { user } });
                      dispatch({ type: SPINNER_HIDE });
                      history.push(PLACES);
                    } else {
                      dispatch({
                        type: LOGIN_ERROR,
                        payload: { error: profile },
                      });
                      dispatch({ type: SPINNER_HIDE });
                    }
                  })
                  .catch(error => {
                    dispatch({ type: LOGIN_ERROR, payload: { error } });
                    dispatch({ type: SPINNER_HIDE });
                  });
              }
            })
            .catch(error => {
              dispatch({ type: LOGIN_ERROR, payload: { error } });
              dispatch({ type: SPINNER_HIDE });
            });
        })
        .catch(error => {
          dispatch({ type: LOGIN_ERROR, payload: { error } });
          dispatch({ type: SPINNER_HIDE });
        });
    } catch (error) {
      dispatch({ type: LOGIN_ERROR, payload: { error } });
      dispatch({ type: SPINNER_HIDE });
    }
  };
}

export function authenticateGoogle({ username, userToken, email }) {
  return dispatch => {
    dispatch({ type: LOGIN_START });
    dispatch({ type: SPINNER_SHOW });
    try {
      return cognito
        .getAwsCredentialsGG(username, userToken)
        .then(user => {
          const header = {
            'X-Auth-Identity-Id': user.identityId,
            'X-Auth-Provider-Id': user.authenticator,
            'X-Auth-Token': user.userToken,
          };
          cognito.addEmailToLocalStore(email);
          cognito
            .getRecord()
            .then(data => {
              if (data.Records.length > 0) {
                let userId;
                data.Records.map(record => {
                  if (record.Key === 'UserId') {
                    userId = record.Value;
                  }
                });
                if (!userId) {
                  // When user hasn't been mapped
                  // Goto signup page
                  dispatch({ type: SPINNER_HIDE });
                  history.push(SIGNUP);
                } else {
                  get(`${api.apiServerUrl}/api/v1/users/${userId}`, header)
                    .then(profile => {
                      // Update user id in localstore
                      cognito.addUserIdToLocalStore(profile.userId);
                      // Put user profile to state
                      dispatch({
                        type: PROFILE_SUCCESS,
                        payload: { profile, dataSelect },
                      });
                      user.userId = profile.userId;
                      dispatch({ type: LOGIN_SUCCESS, payload: { user } });
                      dispatch({ type: SPINNER_HIDE });
                      history.push(PLACES);
                    })
                    .catch(error => {
                      dispatch({ type: LOGIN_ERROR, payload: { error } });
                      dispatch({ type: SPINNER_HIDE });
                    });
                }
              } else {
                // When user hasn't been mapped
                // Goto signup page
                dispatch({ type: SPINNER_HIDE });
                history.push(SIGNUP);
              }
            })
            .catch(error => {
              dispatch({ type: LOGIN_ERROR, payload: { error } });
              dispatch({ type: SPINNER_HIDE });
            });
        })
        .catch(error => {
          dispatch({ type: LOGIN_ERROR, payload: { error } });
          dispatch({ type: SPINNER_HIDE });
        });
    } catch (error) {
      dispatch({ type: LOGIN_ERROR, payload: { error } });
      dispatch({ type: SPINNER_HIDE });
    }
  };
}

export function authenticateFacebook({ username, userToken, email }) {
  return dispatch => {
    dispatch({ type: LOGIN_START });
    dispatch({ type: SPINNER_SHOW });
    try {
      return cognito
        .getAwsCredentialsFB(username, userToken)
        .then(user => {
          const header = {
            'X-Auth-Identity-Id': user.identityId,
            'X-Auth-Provider-Id': user.authenticator,
            'X-Auth-Token': user.userToken,
          };
          cognito.addEmailToLocalStore(email);
          cognito
            .getRecord()
            .then(data => {
              if (data.Records.length > 0) {
                let userId;
                data.Records.map(record => {
                  if (record.Key === 'UserId') {
                    userId = record.Value;
                  }
                });
                if (!userId) {
                  // When user hasn't been mapped
                  // Goto signup page
                  dispatch({ type: SPINNER_HIDE });
                  history.push(SIGNUP);
                } else {
                  get(`${api.apiServerUrl}/api/v1/users/${userId}`, header)
                    .then(profile => {
                      // Update user id in localstore
                      cognito.addUserIdToLocalStore(profile.userId);
                      // Put user profile to state
                      dispatch({
                        type: PROFILE_SUCCESS,
                        payload: { profile, dataSelect },
                      });
                      user.userId = profile.userId;
                      dispatch({ type: LOGIN_SUCCESS, payload: { user } });
                      dispatch({ type: SPINNER_HIDE });
                      history.push(PLACES);
                    })
                    .catch(error => {
                      dispatch({ type: LOGIN_ERROR, payload: { error } });
                      dispatch({ type: SPINNER_HIDE });
                    });
                }
              } else {
                // When user hasn't been mapped
                // Goto signup page
                dispatch({ type: SPINNER_HIDE });
                history.push(SIGNUP);
              }
            })
            .catch(error => {
              console.log(error);
              dispatch({ type: LOGIN_ERROR, payload: { error } });
              dispatch({ type: SPINNER_HIDE });
            });
        })
        .catch(error => {
          console.log(error);
          dispatch({ type: LOGIN_ERROR, payload: { error } });
          dispatch({ type: SPINNER_HIDE });
        });
    } catch (error) {
      console.log(error);
      dispatch({ type: LOGIN_ERROR, payload: { error } });
      dispatch({ type: SPINNER_HIDE });
    }
  };
}

export function mappingFacebook({ username, userToken }) {
  return dispatch => {
    dispatch({ type: MAPPING_START });
    dispatch({ type: SPINNER_SHOW });
    try {
      cognito.getRecord().then(data => {
        if (data.Records.length > 0) {
          let userId;
          data.Records.map(record => {
            if (record.Key === 'UserId') {
              userId = record.Value;
            }
          });
          // 1. Update amazon account facebook id
          const dateset = {
            Key: 'FacebookId',
            Value: username,
            Op: 'replace', // required
            SyncCount: data.DatasetSyncCount, // required
          };
          // Update metadata for facebook account
          cognito.setRecord(dateset);
          // 2. Update metadata user profile
          // const userId = cognito.getUserId();
          return cognito
            .getAwsCredentialsFB(username, userToken)
            .then(user => {
              cognito.getRecord().then(data => {
                const dateset = {
                  Key: 'UserId',
                  Value: userId,
                  Op: 'replace', // required
                  SyncCount: data.DatasetSyncCount, // required
                };
                // Update metadata for login account
                cognito.setRecord(dateset);
                dispatch({ type: MAPPING_SUCCESS });
                dispatch({ type: SPINNER_HIDE });
              });
            })
            .catch(error => {
              dispatch({ type: MAPPING_ERROR, payload: { error } });
              dispatch({ type: SPINNER_HIDE });
            });
        } else {
          dispatch({ type: SPINNER_HIDE });
          console.log('Record not found');
        }
      });
    } catch (error) {
      dispatch({ type: MAPPING_ERROR, payload: { error } });
      dispatch({ type: SPINNER_HIDE });
    }
  };
}

export function mappingGoogle({ username, userToken }) {
  return dispatch => {
    dispatch({ type: MAPPING_START });
    dispatch({ type: SPINNER_SHOW });
    try {
      cognito.getRecord().then(data => {
        if (data.Records.length > 0) {
          let userId;
          data.Records.map(record => {
            if (record.Key === 'UserId') {
              userId = record.Value;
            }
          });
          // 1. Update amazon account facebook id
          const dateset = {
            Key: 'GoogleId',
            Value: username,
            Op: 'replace', // required
            SyncCount: data.DatasetSyncCount, // required
          };
          // Update metadata for facebook account
          cognito.setRecord(dateset);
          // 2. Update metadata user profile
          // const userId = cognito.getUserId();
          return cognito
            .getAwsCredentialsGG(username, userToken)
            .then(user => {
              cognito.getRecord().then(data => {
                const dateset = {
                  Key: 'UserId',
                  Value: userId,
                  Op: 'replace', // required
                  SyncCount: data.DatasetSyncCount, // required
                };
                // Update metadata for login account
                cognito.setRecord(dateset);
                dispatch({ type: MAPPING_SUCCESS });
                dispatch({ type: SPINNER_HIDE });
              });
            })
            .catch(error => {
              dispatch({ type: MAPPING_ERROR, payload: { error } });
              dispatch({ type: SPINNER_HIDE });
            });
        } else {
          dispatch({ type: SPINNER_HIDE });
          console.log('Record not found');
        }
      });
    } catch (error) {
      dispatch({ type: MAPPING_ERROR, payload: { error } });
      dispatch({ type: SPINNER_HIDE });
    }
  };
}
