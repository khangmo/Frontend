/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

/* eslint-disable max-len */

// if (process.env.BROWSER) {
//   throw new Error('Do not import `config.js` from inside the client-side code.');
// }

module.exports = {
  // Site name
  siteName: 'Olympic',

  // Node.js app
  port: process.env.PORT || 3000,

  // API Gateway
  api: {
    // API URL to be used in the server-side code
    apiServerUrl:
      process.env.API_SERVER_URL ||
      'http://olympic-backend-beta-elb-389161899.ap-northeast-1.elb.amazonaws.com',
    apiServerTimeout: process.env.API_SERVER_TIMEOUT || 3600000, // milliseconds
  },
  // Web analytics
  analytics: {
    // https://analytics.google.com/
    googleTrackingId: process.env.GOOGLE_TRACKING_ID, // UA-XXXXX-X
  },
  imageFolder: {
    imageServer:
      process.env.IMAGE_SERVER ||
      'https://s3-ap-northeast-1.amazonaws.com/olympic-images.nbd-dev.org',
    userAvatar:
      process.env.IMAGE_FOLDER_USER_AVATAR_ORIGIN || 'user/avatar/origin',
    planAvatar:
      process.env.IMAGE_FOLDER_PLAN_AVATAR_ORIGIN || 'plan/avatar/origin',
    planPhoto:
      process.env.IMAGE_FOLDER_PLAN_PHOTO_ORIGIN || 'plan/image/origin',
    placePhoto:
      process.env.IMAGE_FOLDER_PLACE_PHOTO_ORIGIN || 'place/image/origin',
  },
  aws: {
    Region: process.env.AWS_REGION || 'ap-northeast-1',
    IdentityPoolId:
      process.env.AWS_COGNITO_IDENTITY_POOL_ID ||
      'ap-northeast-1:a99c4e20-e64f-4fcd-94f9-1bcce595bf2a',
    Bucket: process.env.AWS_BUCKET || 'olympic-images.nbd-dev.org',
  },
  cognito: {
    USER_POOL_ID:
      process.env.AWS_COGNITO_USER_POOL_ID || 'ap-northeast-1_ch9yWvqtp',
    APP_CLIENT_ID:
      process.env.AWS_COGNITO_APP_CLIENT_ID || '4g3urj0e2q5gr6v7qsa8ot9od9',
    authenticator:
      process.env.AWS_COGNITO_AUTHENTINCATOR ||
      'cognito-idp.ap-northeast-1.amazonaws.com/ap-northeast-1_ch9yWvqtp',
    DatasetName: process.env.AWS_COGNITO_DATASET_NAME || 'TEST_DATASET',
  },
  facebook: {
    authenticator: process.env.FACEBOOK_AUTHENTICATOR || 'graph.facebook.com',
    clientId: process.env.FACEBOOK_CLIENT_ID || '473123806373231',
  },
  google: {
    authenticator: process.env.GOOGLE_AUTHENTICATOR || 'accounts.google.com',
    clientId:
      process.env.GOOGLE_CLIENT_ID ||
      '581247219753-c3ahuolu2vampvve5j1hq589m683rq4g.apps.googleusercontent.com',
  },

  plan_avatar_default: 'images/Fuji-mount-Japan.png',

  public_default: 'PUBLIC',
};
