import {
  PLAN_START,
  PLAN_SUCCESS,
  PLAN_ERROR,
  PLAN_CLEAR,
  PLAN_TEMP,
} from '../constants';

const INITIAL_STATE = {
  loading: false,
};

export default function plans(state = { plan: [] }, action) {
  if (state === null) {
    // server doesn't suppprt state = {}
    return INITIAL_STATE;
  }

  switch (action.type) {
    case PLAN_START:
      return {
        ...state,
        loading: true,
        error: null,
        plan: null,
      };
    case PLAN_SUCCESS:
      return {
        ...state,
        loading: false,
        error: null,
        plan: action.payload,
      };
    case PLAN_TEMP:
      return {
        ...state,
        loading: false,
        error: null,
        temp: action.planData,
      };
    case PLAN_CLEAR:
      return {
        ...state,
        loading: false,
        error: null,
        plan: null,
        temp: null,
      };
    case PLAN_ERROR:
      return {
        ...state,
        loading: false,
        error: action.payload.error,
        plan: null,
      };
    default:
      return state;
  }
}
