import { SPINNER_SHOW, SPINNER_HIDE } from '../constants';

const INITIAL_STATE = {
  loading: false,
};

export default function index(state = {}, action) {
  if (state === null) {
    // server doesn't suppprt state = {}
    return INITIAL_STATE;
  }
  switch (action.type) {
    case SPINNER_SHOW:
      return {
        ...state,
        loading: true,
      };
    case SPINNER_HIDE:
      return {
        ...state,
        loading: false,
      };
    default:
      return state;
  }
}
