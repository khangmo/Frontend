import { combineReducers } from 'redux';
import { UPDATE_DESTINATION, UPDATE_DESTINATION_ERROR } from '../constants';

const updateDestination = (state = [], action) => {
  switch (action.type) {
    case UPDATE_DESTINATION:
      return { state, addDestination: action.destinations };
    case UPDATE_DESTINATION_ERROR:
      return [
        ...state,
        {
          error: action.payload.error,
          destination: null,
        },
      ];
    default:
      return state;
  }
};

export default combineReducers({
  updateDestination,
});
