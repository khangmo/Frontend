import { combineReducers } from 'redux';
import { ADD_DESTINATION_START, DESTINATION_CLEAR } from '../constants';

const addDestination = (state = [], action) => {
  switch (action.type) {
    case ADD_DESTINATION_START:
      return [...state, action.destination];
    case DESTINATION_CLEAR:
      return { state, addDestination: [] };
    default:
      return state;
  }
};
export default combineReducers({
  addDestination,
});
