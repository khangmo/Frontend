import { combineReducers } from 'redux';
import user from './user';
import runtime from './runtime';
import destination from './destination';
import plans from './plan';
import profile from './profile';
import userAgent from './userAgent';
import locationPath from './locationPath';
import comments from './comment';
import updateDestination from './updateDestination';
import places from './places';
import spinner from './spinner';
import myPlan from './myPlan';
import planList from './planList';
import placeList from './placeList';
import editPlan from './editPlan';

export default combineReducers({
  user,
  runtime,
  plans,
  profile,
  destination,
  updateDestination,
  userAgent,
  comments,
  places,
  spinner,
  locationPath,
  myPlan,
  planList,
  placeList,
  editPlan,
});
