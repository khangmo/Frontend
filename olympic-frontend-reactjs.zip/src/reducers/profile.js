import { PROFILE_START, PROFILE_SUCCESS, PROFILE_ERROR } from '../constants';

const INITIAL_STATE = {
  loading: false,
};

export default function profile(state = { profile: [] }, action) {
  if (state === null) {
    // server doesn't suppprt state = {}
    return INITIAL_STATE;
  }

  switch (action.type) {
    case PROFILE_START:
      return {
        ...state,
        loading: true,
        profile: null,
      };
    case PROFILE_SUCCESS:
      return {
        ...state,
        loading: false,
        error: null,
        profile: action.payload,
      };
    case PROFILE_ERROR:
      return {
        ...state,
        loading: false,
        error: action.payload.error,
        profile: null,
      };
    default:
      return state;
  }
}
