import {
  LOGIN_START,
  LOGIN_SUCCESS,
  LOGIN_ERROR,
  SIGNUP_START,
  SIGNUP_SUCCESS,
  SIGNUP_ERROR,
  SIGNUP_CLEAR,
  LOGOUT_SUCCESS,
  CHECK_CURRENT_USER,
  USER_AVAIABLE,
  USER_NOT_AVAIABLE,
} from '../constants';

const INITIAL_STATE = {
  loading: false,
};

export default function user(state = {}, action) {
  if (state === null) {
    // server doesn't suppprt state = {}
    return INITIAL_STATE;
  }
  switch (action.type) {
    case LOGIN_START:
      return {
        ...state,
        loading: true,
        user: null,
        error: null,
      };
    case LOGIN_SUCCESS:
      return {
        ...state,
        loading: false,
        error: null,
        user: action.payload.user,
      };
    case LOGIN_ERROR:
      return {
        ...state,
        loading: false,
        error: action.payload.error ? action.payload.error : null,
        user: null,
      };
    case CHECK_CURRENT_USER:
      return {
        ...state,
        loading: true,
        user: null,
        error: null,
      };
    case USER_AVAIABLE:
      return {
        ...state,
        loading: false,
        error: null,
        user: action.payload.user,
      };
    case USER_NOT_AVAIABLE:
      return {
        ...state,
        loading: false,
        error: action.payload.error ? action.payload.error : null,
        user: null,
      };
    case SIGNUP_START:
      return {
        ...state,
        loading: true,
        signup: null,
        error: null,
      };
    case SIGNUP_SUCCESS:
      return {
        ...state,
        loading: false,
        error: null,
        signup: action.payload.user,
      };
    case SIGNUP_ERROR:
      return {
        ...state,
        loading: false,
        error: action.payload.error,
      };
    case SIGNUP_CLEAR:
      return {
        ...state,
        loading: false,
        error: null,
        signup: null,
      };
    case LOGOUT_SUCCESS:
      return {
        ...state,
        error: null,
        user: null,
      };
    default:
      return state;
  }
}
