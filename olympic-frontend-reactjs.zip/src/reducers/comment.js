import {
  COMMENT_START,
  COMMENT_SUCCESS,
  COMMENT_ERROR,
  COMMENT_TEMP,
  COMMENT_CLEAR,
} from '../constants';

const INITIAL_STATE = {
  loading: false,
};

export default function comment(state = { comment: [] }, action) {
  if (state === null) {
    // server doesn't suppprt state = {}
    return INITIAL_STATE;
  }

  switch (action.type) {
    case COMMENT_START:
      return {
        ...state,
        loading: true,
        comment: null,
      };
    case COMMENT_SUCCESS:
      return {
        ...state,
        loading: false,
        error: null,
        comment: action.payload,
      };
    case COMMENT_ERROR:
      return {
        ...state,
        loading: false,
        error: action.payload.error,
        comment: null,
      };
    case COMMENT_TEMP:
      return {
        ...state,
        loading: false,
        error: null,
        comment: action.dataTemp,
      };
    case COMMENT_CLEAR:
      return {
        ...state,
        loading: false,
        error: null,
        comment: null,
      };
    default:
      return state;
  }
}
