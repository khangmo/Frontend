import {
  GET_PLAN_LIST_START,
  GET_PLAN_LIST_SUCCESS,
  GET_PLAN_LIST_ERROR,
} from '../constants';

const INITIAL_STATE = {
  loading: false,
  data: null,
  error: null,
};

export default function planList(state = { data: [] }, action) {
  if (state === null) {
    return INITIAL_STATE;
  }

  switch (action.type) {
    case GET_PLAN_LIST_START:
      return {
        ...state,
        loading: true,
        data: null,
        error: null,
      };
    case GET_PLAN_LIST_SUCCESS:
      return {
        ...state,
        loading: false,
        error: null,
        data: action.payload,
      };
    case GET_PLAN_LIST_ERROR:
      return {
        ...state,
        loading: false,
        error: action.payload.error,
        data: null,
      };
    default:
      return state;
  }
}
