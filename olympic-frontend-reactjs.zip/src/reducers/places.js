import { PLACES_START, PLACES_SUCCESS, PLACES_ERROR } from '../constants';

const INITIAL_STATE = {
  loading: false,
};

export default function place(state = { places: [] }, action) {
  if (state === null) {
    // server doesn't suppprt state = {}
    return INITIAL_STATE;
  }

  switch (action.type) {
    case PLACES_START:
      return {
        ...state,
        loading: true,
        places: null,
      };
    case PLACES_SUCCESS:
      return {
        ...state,
        loading: false,
        error: null,
        places: action.payload,
      };
    case PLACES_ERROR:
      return {
        ...state,
        loading: false,
        error: action.payload.error,
        places: null,
      };
    default:
      return state;
  }
}
