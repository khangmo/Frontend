/**
 * Created by KhangNT on 8/19/2017.
 */
import { PLAN_EDIT } from '../constants'; //eslint-disable-line

export default function editPlan(state = {}, action) {
  switch (action.type) {
    case PLAN_EDIT:
      return {
        ...state,
        planEdit: action.planEdit,
      };
    default:
      return state;
  }
}
