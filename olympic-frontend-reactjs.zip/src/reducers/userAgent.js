import { SET_USER_AGENT_VARIABLE } from '../constants';

export default function setUserAgent(state = {}, action) {
  switch (action.type) {
    case SET_USER_AGENT_VARIABLE:
      return {
        ...state,
        userAgent: action.userAgent,
      };
    default:
      return state;
  }
}
