## POST
#### How to call POST method, for example like below:
```javascript
post(url, headers, callback, data);
```
 `callback` is a function, which is processing your data was received from server.
```javascript
post('http://10.17.22.85:8888/test', {
      'o-u-uid': 'userid',
      'o-u-token': 'AAAAAAAAAAAAAAAAAAAAAAAAA',
    }, callback, {
      data: {
        id: '0001',
        name: 'khangnt',
      },
    });
```

## PUT
#### How to call PUT method, for example like below:
```javascript
put(url, headers, callback, data);
```
 `callback` is a function, which is processing your data was received from server.
```javascript
put('http://10.17.22.85:8888/test/1000', {
    'o-u-uid': 'userid',
      'o-u-token': 'AAAAAAAAAAAAAAAAAAAAAAAAA',
    }, callback, {
      data: {
        id: '0001',
        name: 'khangnt',
      },
    });
```
`1000` in your url is an id of object will be update.

## GET
#### How to call GET method, for example like below:
```javascript
get(url, headers, callback);
```
```javascript
get('http://10.17.22.85:8888/test', {
      'o-u-uid': 'userid',
      'o-u-token': 'AAAAAAAAAAAAAAAAAAAAAAAAA',
    }, callback);
```

## DELETE
#### How to call DELETE method, for example like below:
```javascript
get(url, headers, callback);
```
```javascript
get('http://10.17.22.85:8888/test/1000', {
      'o-u-uid': 'userid',
      'o-u-token': 'AAAAAAAAAAAAAAAAAAAAAAAAA',
    }, callback);
```
`1000` in your url is an id of object will be delete.

---

## getPlacesDetail
#### How to call getPlacesDetail, for example like below:
 ```javascript
 getPlacesDetail(placeService, placeIds, callback);
````

#### With getPlacesDetail method, parameters input will be defined below:
+ `placeService` will be initialized before call `getPlacesDetail` method, because
 if you call the function multiple times, there will be no re-initialization 
 of the `placeService`: 
```javascript
placeService = new google.maps.places.PlacesService(document.createElement('div'));
```
+ `placeIds` is an array of `place_id` (Google Maps)
```javascript
['ChIJD4KER5OMGGARGI6iNtBWYQE', 'ChIJddt-chuJGGARDHrwEnQv27', 'ChIJEZUb1l-bImARvnvg_9t3thw',]
```
+ `callback` is a function, which is processing your data was received from `placeService`. For
example a callback function like this:
```javascript
const callback = (response) => {
    bootbox.alert(JSON.stringify(response));  
};
```

## mapPlaceDetailToDestination
#### How to call `mapPlaceDetailToDestination`, for example like below:
```javascript
import { mapPlaceDetailToDestination } from '../../common/common';

let service;

componentDidMount(){
    /* Initialize service */
    this.service = new google.maps.places.PlacesService(document.createElement('div'));
}
mapPlaceDetailToDestination(data, this.service);
```
#### With `mapPlaceDetailToDestination` method, all parameters input will be defined below:
+ `data` is an array, each element has format like this:
```json
{
  "2017-06-12": [
      {
        "title": "Sendaiborigawa Park, Koto, Tokyo, Japan",
        "date": "2017-06-12T17:00:00.000Z",
        "start": "8:00 pm",
        "stay": 5,
        "summary": "Sendaiborigawa Park, Koto, Tokyo, Japan",
        "google_id": "ChIJo7k4wGCIGGAR1qAiJCBqXWo"
      }, {
        "title": "Saitama Prefecture, flowers and green Promotion Center",
        "date": "2017-06-12T17:00:00.000Z",
        "start": "7:00 am",
        "stay": 4,
        "summary": "Saitama Prefecture, flowers and green Promotion Center, Kawaguchi, Saitama, Nh?t B?n",
        "google_id": "ChIJcdHQQT6UGGAR9uLN2rrGBmw"
      }
    ],
  "2017-06-13": [
      {
        "title": "Funabashi Andersen Park",
        "date": "2017-06-13T17:00:00.000Z",
        "start": "9:55 pm",
        "stay": 3,
        "summary": "Funabashi Andersen Park, Funabashi, Chiba, Japan",
        "google_id": "ChIJRTLSKVN-ImARhPnTKDzmzdQ"
      }
  ]  
}
```
+  `this.service` like 
```javascript
/* Initialize service */
this.service = new google.maps.places.PlacesService(document.createElement('div'));
```
`document.createElement('div')` because Instead of use map object of google, we will use free object.

## Convert location between Google Maps and ZENRIN maps
#### Import object from `google-maps-zenrin` npm
```javascript
import GoogleMapsZenrin from 'google-maps-zenrin';
```
+ Convert location of Google Maps to ZENRIN:
```javascript
const zenrinLocation = GoogleMapsZenrin.googleMapsToZenrin({
  lat: 35.168045,
  lng: 136.8765806
});
```
+ Convert location of ZENRIN to Google Maps:
```javascript
const googleLocation = GoogleMapsZenrin.zenrinToGoogleMaps({
  lat: 35.6658741,
  lng: 35.1648231
});
```
