/**
 * Created by KhangNT on 6/27/2017.
 */
import axios from 'axios'; //eslint-disable-line
import GoogleMapsZenrin from 'google-maps-zenrin';

import { api } from '../config';
import { NEW_ICON_TRANSIT } from '../constants/icons';

// Get random photo from public/images folder
export const getRandomPhoto = () => {
  const photos = ['images/Tokyo_Tower_02.jpg'];
  const index = Math.floor(Math.random() * 1);
  return photos[index];
};

const setConfigGet = (url, headers) => ({
  method: 'get',
  url,
  responseType: 'json',
  withCredentials: true,
  timeout: api.apiServerTimeout,
  headers,
});

export const getHeader = state => {
  const user = state.user.user;
  if (user) {
    return {
      'X-Auth-Identity-Id': user.identityId,
      'X-Auth-Provider-Id': user.authenticator,
      'X-Auth-Token': user.userToken,
      'X-Auth-UserName': user.username,
    };
  }
  return {};
};

export const isLogin = user => {
  if (user) {
    return true;
  }
  return false;
};

export const getPostCode = info => {
  if (info) {
    let temp = info;
    while (temp.indexOf(',') >= 0) {
      temp = temp.replace(',', '');
    }
    const res = temp.split('</span>');
    for (let i = 0; i < res.length; i++) {
      // eslint-disable-line
      if (res[i].indexOf('postal-code') >= 0) {
        return res[i].replace('<span class="postal-code">', '');
      }
    }
  }
  return '';
};

export const convertDataFollowDate = data => {
  const result = {};
  if (data) {
    for (let i = 0; i < data.length; i++) {
      //eslint-disable-line
      const dateFormat = data[i].startDate;
      if (dateFormat) {
        if (Object.prototype.hasOwnProperty.call(result, dateFormat)) {
          const keys = Object.keys(result);
          for (let j = 0; j < keys.length; j++) {
            //eslint-disable-line
            if (keys[j] === dateFormat) {
              result[keys[j]] = [...result[keys[j]], data[i]];
            }
          }
        } else {
          result[dateFormat] = [data[i]];
        }
      }
    }
  }
  return result;
};

export const mapDataToDate = data => {
  const result = {};
  if (data) {
    data.map(eachPlace => {
      const date = eachPlace.date;
      if (Object.prototype.hasOwnProperty.call(result, date)) {
        const keys = Object.keys(result);
        keys.map(key => {
          if (key === date) {
            result[key] = [...result[key], eachPlace];
          }
          return key;
        });
      } else {
        result[date] = [eachPlace];
      }
      return eachPlace;
    });
  } else {
    bootbox.alert('Can not map array of data to date!'); //eslint-disable-line
  }
  return result;
};

export const parserDeatailService = dataInput => {
  const map = {};
  if (dataInput) {
    if (Object.prototype.hasOwnProperty.call(dataInput, 'geometry')) {
      const geometry = dataInput.geometry;
      map.location = geometry.location;
    }
    if (Object.prototype.hasOwnProperty.call(dataInput, 'place_id')) {
      map.place_id = dataInput.place_id;
    }
    if (Object.prototype.hasOwnProperty.call(dataInput, 'id')) {
      map.id = dataInput.id;
    }
    if (
      Object.prototype.hasOwnProperty.call(
        dataInput,
        'international_phone_number',
      )
    ) {
      map.international_phone_number = dataInput.international_phone_number;
    }
    if (Object.prototype.hasOwnProperty.call(dataInput, 'name')) {
      map.name = dataInput.name;
    }
    if (Object.prototype.hasOwnProperty.call(dataInput, 'rating')) {
      map.rating = dataInput.rating;
    }
    if (Object.prototype.hasOwnProperty.call(dataInput, 'reference')) {
      map.reference = dataInput.reference;
    }
    if (Object.prototype.hasOwnProperty.call(dataInput, 'website')) {
      map.website = dataInput.website;
    }
    if (Object.prototype.hasOwnProperty.call(dataInput, 'types')) {
      map.types = dataInput.types;
    }
    if (Object.prototype.hasOwnProperty.call(dataInput, 'formatted_address')) {
      map.formatted_address = dataInput.formatted_address;
    }
    if (Object.prototype.hasOwnProperty.call(dataInput, 'icon')) {
      map.icon = dataInput.icon;
    }
    if (Object.prototype.hasOwnProperty.call(dataInput, 'adr_address')) {
      map.post_code = getPostCode(dataInput.adr_address);
    }
  }
  return map;
};

const setConfigPost = (url, data, headers) => ({
  method: 'post',
  url,
  data,
  timeout: api.apiServerTimeout,
  responseType: 'json',
  headers,
});

const setConfigPut = (url, data, headers) => ({
  method: 'put',
  url,
  data,
  timeout: api.apiServerTimeout,
  responseType: 'json',
  headers,
});

const setConfigDelete = (url, headers) => ({
  method: 'delete',
  url,
  timeout: api.apiServerTimeout,
  responseType: 'json',
  headers,
});

export const get = (url, headers) =>
  new Promise((resolve, reject) => {
    const config = setConfigGet(url, headers);

    axios(config)
      .then(response => {
        resolve(response.data);
      })
      .catch(error => {
        if (error.response && error.response.data) {
          reject(error.response.data);
        } else {
          reject({ code: 10, message: 'Server under maintenance' });
        }
      });
  });

export const post = (url, headers, data) =>
  new Promise((resolve, reject) => {
    const config = setConfigPost(url, data, headers);
    axios(config)
      .then(response => {
        resolve(response.data);
      })
      .catch(error => {
        if (error.response && error.response.data) {
          reject(error.response.data);
        } else {
          reject({ code: 10, message: 'Server under maintenance' });
        }
      });
  });

export const put = (url, headers, data) =>
  new Promise((resolve, reject) => {  //eslint-disable-line
    const config = setConfigPut(url, data, headers);
    axios(config)
      .then(response => {
        resolve(response.data);
      })
      .catch(error => {
        if (error.response && error.response.data) {
          reject(error.response.data);
        } else {
          reject({ code: 10, message: 'Server under maintenance' });
        }
      });
  });

export const del = (url, headers) =>
  new Promise((resolve, reject) => {  //eslint-disable-line
    const config = setConfigDelete(url, headers);
    axios(config)
      .then(response => {
        resolve(response.data);
      })
      .catch(error => {
        if (error.response && error.response.data) {
          reject(error.response.data);
        } else {
          reject({ code: 10, message: 'Server under maintenance' });
        }
      });
  });

export const getPlaceDetail = (placeService, placeId, callback) => {
  if (placeId && placeService) {
    placeService.getDetails(
      {
        placeId,
      },
      (place, status) => {
        if (status === 'OK') {
          callback(place);
        } else {
          bootbox.alert( //eslint-disable-line
            `Does not get place detail from place_id is ${placeId}`,
          );
        }
      },
    );
  }
};

export const getPlacesDetail = (placeService, placeIds, callback) => {
  if (placeIds && placeService) {
    placeIds.map(placeId => getPlaceDetail(placeService, placeId, callback));
  } else {
    bootbox.alert('Error occurred!'); //eslint-disable-line
  }
};

export const getRecusivePlaceDetail = (
  placeService,
  DirectionsService,
  data,
  index,
  callback,
) => {
  if (index < data.length) {
    placeService.getDetails(
      {
        placeId: data[index].place.googleId,
      },
      (place, status) => {
        if (status === 'OK') {
          const map = parserDeatailService(place);
          data[index].map = map; //eslint-disable-line
        } else {
          bootbox.alert( //eslint-disable-line
            `Does not get place detail from place_id is ${data[index]
              .google_id}`,
          );
        }
        getRecusivePlaceDetail(
          placeService,
          DirectionsService,
          data,
          index + 1,
          callback,
        ); //eslint-disable-line
      },
    );
  } else {
    /* Save data to store */
    callback(DirectionsService, mapDataToDate(data));
  }
};

/* Map place info to data array */
export const mapPlaceDetailToDestination = (
  data,
  placeService,
  DirectionsService,
  callback,
) => {
  if (!data || !placeService) {
    bootbox.alert('Please check data or place service again!'); //eslint-disable-line
    return;
  }
  /* Create a array to store all data before get Detail Service */
  const tempData = [];
  const dataInput = convertDataFollowDate(data);
  const days = Object.keys(dataInput);
  days.map(day => {
    const currentDay = dataInput[day];
    /* Browsing all destination on day */
    currentDay.map(destinationOnDay => {
      destinationOnDay.date = day; //eslint-disable-line
      tempData.push(destinationOnDay);
      return destinationOnDay;
    });
    return day;
  });
  getRecusivePlaceDetail(
    placeService,
    DirectionsService,
    tempData,
    0,
    callback,
  );
};

/* Convert date to YYYY-MM-dd */
export const formatDateFormat = date => {
  if (date) {
    const day = new Date(date);
    return `${day.getFullYear()}-${day.getMonth() + 1 < 10
      ? `0${day.getMonth() + 1}`
      : day.getMonth() + 1}-${day.getDate() < 10
      ? `0${day.getDate()}`
      : day.getDate()}`;
  }
  return '';
};

/* Trim string */
export const trimStr = value => {
  if (value) {
    return value.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
  }
  return '';
};

/* Order list of plans */
export const oderListOfDestination = data => {
  let result = {};
  if (data) {
    const keys = Object.keys(data);
    /* Sort days in plan */
    keys.sort();
    keys.map(day => {
      const dataOfDay = data[day];
      /* Sort destination on day */
      if (dataOfDay) {
        dataOfDay.sort(function(a, b) {
          if (!a.start) {
            a.start = '09:00';
          }
          if (!b.start) {
            b.start = '09:00';
          }
          return a.start > b.start ? 1 : b.start > a.start ? -1 : 0;
        });
        result[day] = dataOfDay;
      }
      return day;
    });
  }
  return result;
};

/* Get startTime follow format zenrin */
export const formatStartTimeZenrin = (day, time) => {
  if (day && time) {
    let dayTemp = day;
    let timeTemp = time;
    while (dayTemp.indexOf('-') >= 0) {
      dayTemp = dayTemp.replace('-', '');
    }
    if (dayTemp.length < 8) {
      return '';
    }
    while (timeTemp.indexOf(':') >= 0) {
      timeTemp = timeTemp.replace(':', '');
    }
    if (timeTemp.length < 4) {
      return '';
    } else {
      timeTemp += '00';
    }
    return dayTemp + timeTemp;
  }
  return '';
};

/* export const convert GoogleMaps location to Zenrin location */
export const convertGoogleMapsToZenrinToRequest = location => {
  if (location) {
    return GoogleMapsZenrin.googleMapsToZenrin(location);
  }
  return null;
};

/* export const convert Zenrin location to GoogleMaps location */
export const convertZerinToGoogleMaps = location => {
  if (location) {
    const temp = {};
    if (typeof location.latitude === 'string') {
      temp.lat = Number(location.latitude);
    } else {
      temp.lat = location.latitude;
    }
    if (typeof location.longitude === 'string') {
      temp.lng = Number(location.longitude);
    } else {
      temp.lng = location.longitude;
    }
    return GoogleMapsZenrin.zenrinToGoogleMaps(temp);
  }
  return null;
};

/* export const convert GoogleMaps location to Zenrin location */
export const convertGoogleMapsToZenrin = location => {
  if (location) {
    const temp = {};
    if (typeof location.latitude === 'string') {
      temp.lat = Number(location.latitude);
    } else {
      temp.lat = location.latitude;
    }
    if (typeof location.longitude === 'string') {
      temp.lng = Number(location.longitude);
    } else {
      temp.lng = location.longitude;
    }
    return GoogleMapsZenrin.googleMapsToZenrin(temp);
  }
  return null;
};

/* export const convert List of Google-Location to Zenrin Location */
export const convertListOfGoogleMapsToZenrin = locations => {
  let result = [];
  if (locations) {
    locations.map(location => {
      const newLocation = convertGoogleMapsToZenrin(location);
      if (newLocation) {
        return result.push(newLocation);
      }
      return location;
    });
  }
  return result;
};

/* export const convert List of Zenrin-Location to Google-Maps Location */
export const convertListOfZenrinToGoogle = locations => {
  let result = [];
  if (locations) {
    locations.map(location => {
      const newLocation = convertZerinToGoogleMaps(location);
      if (newLocation) {
        result.push(newLocation);
      }
      return location;
    });
  }
  return result;
};

export const getColorRandom = () => {
  const colors = [
    '#5F9EA0',
    '#B22222',
    '#4169E1',
    '#337ab7',
    '#3fcd27',
    '#663399',
    '#FF4500',
    '#af9b0b',
    '#FF33ED',
    '#250DFF',
    '#800000',
    '#004d00',
    '#3c3c3c',
  ];
  const index = Math.floor(Math.random() * 12);
  return colors[index];
};

/*
 3 ??
 4 ?
 1 ??
 2 ??
 5 ???
 */
export const checkTransitType = type => {
  switch (type.code) {
    case '1':
      return {
        icon: NEW_ICON_TRANSIT.BUS,
        type: type.name,
      };
    case '2':
      return {
        icon: NEW_ICON_TRANSIT.RAIL,
        type: type.name,
      };
    case '3':
      return {
        icon: NEW_ICON_TRANSIT.WALK,
        type: type.name,
      };
    case '4':
      return {
        icon: NEW_ICON_TRANSIT.DRIVE,
        type: type.name,
      };
    default:
      return {
        icon: NEW_ICON_TRANSIT.AIR_PLANE,
        type: type.name,
      };
  }
};

export const getFormatInfoZenrin = value => {
  let result = `From ${value.startInfo.name} To ${value.endInfo.name}:`;
  const distance = value.distance;
  if (distance) {
    result = `${result} Distance is ${distance}m`;
  }
  return result;
};
