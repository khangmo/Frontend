/* eslint-disable import/prefer-default-export */

export const HOME = '/';
export const PLANS = '/plans';
export const PLACES = '/places';
export const MY_HOME = '/my/home';
export const MY_PROFILE = '/my/profile';
export const MY_PLAN = '/my/plans';
export const MY_WISHLIST_PLAN = '/my/plans/wishlist';
export const MY_PLACE = '/my/places';
export const MY_WISHLIST_PLACE = '/my/places/wishlist';
export const PLAN_ADD = '/plans/add';
export const PLACE_ADD = '/places/add';
export const PLAN_DESTINATION = '/plans/destination';
export const LOGIN = '/login';
export const SIGNUP = '/signup';
export const LOGOUT = '#';
export const SEARCH = '/search';
export const DESTINATION_EDIT = '/destination/edit';

/* URL of API Server */
export const API_VERSION = '/api/v1';
export const SAVE_NEW_PLAN = `${API_VERSION}/plans`;
export const GET_PLAN_DETAIL = `${API_VERSION}/plans`;

export const SAVE_PLACE = `${API_VERSION}/places`;

export const SAVE_DESTINATION = `${API_VERSION}/places`;
export const GET_DESTINATION_DETAIL = `${API_VERSION}/destination/detail/`;

export const GET_PLACE_DETAIL = `${API_VERSION}/places`;

export const REQUEST_TRANSIT_ZENRIN = `${API_VERSION}/transits`;
