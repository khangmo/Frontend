import React from 'react';
import { connect } from 'react-redux';
import Rater from 'react-rater';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
// import FaStartIcon from 'react-icons/lib/fa/star';
import SearchIcon from 'react-icons/lib/fa/search';
import cx from 'classnames';
import s from './Search.css';

import PlaceCondition from './placeCondition/PlaceCondition';
import PlanCondition from './planCondition/PlanCondition';
import SwitchCondition from './switchCondition/SwitchCondition';

class SearchAdvance extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showAdvanceSearch: false,
    };
    this.toggleSearch = this.toggleSearch.bind(this);
  }

  toggleSearch() {
    this.setState({
      showAdvanceSearch: !this.state.showAdvanceSearch,
    });
  }

  render() {
    let PrivateCondition = '';

    if (this.state.showAdvanceSearch === false) {
      PrivateCondition = <PlaceCondition />;
    } else {
      PrivateCondition = <PlanCondition />;
    }

    return (
      <div className={s.searchCriteriaWrapper}>
        <div className={s.searchConditionRegion}>
          <div className="row">
            <div className="col-xs-12">
              <div className={cx('form-group', s.switchToogle)}>
                <SwitchCondition
                  isChecked={true}
                  onChange={this.toggleSearch}
                />
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-xs-12">
              <div>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                />
              </div>
            </div>
          </div>
          <div className={cx('row', s.searchCondition)}>
            <div className="col-xs-10">
              <label>Where to</label>
            </div>
            <div className="col-xs-2 text-right">
              <span
                className="glyphicon glyphicon-chevron-up accordion-toggle"
                data-toggle="collapse"
                data-parent="#accordion2"
                href="#collapseWhere"
              />
            </div>
          </div>
          <div
            id="collapseWhere"
            className={cx(s.accordionBody, s.collapseWhere, 'collapse in')}
          >
            <div className={cx('row', s.whereToCondition)}>
              <div className="col-sm-10 col-xs-5">
                <div className={s.whereToItem}>
                  <select className="form-control city-provice">
                    <option>- Area -</option>
                    <option>Toyota</option>
                    <option>Toyokawa</option>
                    <option>Kariya</option>
                    <option>Nagoya</option>
                  </select>
                </div>
              </div>
              <div className="col-sm-2 text-right">
                <i className="fa fa-plus" aria-hidden="true" />
              </div>
            </div>
          </div>

          {PrivateCondition}

          <div className={cx('row', s.searchCondition)}>
            <div className="col-xs-10">
              <label>Rating</label>
            </div>
            <div className="col-xs-2 text-right">
              <span
                className="glyphicon glyphicon-chevron-up accordion-toggle"
                data-toggle="collapse"
                data-parent="#accordion2"
                href="#collapseRating"
              />
            </div>
          </div>
          <div
            id="collapseRating"
            className={cx(s.accordionBody, s.ratingCondition, 'collapse in')}
          >
            <div className="criteria-content-select rating">
              <Rater />
            </div>
          </div>

          <div className="row">
            <div className="col-xs-12">
              <div className="form-group">
                <button
                  type="button"
                  className={cx(
                    'btn btn-default',
                    s.btnIcon,
                    s.btnSave,
                    s.searchButton,
                  )}
                >
                  <span className={cx('glyphicon', s.glyphicon)}>
                    <SearchIcon />
                  </span>
                  <span>Search</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapState = state => ({
  user: state.user,
});

export default connect(mapState)(withStyles(s)(SearchAdvance));
