/**
 * Search advance button 
 * Have just display on table and mobile devices
 */

import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from './Search.css';

class SearchSelected extends React.Component {
  render() {
    return (
      <div className="yourSelected">
        <span className="yourSelectedTitle text-uppercase">Your selected</span>
        <a className="btnClearAll text-right">Clear all</a>
        <div className="row title-padding">
          <div className="col-xs-12 col-sm-6 col-md-4 yourSelectedItem">
            <div className="checkbox">
              <label>
                <input type="checkbox" checked /> Tokyo
              </label>
            </div>
          </div>

          <div className="col-xs-12 col-sm-6 col-md-4 yourSelectedItem">
            <div className="checkbox">
              <label>
                <input type="checkbox" checked /> 1 day - 3 days
              </label>
            </div>
          </div>

          <div className="col-xs-12 col-sm-6 col-md-4 yourSelectedItem">
            <div className="checkbox">
              <label>
                <input type="checkbox" checked />
                <span>
                  <i className="fa fa-star" aria-hidden="true" />
                  <i className="fa fa-star" aria-hidden="true" />
                  <i className="fa fa-star" aria-hidden="true" />
                  <i className="fa fa-star" aria-hidden="true" />
                </span>
              </label>
            </div>
          </div>

          <div className="col-xs-12 col-sm-6 col-md-4 yourSelectedItem">
            <div className="checkbox">
              <label>
                <input type="checkbox" checked />
                <span>
                  <i className="fa fa-star" aria-hidden="true" />
                  <i className="fa fa-star" aria-hidden="true" />
                </span>
              </label>
            </div>
          </div>

          <div className="col-xs-12 col-sm-6 col-md-4 yourSelectedItem">
            <div className="checkbox">
              <label>
                <input type="checkbox" checked /> My wish list places
              </label>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(SearchSelected);
