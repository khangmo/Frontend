import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from '../Search.css';

class SwitchCondition extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isChecked: null,
    };
    this._handleChange = this._handleChange.bind(this);
  }

  componentWillMount() {
    this.setState({ isChecked: this.props.isChecked });
  }

  render() {
    return (
      <div className={s.switchContainer}>
        <label>
          <input
            ref="switch"
            checked={this.state.isChecked}
            onChange={this._handleChange}
            className={s.switch}
            type="checkbox"
          />
          <div className={s.switchContainer}>
            <span className={s.placeLable}>
              <g className={cx(s.icon, s.iconToolbar, s.gridView)} />Place
            </span>
            <span className={s.planLable}>
              <g className={cx(s.icon, s.iconToolbar, s.ticketView)} />Plan
            </span>
            <div />
          </div>
        </label>
      </div>
    );
  }

  _handleChange() {
    this.setState({ isChecked: !this.state.isChecked });
    this.props.onChange();
  }
}

export default withStyles(s)(SwitchCondition);
