/**
 * Search advance button 
 * Have just display on table and mobile devices
 */

import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from './Search.css';

class SearchAdvanceButton extends React.Component {
  render() {
    return (
      <button
        type="button"
        className={cx(
          'btn btn-default',
          s.btnIcon,
          s.searchAdvanceBtn,
          s.hideSearchAdvance,
        )}
      >
        <span>Advance search</span>
        <span
          className={cx(
            'glyphicon glyphicon-circle-arrow-right pull-right',
            s.searchAdvancedIcon,
          )}
        />
      </button>
    );
  }
}

export default withStyles(s)(SearchAdvanceButton);
