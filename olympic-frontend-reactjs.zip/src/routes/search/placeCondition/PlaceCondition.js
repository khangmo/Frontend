import React from 'react';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from '../Search.css';

class PlaceCondition extends React.Component {
  render() {
    let placeCondition = '';
    if (this.props.user.user === null) {
      placeCondition = (
        <div className={cx('criteria-content-select', s.places)}>
          <div className={cx('radio', s.radio)}>
            <label>
              <input type="radio" name="placeOption" />All places
            </label>
          </div>
        </div>
      );
    } else {
      placeCondition = (
        <div className={cx('criteria-content-select', s.places)}>
          <div className={cx('radio', s.radio)}>
            <label>
              <input type="radio" name="placeOption" />My places
            </label>
          </div>
          <hr />
          <div className={cx('radio', s.radio)}>
            <label>
              <input type="radio" name="placeOption" />My wish list places
            </label>
          </div>
          <hr />
          <div className={cx('radio', s.radio)}>
            <label>
              <input type="radio" name="placeOption" />All places
            </label>
          </div>
        </div>
      );
    }

    return (
      <div className={s.privatePlaceCondition}>
        <div className={cx('row', s.searchCondition)}>
          <div className="col-xs-10">
            <label>Type of place</label>
          </div>
          <div className="col-xs-2 text-right">
            <span
              className="glyphicon glyphicon-chevron-up accordion-toggle"
              data-toggle="collapse"
              data-parent="#accordion2"
              href="#typeOfPlace"
            />
          </div>
        </div>

        <div className="privatePlaceCondition">
          <div id="typeOfPlace" className={cx(s.accordionBody, 'collapse in')}>
            <div className="row">
              <div className="col-xs-10 col-sm-10">
                <select id="typeOfPlace" className="form-control">
                  <option value="0">- Type -</option>
                  <option value="1">Airport</option>
                  <option value="2">Amusement park</option>
                  <option value="3">ATM</option>
                  <option value="4">Bar</option>
                  <option value="5">Cafe</option>
                  <option value="6">Campground</option>
                  <option value="7">City hall</option>
                  <option value="8">Gas station</option>
                  <option value="9">Liquor store</option>
                  <option value="10">Lodging</option>
                  <option value="11">Meal takeaway</option>
                  <option value="12">Night club</option>
                  <option value="13">Park</option>
                  <option value="14">Parking</option>
                  <option value="15">Restaurant</option>
                  <option value="16">Shopping mall</option>
                  <option value="17">Taxi stand</option>
                  <option value="18">Train station</option>
                  <option value="19">Travel agency</option>
                  <option value="20">Zoo</option>
                </select>
              </div>
            </div>
          </div>

          <div className={cx('row', s.searchCondition, s.searchByPlan)}>
            <div className="col-xs-10">
              <label>Search in</label>
            </div>
            <div className="col-xs-2 text-right">
              <span
                className="glyphicon glyphicon-chevron-up accordion-toggle"
                data-toggle="collapse"
                data-parent="#accordion2"
                href="#collapsePlace"
              />
            </div>
          </div>
          <div
            id="collapsePlace"
            className={cx(s.accordionBody, 'collapse in')}
          >
            {placeCondition}
          </div>
        </div>
      </div>
    );
  }
}

const mapState = state => ({
  user: state.user,
});

export default connect(mapState)(withStyles(s)(PlaceCondition));
