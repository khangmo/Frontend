import React from 'react';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from '../Search.css';

class PlanCondition extends React.Component {
  render() {
    let planCondition = '';
    if (this.props.user.user === null) {
      planCondition = (
        <div className={cx('criteria-content-select', s.plans)}>
          <div className={cx('radio', s.radio)}>
            <label>
              <input type="radio" name="planOption" />All plans
            </label>
          </div>
        </div>
      );
    } else {
      planCondition = (
        <div className={cx('criteria-content-select', s.plans)}>
          <div className={cx('radio', s.radio)}>
            <label>
              <input type="radio" name="planOption" />My plans
            </label>
          </div>
          <hr />
          <div className={cx('radio', s.radio)}>
            <label>
              <input type="radio" name="planOption" />My wish list plans
            </label>
          </div>
          <hr />
          <div className={cx('radio', s.radio)}>
            <label>
              <input type="radio" name="planOption" />All plans
            </label>
          </div>
        </div>
      );
    }

    return (
      <div className={s.privatePlaceCondition}>
        <div className={cx('row', s.searchCondition)}>
          <div className="col-xs-10">
            <label>Time</label>
          </div>
          <div className="col-xs-2 text-right">
            <span
              className="glyphicon glyphicon-chevron-up accordion-toggle"
              data-toggle="collapse"
              data-parent="#accordion2"
              href="#collapseTime"
            />
          </div>
        </div>
        <div id="collapseTime" className={cx(s.accordionBody, 'collapse in')}>
          <div className="row duration">
            <div className="col-xs-7 col-sm-10">
              <select className="form-control">
                <option>- Duration -</option>
                <option>1 day - 3 days</option>
                <option>4 day - 6 days</option>
                <option>2 week</option>
              </select>
            </div>
          </div>
        </div>

        <div className={cx('row', s.searchCondition, s.searchByPlace)}>
          <div className="col-xs-10">
            <label>Search in</label>
          </div>
          <div className="col-xs-2 text-right">
            <span
              className="glyphicon glyphicon-chevron-up accordion-toggle"
              data-toggle="collapse"
              data-parent="#accordion2"
              href="#collapsePlan"
            />
          </div>
        </div>
        <div id="collapsePlan" className={cx(s.accordionBody, 'collapse in')}>
          {planCondition}
        </div>
      </div>
    );
  }
}

const mapState = state => ({
  user: state.user,
});

export default connect(mapState)(withStyles(s)(PlanCondition));
