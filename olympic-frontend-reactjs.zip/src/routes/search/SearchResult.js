/**
 * Search result screen
 */

import React from 'react';
import Rater from 'react-rater';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from './Search.css';

import SearchAdvanceButton from './SearchAdvanceButton';
import SearchAdvance from './SearchAdvance';
import SearchSelected from './SearchSelected';

import results from './results.json';

class SearchResult extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      results: results.results,
      showAdvanceSearch: false,
    };
    this.toggleSearch = this.toggleSearch.bind(this);
  }

  toggleSearch() {
    this.setState({
      showAdvanceSearch: !this.state.showAdvanceSearch,
    });
  }

  render() {
    return (
      <div className={cx(s.mainContentWrapper, s.searchResultWrapper)}>
        <div className="container">
          <div className="row">
            <div
              className={cx(
                'col-xs-12 text-center',
                s.searchAdvanceButton,
                this.state.showAdvanceSearch
                  ? s.showAdvanceSearch
                  : s.hideAdvanceSearch,
              )}
              onClick={this.toggleSearch}
            >
              <SearchAdvanceButton />
            </div>
          </div>
          <div className={cx('row', s.searchMainContent)}>
            <div
              className={cx(
                'col-xs-12 col-sm-12 col-md-3',
                s.sidebarLeft,
                s.searchAdvance,
                s.hideSearchAdvance,
                this.state.showAdvanceSearch
                  ? s.showAdvanceSearch
                  : s.hideAdvanceSearch,
              )}
            >
              <SearchAdvance />
            </div>
            <div
              className={cx('col-xs-12 col-sm-12 col-md-9', s.searchContent)}
            >
              <div className="row">
                {Object.values(this.state.results).map((result, index) => {
                  return (
                    <div
                      key={index}
                      className={cx('col-md-4 col-sm-4 col-xs-12', s.itemList)}
                    >
                      <a href={result.url}>
                        <div className={s.itemListImage}>
                          <img
                            className="thumbnail"
                            src={result.image}
                            alt=""
                          />
                        </div>
                      </a>
                      <div className={s.itemListSumary}>
                        <span className={s.itemListTitle}>
                          {result.title}
                        </span>
                        <div className={s.itemListDescription}>
                          <span>
                            {result.location}
                          </span>
                        </div>
                      </div>
                      <Rater
                        className="react-rater notChoose"
                        rating={parseInt(result.rating, 10)}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

SearchResult.propTypes = {
  userAgent: PropTypes.object, // eslint-disable-line
};

const mapStateToProps = state => ({ userAgent: state.userAgent.userAgent });

export default connect(mapStateToProps)(withStyles(s)(SearchResult));
