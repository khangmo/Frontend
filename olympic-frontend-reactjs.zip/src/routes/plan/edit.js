/**
 * Created by KhangNT on 8/17/2017.
 */
import React from 'react';
import EditPlan from './EditPlan';
import Layout from '../../components/Layout';

import { PLANS } from '../../common/path';

export default {
  path: `${PLANS}/edit`,

  async action() {
    const title = 'Edit plan';
    return {
      title: 'Edit plan',
      component: (
        <Layout>
          <EditPlan title={title} />
        </Layout>
      ),
    };
  },
};
