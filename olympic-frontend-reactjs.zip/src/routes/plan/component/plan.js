/**
 * Created by KhangNT on 7/4/2017.
 */
import {  //eslint-disable-line
  getColorRandom,
  formatStartTimeZenrin,
  convertListOfZenrinToGoogle,
  convertGoogleMapsToZenrinToRequest,
} from '../../../common/common';

export const genTransitZenrin = (postZenrin, destinations, callback, day) => {
  if (!destinations || destinations.length === 1) {
    return;
  }
  const color = getColorRandom();
  for (let i = 0; i < destinations.length; i++) {
    if (i > 0) {
      if (!destinations[i - 1].map || !destinations[i].map) {
        return;
      }
      /* Convert to Zenrin Location */
      const startZenrin = convertGoogleMapsToZenrinToRequest({
        lat: destinations[i - 1].map.location.lat(),
        lng: destinations[i - 1].map.location.lng(),
      });
      const endZenrin = convertGoogleMapsToZenrinToRequest({
        lat: destinations[i].map.location.lat(),
        lng: destinations[i].map.location.lng(),
      });

      const startTime = formatStartTimeZenrin(day, destinations[i].startTime);
      /* Call API Zenrin */
      const dataPostToZenrin = {
        start: {
          latitude: startZenrin.lat,
          longitude: startZenrin.lng,
        },
        end: {
          latitude: endZenrin.lat,
          longitude: endZenrin.lng,
        },
        startTime,
        endTime: startTime,
        transitType: destinations[i - 1].transit.transitType || 'other',
      };

      if (startZenrin && endZenrin) {
        postZenrin(dataPostToZenrin, response => {
          if (Object.prototype.hasOwnProperty.call(response, 'totalTime')) {
            const finalResult = {
              path: convertListOfZenrinToGoogle(response.sections),
              color,
              response: response,
              day,
            };
            callback({ direction: finalResult, color }, day);
          } else {
            bootbox.alert('No way in zenrin.'); //eslint-disable-line
          }
        });
      }
    }
  }
};

export const genDirections = (
  DirectionsService,
  destinations,
  callback,
  day,
) => {
  if (!destinations || destinations.length === 1) {
    return;
  }
  const color = getColorRandom();
  for (let i = 0; i < destinations.length; i++) {
    if (i > 0) {
      if (!destinations[i - 1].map || !destinations[i].map) {
        return;
      }
      const originMarker = new google.maps.LatLng(
        destinations[i - 1].map.location.lat(), //eslint-disable-line
        destinations[i - 1].map.location.lng(),
      );
      const destinationMarker = new google.maps.LatLng(
        destinations[i].map.location.lat(), //eslint-disable-line
        destinations[i].map.location.lng(),
      );
      if (originMarker) {
        DirectionsService.route(
          {
            origin: originMarker,
            destination: destinationMarker,
            travelMode: destinations[i].transit.transitType,
          },
          (response, status) => {
            if (status === 'OK') {
              callback(
                {
                  direction: response,
                  color,
                },
                day,
              );
            } else {
              console.log(
                `No road from ${destinations[i - 1].title} to ${destinations[i]
                  .title}`,
              ); //eslint-disable-line
            }
          },
        );
      }
    }
  }
};
