/**
 * Created by KhangNT on 7/6/2017.
 */
import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Rater from 'react-rater';
import { getRandomPhoto } from '../../../../common/common';
import cx from 'classnames';

import s from './Title.css';

class Title extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      defaultAvatar: '/images/demo.jpg',
    };
  }
  componentWillMount() {}

  render() {
    const { plan } = this.props;
    const rating = Number(plan.ratingAverage);
    return (
      <div className={cx('title', s.planConent)}>
        <div className="row">
          <div className="col-xs-12 col-sm-6 col-md-6">
            <img
              className="thumbnail"
              src={plan.avatar || this.state.defaultAvatar}
              alt={plan.title}
            />
          </div>
          <div className="col-xs-12 col-sm-6 col-md-6">
            <div className="row">
              <div className="col-xs-6 col-sm-4 col-md-3">
                <div className="pull-left">
                  <label htmlFor="View for Start Date">Start date</label>
                </div>
              </div>
              <div className="col-xs-6 col-sm-8 col-md-9">
                {plan.startDate}
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-6 col-sm-4 col-md-3">
                <div className="pull-left">
                  <label htmlFor="View for End Date">End date</label>
                </div>
              </div>
              <div className="col-xs-6 col-sm-8 col-md-9">
                {plan.endDate}
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-6 col-sm-4 col-md-3">
                <div className="pull-left">
                  <label htmlFor="View for Duration">Duration</label>
                </div>
              </div>
              <div className="col-xs-6 col-sm-8 col-md-9">
                {plan.duration}
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-6 col-sm-4 col-md-3">
                <div className="pull-left">
                  <label htmlFor="View for Rating">Rating</label>
                </div>
              </div>
              <div className="col-xs-6 col-sm-8 col-md-9">
                <Rater
                  className="react-rater notChoose"
                  interactive={false}
                  rating={rating}
                />
              </div>
            </div>
            <div className={s.divide} />
          </div>
        </div>
        <div className="row">
          <div className="col-xs-12">
            <div className="form-group">
              <label htmlFor="View for Summary">Summary</label>
              <p>
                {plan.summary}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(Title);
