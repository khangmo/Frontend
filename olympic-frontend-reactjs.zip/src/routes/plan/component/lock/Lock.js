/**
 * Created by KhangNT on 8/18/2017.
 */
import React from 'react'; //eslint-disable-line
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import s from './Lock.css'; //eslint-disable-line
import FaLock from 'react-icons/lib/fa/lock';
import FaUnLock from 'react-icons/lib/fa/unlock';
import FaTrash from 'react-icons/lib/fa/trash';
import FaPlus from 'react-icons/lib/fa/plus';
import FaTrain from 'react-icons/lib/fa/train';

import { NEW_ICON_TRANSIT } from '../../../../constants/icons';

class Lock extends React.Component {
  constructor(props) {
    super(props);
    this.onLock = this.onLock.bind(this);
    this.onUnLock = this.onUnLock.bind(this);
  }

  onLock = destinationId => {
    $(`#unlock-${destinationId}`).hide();
    $(`#lock-${destinationId}`).show();
    $(`#${destinationId}`).removeClass('for-moving');
    this.props.updateLockOrUnLock(destinationId, true);
  };

  onUnLock = destinationId => {
    $(`#lock-${destinationId}`).hide();
    $(`#unlock-${destinationId}`).show();
    $(`#${destinationId}`).addClass('for-moving');
    this.props.updateLockOrUnLock(destinationId, false);
  };

  render() {
    const { index } = this.props;
    return (
      <div className={s.position}>
        <div
          className="btn-group btn-toggle btn-group-sm"
          style={{ display: 'flex' }}
        >
          <div style={{}} className="dropdown change-transit-component">
            <button
              className="btn btn-primary dropdown-toggle btn-sm"
              id={`${index}-1`}
              style={{
                borderBottomLeftRadius: 0,
                borderBottomRightRadius: 0,
                borderTopRightRadius: 0,
              }}
              data-toggle="dropdown"
            >
              <FaTrain />
            </button>
            <ul
              className="dropdown-menu"
              style={{
                left: '-140px',
                zIndex: '2',
                top: '-3px',
                minWidth: '140px',
              }}
            >
              <li style={{ padding: '0px' }}>
                <a
                  onClick={this.props.selectTransit.bind(this, {
                    destinationId: this.props.destinationId,
                    transitType: 'walk',
                  })}
                >
                  <img
                    src={NEW_ICON_TRANSIT.WALK}
                    style={{
                      height: '20px',
                      width: '20px',
                      marginRight: '10px',
                    }}
                    alt="Walk"
                  />Walk
                </a>
              </li>
              <li className="divider" style={{ padding: '0px' }} />
              <li style={{ padding: '0px' }}>
                <a
                  onClick={this.props.selectTransit.bind(this, {
                    destinationId: this.props.destinationId,
                    transitType: 'drive',
                  })}
                >
                  <img
                    src={NEW_ICON_TRANSIT.DRIVE}
                    style={{
                      height: '20px',
                      width: '20px',
                      marginRight: '10px',
                    }}
                    alt="Drive"
                  />Drive
                </a>
              </li>
              <li className="divider" style={{ padding: '0px' }} />
              <li style={{ padding: '0px' }}>
                <a
                  onClick={this.props.selectTransit.bind(this, {
                    destinationId: this.props.destinationId,
                    transitType: 'other',
                  })}
                >
                  <img
                    src={NEW_ICON_TRANSIT.RAIL}
                    style={{
                      height: '20px',
                      width: '20px',
                      marginRight: '10px',
                    }}
                    alt="Other"
                  />Other
                </a>
              </li>
            </ul>
          </div>
          <button
            className="btn btn-success"
            id={`${index}-1`}
          >
            <FaPlus />
          </button>
          <button
            className="btn btn-primary"
            id={`unlock-${this.props.destinationId}`}
            onClick={this.onLock.bind(this, this.props.destinationId)}
          >
            <FaUnLock />
          </button>
          <button
            className="btn btn-danger"
            id={`lock-${this.props.destinationId}`}
            onClick={this.onUnLock.bind(this, this.props.destinationId)}
            style={{
              borderTopRightRadius: 0,
              display: 'none',
            }}
          >
            <FaLock />
          </button>
          <button
            className="btn btn-danger"
            id={`${index}-1`}
            onClick={this.props.delete.bind(this, this.props.destinationId)}
            style={{
              borderTopRightRadius: 0,
            }}
          >
            <FaTrash />
          </button>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(Lock);
