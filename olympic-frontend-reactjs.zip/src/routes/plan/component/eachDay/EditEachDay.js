/**
 * Created by KhangNT on 8/17/2017.
 */
import React from 'react'; //eslint-disable-line
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import s from './EachDay.css'; //eslint-disable-line
import EditItem from './item/EditItem';
import { connect } from 'react-redux';

class EditEachDay extends React.Component {
  componentWillMount() {}

  render() {
    const { planEdit } = this.props;
    const days = planEdit ? Object.keys(planEdit) : [];
    return (
      <div className="schedule">
        {days.map((day, index) =>
          <div className="row" key={index.toString()}>
            <div className="col-xs-12">
              <div
                className="panel panel-default"
                style={{ marginLeft: '15px', marginRight: '15px' }}
              >
                <div className="panel-heading">
                  <h4 className="panel-title">
                    {day}
                  </h4>
                </div>
                <div
                  className="panel-body"
                  style={{ backgroundColor: '#f0f0f0' }}
                >
                  <EditItem day={day} />
                </div>
              </div>
            </div>
          </div>,
        )}
      </div>
    );
  }
}

const mapState = state => ({
  loading: state.plans.loading,
  planDetail: state.plans.plan,
  planEdit: state.editPlan.planEdit,
});

const mapDispatch = {};

export default connect(mapState, mapDispatch)(withStyles(s)(EditEachDay));
