/**
 * Created by KhangNT on 8/17/2017.
 */
import React from 'react'; //eslint-disable-line
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import s from './Item.css'; //eslint-disable-line
import { connect } from 'react-redux';
import EditDestination from './Destination/EditDestination';
import editPlan from '../../../../../actions/plan/edit';
import postZenrin from '../../../../../actions/plan/postZenrin';
import ChangeTransit from '../../../../../components/plan/ChangeTransit';

class Item extends React.Component {
  constructor(props) {
    super(props);
    this.callback = this.callback.bind(this);
    this.updateDragDropAction = this.updateDragDropAction.bind(this);
    this.getChildByChildIdOrOldParent = this.getChildByChildIdOrOldParent.bind(
      this,
    );
    this.move = this.move.bind(this);
    this.delete = this.delete.bind(this);
    this.getIndexElement = this.getIndexElement.bind(this);
    this.getOldIndex = this.getOldIndex.bind(this);
    this.convertToDataPostZenrin = this.convertToDataPostZenrin.bind(this);
    this.convertToDataStore = this.convertToDataStore.bind(this);
    this.selectTransit = this.selectTransit.bind(this);
    this.updateLockOrUnLock = this.updateLockOrUnLock.bind(this);
  }
  componentWillMount() {}

  getChildByChildIdOrOldParent = (childId, isChild) => {
    let result = null;
    const dataStore = this.props.planEdit;
    if (dataStore) {
      const keys = Object.keys(dataStore);
      keys.map(key => {
        if (result) {
          return result;
        }
        dataStore[key].map(destination => {
          if (childId === destination.destinationId) {
            if (isChild) {
              return (result = destination);
            } else {
              return (result = key);
            }
          }
        });
      });
    }
    return result;
  };

  getIndexElement = element => {
    if (element) {
      const parent = element.parentNode;
      const allChild = parent.children;
      for (let i = 0; i < allChild.length; i++) {
        if (element.isSameNode(allChild[i])) {
          return i;
        }
      }
    }
    return -1;
  };

  getOldIndex = (childId, parents) => {
    let result = -1;
    if ((childId, parents)) {
      parents.map((parent, index) => {
        if (parent.destinationId === childId) {
          return (result = index);
        }
      });
    }
    return result;
  };

  move = (oldIndex, newIndex, arr) => {
    if (newIndex >= arr.length) {
      let k = newIndex - arr.length;
      while (k-- + 1) {
        arr.push(undefined);
      }
    }
    arr.splice(newIndex, 0, arr.splice(oldIndex, 1)[0]);
    return arr; // for testing purposes
  };

  updateDragDropAction = (index, parentId, childId) => {
    let dataAfterChange = this.props.planEdit;
    const data = this.props.planEdit;

    /* Get the element has been moving */
    const childMoved = this.getChildByChildIdOrOldParent(childId, true);
    const oldParentId = this.getChildByChildIdOrOldParent(childId, false);

    /* Check if moving out of class */
    if (oldParentId === parentId) {
      /* Moving within a class then change the position for this element */
      const oldIndex = this.getOldIndex(childId, data[oldParentId]);
      dataAfterChange[parentId] = this.move(oldIndex, index, data[oldParentId]);
    } else {
      /* Moving out of class then update data of element has been moving to dataStore */
      const currentParent = data[parentId];
      childMoved.date = parentId;
      childMoved.startDate = parentId;
      currentParent.splice(index, 0, childMoved);
      dataAfterChange[parentId] = currentParent;

      /* Remove childMove from oldChild */
      const oldParent = data[oldParentId];
      oldParent.map((child, index) => {
        if (child.destinationId === childId) {
          return oldParent.splice(index, 1);
        }
      });
      dataAfterChange[oldParentId] = oldParent;
    }
    return dataAfterChange;
  };

  callback = item => {
    const index = this.getIndexElement(item);
    const parentId = item.parentNode.id;
    const childId = item.id;
    let dataAfterMoved = this.updateDragDropAction(index, parentId, childId);
    this.props.postZenrin(
      this.convertToDataPostZenrin(dataAfterMoved),
      response => {
        const dataMovedSuccess = this.convertToDataStore(response);
        // this.props.editPlan(this.convertToDataStore(response));
        const keys = Object.keys(dataMovedSuccess);
        keys.map(key => {
          dataAfterMoved[key] = dataMovedSuccess[key];
          dataAfterMoved[key].map(item => {
            $(`#start-time-${item.destinationId}`)
              .empty()
              .append(` ${item.startTime}`);
            if (item.invalid) {
              $(`#boundary-${item.destinationId}`).css({
                border: '1px solid #c5c6c7',
              });
            } else {
              $(`#boundary-${item.destinationId}`).css({
                border: '1px solid #ef0404',
              });
            }
          });
        });
        this.props.editPlan(dataAfterMoved);
      },
    );
  };

  convertToDataPostZenrin = input => {
    let output = {
      plan: [],
    };
    const keys = Object.keys(input);
    keys.map(key => {
      return output.plan.push({
        date: key,
        destinations: input[key],
      });
    });
    return output;
  };

  convertToDataStore = input => {
    let result = {};
    const plans = input.plan;
    plans.map(plan => {
      return (result[plan.date] = plan.destinations);
    });
    return result;
  };

  updateLockOrUnLock = (destinationId, isLock) => {
    const dataStore = this.props.planEdit;
    if (dataStore) {
      const keys = dataStore ? Object.keys(dataStore) : [];
      keys.map(key => {
        dataStore[key].map(destination => {
          if (destinationId === destination.destinationId) {
            destination.lock = isLock;
            this.props.editPlan(dataStore);
            return isLock;
          }
        });
      });
    }
  };

  componentDidMount() {
    Sortable.create(document.getElementById(this.props.day), {
      handle: '.for-moving',
      group: 'world',
      animation: 150,
      onEnd: evt => {
        this.callback(evt.item);
      },
    });
  }

  delete = destinationId => {
    bootbox.confirm('Are you sure?', result => {
      if (result) {
        const dataStore = this.props.planEdit;
        if (dataStore) {
          const keys = dataStore ? Object.keys(dataStore) : [];
          keys.map((key, index) => {
            dataStore[key].map(destination => {
              if (destinationId === destination.destinationId) {
                return dataStore[key].splice(index, 1);
              }
            });
          });
          this.props.editPlan(dataStore);
          $(`#${destinationId}`).remove();
        }
      }
    });
  };

  selectTransit(transit) {
    const childId = transit.destinationId;
    const newTransitType = transit.transitType;
    const dataStore = this.props.planEdit;
    if (dataStore) {
      const keys = Object.keys(dataStore);
      keys.map(key => {
        dataStore[key].map(destination => {
          if (childId === destination.destinationId) {
            const currentType = destination.transit.transitType;
            if (newTransitType !== currentType) {
              destination.transit.transitType = newTransitType;
              this.props.editPlan(dataStore);
            }
          }
        });
      });
    }
  }

  render() {
    const { day } = this.props;
    const dataOnDay = this.props.planEdit[day];
    return (
      <ul className="schedule block__list block__list_words" id={day}>
        {dataOnDay.map((data, index) =>
          <li
            className="eachDay for-moving"
            id={data.destinationId}
            key={index}
          >
            <div className="item">
              <div className="row" style={{ marginTop: '10px' }}>
                <div className="col-xs-12">
                  <EditDestination
                    data={data}
                    selectTransit={this.selectTransit}
                    day={day}
                    updateLockOrUnLock={this.updateLockOrUnLock}
                    delete={this.delete}
                  />
                </div>
              </div>
            </div>
          </li>,
        )}
      </ul>
    );
  }
}

const mapState = state => ({
  planEdit: state.editPlan.planEdit,
});

const mapDispatch = {
  editPlan,
  postZenrin,
};

export default connect(mapState, mapDispatch)(withStyles(s)(Item));
