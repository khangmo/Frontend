/**
 * Created by KhangNT on 7/5/2017.
 */
import React from 'react'; //eslint-disable-line
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import FaPlus from 'react-icons/lib/fa/plus-circle';
import s from './Item.css'; //eslint-disable-line
import Destinations from './Destination/Destinations';
import Direction from './Direction/Direction';

class Item extends React.Component {
  componentWillMount() {}

  render() {
    const { dataOnDay } = this.props;
    const { directionOnDay } = this.props;
    const { day } = this.props;
    return (
      <div className="schedule">
        {dataOnDay.map((data, index) =>
          <div className="eachDay" key={index.toString()}>
            {directionOnDay && directionOnDay[index]
              ? <div className="item">
                  <div className="row" style={{ marginTop: '3px' }}>
                    <div className="col-xs-2">
                      <button
                        data-toggle="collapse"
                        data-target={`#${day}-${index}`}
                        className="btn"
                        style={{
                          marginLeft: '10px',
                          borderRadius: '50%',
                          padding: '0 0',
                          marginTop: '25px',
                        }}
                      >
                        <FaPlus
                          style={{
                            width: '30px',
                            height: '30px',
                            color: 'white',
                          }}
                        />
                      </button>
                    </div>
                    <div className="col-xs-10">
                      <Destinations data={data} />
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-xs-2" />
                    <div className="col-xs-10">
                      <div className="out collapse" id={`${day}-${index}`}>
                        <Direction data={directionOnDay[index]} />
                      </div>
                    </div>
                  </div>
                </div>
              : <div className="item">
                  <div className="row" style={{ marginTop: '3px' }}>
                    <div className="col-xs-2" />
                    <div className="col-xs-10">
                      <Destinations data={data} />
                    </div>
                  </div>
                  <div className={s.divide} />
                </div>}
          </div>,
        )}
      </div>
    );
  }
}

export default withStyles(s)(Item);
