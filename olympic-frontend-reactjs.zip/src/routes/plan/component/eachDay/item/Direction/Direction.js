/**
 * Created by KhangNT on 7/5/2017.
 */
import React from 'react'; //eslint-disable-line
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import {
  checkTransitType,
  getFormatInfoZenrin,
} from '../../../../../../common/common';
import s from './Direction.css'; //eslint-disable-line
class Direction extends React.Component {
  render() {
    if (
      !this.props.data ||
      !Object.prototype.hasOwnProperty.call(this.props.data, 'direction')
    ) {
      return <div />;
    }
    const direction = this.props.data.direction;
    if (
      !direction ||
      !Object.prototype.hasOwnProperty.call(direction, 'response')
    ) {
      return <div />;
    }
    const response = direction.response;
    if (!response || !Object.prototype.hasOwnProperty.call(response, 'nodes')) {
      return <div />;
    }
    const nodes = response.nodes; //eslint-disable-line
    if (!nodes) {
      return <div />;
    }
    const title = `Distance ${response.distance}m in ${response.totalTime} minutes`;
    let listItems = [];
    Object.values(nodes).map((node, index) => {
      const transitType = checkTransitType(node.nodeType);
      const formatText = getFormatInfoZenrin(node);
      return listItems.push(
        <div
          className="list-group-item"
          style={{
            padding: '5px 2px',
            fontSize: '11px',
            border: '1px solid #f3f3f3',
          }}
          key={index}
        >
          <img src={transitType.icon} width="20" high="20"/>
          {`  ${formatText}`}
        </div>,
      );
    });
    const valueHtml = (
      <div
        className="timeline-panel"
        style={{
          padding: '5px 5px',
          border: '1px solid #d4d4d4',
          borderRadius: '5px',
          backgroundColor: '#f5f5f5',
          marginRight: '15px',
          marginLeft: '30px',
          marginTop: '5px',
          marginBottom: '5px',
        }}
      >
        <div
          className="timeline-heading"
          style={{
            backgroundColor: 'rgb(228, 228, 228)',
            borderRadius: '3px',
          }}
        >
          <div className="timeline-title" style={{padding: '5px 5px'}}>
            {title}
          </div>
        </div>
        <div className="timeline-body">
          <div className="list-group" style={{margin: '2px 0px'}}>
            {listItems}
          </div>
        </div>
      </div>
    );
    return (
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-12">
          <div
            className="row"
            style={{marginRight: '0px', marginLeft: '0px'}}
          >
            {valueHtml}
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(Direction);
