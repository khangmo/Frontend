/**
 * Created by KhangNT on 7/5/2017.
 */
import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import history from '../../../../../../history';
import s from './Destination.css';

class Destinations extends React.Component {
  constructor(props) {
    super(props);
    this.viewDestination = this.viewDestination.bind(this);
    this.viewPlace = this.viewPlace.bind(this);
  }

  viewDestination = destinationId => {
    history.push(`/destination/detail/${destinationId}`);
  };

  viewPlace = placeId => {
    history.push(`/places/${placeId}`);
  };

  render() {
    const { data } = this.props; //eslint-disable-line
    let stay = '';
    if (parseFloat(data.stay)) {
      stay =
        parseFloat(data.stay) === 1
          ? data.stay + ' hour'
          : data.stay + ' hours';
    }
    return (
      <div className="row">
        <div className="col-xs-12">
          <div className={s.destination}>
            <div className="row">
              <div className="col-xs-12">
                <label htmlFor="Location of Destination">Location: </label>
                <a
                  onClick={this.viewPlace.bind(this, data.place.placeId)}
                  className={s.link}
                >
                  {` ${data.title}`}
                </a>
              </div>
            </div>
            <div className="row">
              <div className="col-xs-12">
                <label htmlFor="Start time of Destination">
                  Start time:{' '}
                </label>{' '}
                {data.startTime}
              </div>
            </div>
            <div className="row">
              <div className="col-xs-12">
                <label htmlFor="Stay time of Destination">Stay:</label> {stay}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
/* onClick={this.viewDestination.bind(this, data.descriptionId)} */
export default withStyles(s)(Destinations);
