/**
 * Created by KhangNT on 7/5/2017.
 */
import React from 'react'; //eslint-disable-line
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import history from '../../../../../../history';
import s from './Destination.css'; //eslint-disable-line
import Lock from '../../../lock/Lock';

class EditDestination extends React.Component {
  constructor(props) {
    super(props);
    this.viewDestination = this.viewDestination.bind(this);
    this.viewPlace = this.viewPlace.bind(this);
  }

  viewDestination = destinationId => {
    history.push(`/destination/detail/${destinationId}`);
  };

  viewPlace = placeId => {
    history.push(`/places/${placeId}`);
  };

  render() {
    const { data } = this.props; //eslint-disable-line
    let stay = '';
    if (parseFloat(data.stay)) {
      stay =
        parseFloat(data.stay) === 1
          ? data.stay + ' hour'
          : data.stay + ' hours';
    }
    return (
      <div
        className={s.destination}
        style={{ cursor: 'move', marginRight: '0px' }}
        id={`boundary-${data.destinationId}`}
      >
        <Lock
          day={this.props.day}
          index={data.place.placeId}
          delete={this.props.delete}
          destinationId={data.destinationId}
          selectTransit={this.props.selectTransit}
          updateLockOrUnLock={this.props.updateLockOrUnLock}
        />
        <div className="row">
          <div className="col-xs-12">
            <label htmlFor="Location of Destination">Location: </label>
            <a
              onClick={this.viewPlace.bind(this, data.place.placeId)}
              className={s.link}
            >
              {` ${data.title}`}
            </a>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-12" style={{ display: 'flex' }}>
            <label htmlFor="Start time of Destination">Start time: </label>{' '}
            <div id={`start-time-${data.destinationId}`}>{data.startTime}</div>
          </div>
        </div>
        <div className="row">
          <div className="col-xs-12">
            <label htmlFor="Stay time of Destination">Stay:</label> {stay}
          </div>
        </div>
      </div>
    );
  }
}
export default withStyles(s)(EditDestination);
