/**
 * Created by KhangNT on 7/3/2017.
 */
import React from 'react'; //eslint-disable-line
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import s from './EachDay.css';
import Item from './item/Item';

class EachDay extends React.Component {
  componentWillMount() {}

  render() {
    const { days } = this.props;
    const { data } = this.props;
    const { transitsOnDay } = this.props;
    return (
      <div className="schedule">
        {days.map((day, index) =>
          <div className="row" key={index.toString()}>
            <div className="col-xs-12">
              <h4 className={s.titleDay}>
                {day}
              </h4>
              {transitsOnDay && transitsOnDay[day]
                ? <Item
                    day={day}
                    dataOnDay={data[day]}
                    directionOnDay={transitsOnDay[day]}
                  />
                : <Item day={day} dataOnDay={data[day]} transitOnday={''} />}
            </div>
          </div>,
        )}
      </div>
    );
  }
}

export default withStyles(s)(EachDay);
