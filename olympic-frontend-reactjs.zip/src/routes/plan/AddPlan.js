/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react'; //eslint-disable-line
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';

import CalendarIcon from 'react-icons/lib/fa/calendar-plus-o';
import CameraIcon from 'react-icons/lib/fa/camera';

import GoogleMaps from '../../components/GoogleMaps/GoogleMaps';
import Day from '../../components/Plan/Day';

import ShowPublication from '../../components/ShowPublication/ShowPublication';
import UploadS3 from '../../components/UploadS3/UploadS3';
import SlideImageGrid from '../../components/SlideImageGrid/SlideImageGrid';

import planGet from '../../actions/plan/get';
import planPost from '../../actions/plan/post';
import planTemp from '../../actions/plan/temp';
import clearPlan from '../../actions/plan/clear';
import postZenrin from '../../actions/zenrin/post';
import updateDestination from '../../actions/destination/update';

import history from '../../history';
import config from '../../config';

import {
  formatDateFormat,
  isLogin,
  getRandomPhoto,
  oderListOfDestination,
  formatStartTimeZenrin,
  convertListOfZenrinToGoogle,
  convertGoogleMapsToZenrinToRequest,
  getColorRandom,
} from '../../common/common';
import { LOGIN, PLANS, PLAN_DESTINATION } from '../../common/path';

import s from './Plan.css'; //eslint-disable-line

import { convertData } from '../destination/commons';

class AddPlan extends React.Component {
  constructor(props) {
    super(props);
    const { formData } = this.props;
    this.state = {
      data: this.props.data,
      fetching: false,
      directions: [],
      marker: [],
      polyLines: [],
      dataForm: formData || [],
      showMap: true,
      defaultAvatar: getRandomPhoto(),
    };
    this.setDataForm = this.setDataForm.bind(this);
    this.saveTemp = this.saveTemp.bind(this);
    this.updateTransitTypeToDestinations = this.updateTransitTypeToDestinations.bind(
      this,
    );
    this.selectTransitType = this.selectTransitType.bind(this);
  }

  updateTransitTypeToDestinations(destinationId, transitType) {
    const { destination } = this.props;
    for (let i = 0; i < destination.length; i++) {
      if (
        Number(destination[i].createDestinationId) === Number(destinationId)
      ) {
        destination[i].transitType = transitType || 'other';
        /* Save data to store */
        this.props.updateDestination(destination);
      }
    }
  }

  selectTransitType(result) {
    this.updateTransitTypeToDestinations(
      result.destinationId,
      result.transitType,
    );
  }

  componentWillMount() {
    const user = this.props.user;
    if (!user.loading && !this.state.fetching) {
      if (!isLogin(user.user)) {
        history.push(LOGIN);
      }
    }
    const { data, destination } = this.props;
    if (Object.values(data).length > 0) {
      this.setState({ showMap: true });
    }
    const mark = [];
    const keys = Object.keys(data);
    Object.values(data).map((v, index) => {
      const color = getColorRandom();
      Object.values(v).map((val, inx) => {
        val.transitType = val.transitType || 'other';
        const mrk = {
          position: val.map.location,
          day: keys[index],
          startTime: val.start,
          place_id: val.map.place_id,
          color,
          transitType: val.transitType,
        };
        return mark.push(mrk);
      });
    });
    if (mark && !this.props.loading) {
      this.setState({
        dataForm: {
          ...this.state.dataForm,
          destination,
        },
      });
      this.setState({ marker: mark });
      let place_id = null;
      for (let i = 0; i < mark.length; i++) {
        if (i < parseFloat(mark.length - 1)) {
          const startTime = formatStartTimeZenrin(
            mark[i].day,
            mark[i].startTime,
          );
          const latStart = mark[i].position.lat();
          const lngStart = mark[i].position.lng();
          const latEnd = mark[parseFloat(i + 1)].position.lat();
          const lngEnd = mark[parseFloat(i + 1)].position.lng();
          if (mark[i].day === mark[parseFloat(i + 1)].day) {
            place_id = mark[i].place_id;
          }
          if (mark[i].day === mark[i + 1].day) {
            this.direction(
              latStart,
              lngStart,
              latEnd,
              lngEnd,
              place_id,
              mark[i].color,
              startTime,
              mark[i].transitType || 'other',
            );
          }
        }
      }
    }
  }

  componentWillReceiveProps(nextProps) {
    const user = nextProps.user;
    if (!user.loading && !this.state.fetching) {
      if (!isLogin(user.user)) {
        history.push(LOGIN);
      }
    }

    const { data, destination } = nextProps;
    if (Object.values(data).length > 0) {
      this.setState({
        data: this.props.data,
        fetching: false,
        directions: [],
        marker: [],
        polyLines: [],
        dataForm: this.state.dataForm || [],
        showMap: true,
        defaultAvatar: getRandomPhoto(),
      });
    }
    const mark = [];
    const keys = Object.keys(data);
    Object.values(data).map((v, index) => {
      const color = getColorRandom();
      Object.values(v).map((val, inx) => {
        val.transitType = val.transitType || 'other';
        const mrk = {
          position: val.map.location,
          day: keys[index],
          startTime: val.start,
          place_id: val.map.place_id,
          color,
          transitType: val.transitType,
        };
        return mark.push(mrk);
      });
    });
    if (mark && !this.props.loading) {
      this.setState({
        dataForm: {
          ...this.state.dataForm,
          destination,
        },
      });
      this.setState({ marker: mark });
      let place_id = null;
      for (let i = 0; i < mark.length; i++) {
        if (i < parseFloat(mark.length - 1)) {
          const startTime = formatStartTimeZenrin(
            mark[i].day,
            mark[i].startTime,
          );
          const latStart = mark[i].position.lat();
          const lngStart = mark[i].position.lng();
          const latEnd = mark[parseFloat(i + 1)].position.lat();
          const lngEnd = mark[parseFloat(i + 1)].position.lng();
          if (mark[i].day === mark[parseFloat(i + 1)].day) {
            place_id = mark[i].place_id;
          }
          if (mark[i].day === mark[i + 1].day) {
            this.direction(
              latStart,
              lngStart,
              latEnd,
              lngEnd,
              place_id,
              mark[i].color,
              startTime,
              mark[i].transitType || 'other',
            );
          }
        }
      }
    }
  }

  setDataForm(e) {
    this.setState({
      dataForm: {
        ...this.state.dataForm,
        [e.target.name]: e.target.value,
      },
    });
  }

  handleSubmit = e => {
    e.preventDefault();
    const publicLevelDefault = config.public_default;

    const dataPost = {};
    dataPost.destinations = [];
    /* Set value for public level */
    dataPost.publicLevel = this.state.dataForm.publicLevel
      ? this.state.dataForm.publicLevel
      : publicLevelDefault; //eslint-disable-line
    dataPost.title = this.state.dataForm.title;
    dataPost.summary = this.state.dataForm.summary;
    dataPost.avatar = this.state.dataForm.avatar;
    dataPost.photos = this.state.dataForm.photos;
    if (this.state.dataForm) {
      const places = this.state.dataForm.destination;
      if (places && places.length > 0) {
        places.map(place => {
          dataPost.destinations.push({
            startDate: formatDateFormat(place.date),
            startTime: place.start,
            stay: place.stay,
            placeOrder: 0,
            title: place.title,
            summary: place.summary,
            destinationId: '',
            place: {
              placeId: place.placeId,
              googleId: place.map.place_id,
              title: place.map.name,
              summary: place.map.name,
              type: 0,
              url: place.map.website,
            },
            transit: {
              transitDate: '',
              departTimeTransit: '',
              arrivalTimeTransit: '',
              transitType: place.transitType || 'other',
              placeOrder: 0,
            },
            photo: [],
          });
          return dataPost;
        });
      }
    }
    this.props.planPost(dataPost, response => {
      if (
        response &&
        Object.prototype.hasOwnProperty.call(response, 'code') &&
        Object.prototype.hasOwnProperty.call(response, 'message')
      ) {
        const message = response.message.replace(',', '<br/>');
        bootbox.alert(message); //eslint-disable-line
      } else {
        this.props.clearPlan(); // Clear data in store
        history.push(`${PLANS}/${response.planId}`);
      }
    });
  };

  direction(
    latStart,
    lngStart,
    latEnd,
    lngEnd,
    placeId,
    color,
    startTime,
    transitType,
  ) {
    const startZenrin = convertGoogleMapsToZenrinToRequest({
      lat: latStart,
      lng: lngStart,
    });
    const endZenrin = convertGoogleMapsToZenrinToRequest({
      lat: latEnd,
      lng: lngEnd,
    });
    const dataPostToZenrin = {
      start: {
        latitude: startZenrin.lat,
        longitude: startZenrin.lng,
      },
      end: {
        latitude: endZenrin.lat,
        longitude: endZenrin.lng,
      },
      startTime,
      endTime: startTime,
      transitType,
    };
    this.props.postZenrin(dataPostToZenrin, response => {
      if (Object.prototype.hasOwnProperty.call(response, 'totalTime')) {
        const finalResult = {
          path: convertListOfZenrinToGoogle(response.sections),
          color,
          response: response,
          placeId,
        };
        this.setState({
          polyLines: [...this.state.polyLines, finalResult],
        });
      } else {
        bootbox.alert('No way in zenrin.'); //eslint-disable-line
      }
    });
  }

  setPublication = publicValue => {
    this.setState({
      dataForm: {
        ...this.state.dataForm,
        publicLevel: publicValue,
      },
    });
  };

  saveTemp() {
    this.props.planTemp(this.state.dataForm); // eslint-disable-line
    history.push(PLAN_DESTINATION);
  }

  onChange = data => {
    this.setState({
      dataForm: {
        ...this.state.dataForm,
        avatar: data.Key,
        avatarPreview: data.Location,
      },
    });
  };

  onAlbum = data => {
    if (!this.state.dataForm.photos) {
      this.setState({
        dataForm: {
          ...this.state.dataForm,
          photos: [data.Key],
          images: [data.Location],
        },
      });
    } else {
      this.setState({
        dataForm: {
          ...this.state.dataForm,
          photos: [...this.state.dataForm.photos, data.Key],
          images: [...this.state.dataForm.images, data.Location],
        },
      });
    }
  };

  render() {
    const { data } = this.props;
    const arrHtml = [];
    Object.values(data).map((v, j) =>
      arrHtml.push(
        <Day
          key={j}
          day={j}
          dayData={v}
          transits={this.state.polyLines}
          selectTransit={this.selectTransitType}
        />,
      ),
    );

    return (
      <div className="main-content-wrapper">
        <div className={s.pageTitle}>
          <h1 className="container">Create a Plan</h1>
        </div>

        <div className="container">
          <form id="createPlan">
            <div className="form-data">
              <div className="row">
                <div
                  className={cx(
                    'col-xs-12 col-md-6',
                    s.planImageBlock,
                    s.imageBlock,
                    s.avatarImage,
                  )}
                >
                  <div className={s.imageBlockContent}>
                    <div data-toggle="modal" data-target="#viewImage">
                      <div className="thumbnail">
                        <img
                          alt="avatar"
                          src={
                            this.state.dataForm.avatarPreview ||
                            this.state.defaultAvatar
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    className={cx(
                      'btn btn-primary',
                      s.btnAddImage,
                      s.btnUploadImage,
                    )}
                  >
                    <span className={s.glyphicon}>
                      <UploadS3
                        s3Path={`${config.imageFolder.planAvatar}`}
                        onChange={this.onChange}
                      />
                    </span>
                  </button>
                </div>
              </div>
              <div className="row">
                <div className="col-xs-12 col-md-6">
                  <div className="form-group">
                    <label htmlFor="plan title">Plan Title *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="title"
                      defaultValue={this.state.dataForm.title}
                      onChange={this.setDataForm}
                    />
                  </div>
                </div>
              </div>

              <hr />

              <div className="row ">
                <div className="col-xs-12 ">
                  <div className="form-group">
                    <label htmlFor="summary">Summary</label>
                    <textarea
                      type="text"
                      rows="5"
                      className="form-control"
                      name="summary"
                      defaultValue={this.state.dataForm.summary}
                      onChange={this.setDataForm}
                    />
                  </div>
                </div>
                <hr />
              </div>

              <div className="form-group">
                <div className={s.show}>
                  <h1 className={s.pageTitle}>Schedule</h1>
                </div>
                {arrHtml}
              </div>

              <div className="row">
                <div className="col-xs-12">
                  <div className={cx('form-group', s.show)}>
                    <GoogleMaps
                      markers={this.state.marker}
                      directions={this.state.directions}
                      polyLines={this.state.polyLines}
                    />
                  </div>
                </div>
              </div>

              <hr />

              <div className="row">
                <div className="col-xs-12 col-md-5">
                  <div className="form-group">
                    <label htmlFor="Destination">Destination *</label>
                    <button
                      onClick={this.saveTemp}
                      className={cx(s.btnIcon, 'btn btn-default')}
                      type="button"
                    >
                      <span className={s.glyphicon}>
                        <CalendarIcon />
                      </span>
                      <span>ADD NEW DESTINATION</span>
                    </button>
                  </div>
                </div>
              </div>

              <hr />

              <div className="row form-group">
                <div className="col-xs-12 col-md-6">
                  <SlideImageGrid images={this.state.dataForm.images || []} />
                </div>
              </div>

              <div className="row">
                <div className="col-xs-12 col-md-5">
                  <div className="form-group">
                    <button
                      type="button"
                      className={cx(
                        s.btnIcon,
                        s.btnRelative,
                        'btn btn-default',
                      )}
                    >
                      <span className={cx(s.glyphicon, s.btnImage)}>
                        <UploadS3
                          s3Path={`${config.imageFolder.planPhoto}`}
                          onChange={this.onAlbum}
                          title="ADD IMAGE"
                        />
                      </span>
                    </button>
                  </div>
                </div>
              </div>

              <hr />

              <div className="row ">
                <div className="col-xs-12 col-md-5">
                  <div className="form-group">
                    <label htmlFor="publication">Publication</label>
                    <ShowPublication setPub={this.setPublication} />
                  </div>
                </div>
              </div>

              <hr />
              <div className="row">
                <div className="col-xs-12 col-md-5">
                  <div className="form-group">
                    <button
                      onClick={this.handleSubmit}
                      className={cx(s.btnIcon, 'btn btn-primary')}
                      type="button"
                    >
                      <span
                        className={cx(
                          'glyphicon glyphicon-floppy-save',
                          s.glyphicon,
                        )}
                        aria-hidden="true"
                      />
                      <span>Save</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>

        <div
          className="modal fade modalCustom"
          id="insertImageFromLibrary"
          role="dialog"
        >
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-body">
                <button type="button" className="close" data-dismiss="modal">
                  &times;
                </button>
                <div className="insertImage">
                  <ul className="menuItem">
                    <li>
                      <a className="text-uppercase" data-dismiss="modal">
                        <span
                          className="glyphicon glyphicon-picture"
                          aria-hidden="true"
                        />Choose from library
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

AddPlan.propTypes = {
  user: PropTypes.object, // eslint-disable-line
  planGet: PropTypes.func, // eslint-disable-line
  planPost: PropTypes.func, // eslint-disable-line
  planTemp: PropTypes.func, // eslint-disable-line
  clearPlan: PropTypes.func, // eslint-disable-line
};

const mapState = state => ({
  loading: state.plans.loading,
  data: oderListOfDestination(convertData(state.destination.addDestination)),
  formData: state.plans.temp,
  user: state.user,
  destination: state.destination.addDestination,
});

const mapDispatch = {
  planGet,
  planPost,
  planTemp,
  clearPlan,
  postZenrin,
  updateDestination,
};

export default connect(mapState, mapDispatch)(withStyles(s)(AddPlan));
