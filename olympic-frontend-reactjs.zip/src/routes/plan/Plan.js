/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react'; //eslint-disable-line
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import GoogleMaps from '../../components/GoogleMaps/GoogleMaps';
import SlideImageGrid from '../../components/SlideImageGrid/SlideImageGrid';

import s from './PlanDetail.css'; //eslint-disable-line
import {
  mapPlaceDetailToDestination,
  oderListOfDestination,
} from '../../common/common';

import planGet from '../../actions/plan/get';
import postZenrin from '../../actions/zenrin/post';
import bookmark from '../../actions/bookmark';

import { genTransitZenrin } from './component/plan';
import EachDay from './component/eachDay/EachDay';
import Title from './component/title/Title';
import Comment from '../../components/Comment/Comment';
import SocialBar from '../../components/SocialBar';

class Plan extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      planDetail: {},
      mode: 'other',
      days: [],
      markers: [],
      directions: [],
      data: {},
      transitsOnDay: {},
      transits: [],
    };
    /* Parser URL to get planId */
    const planId = this.props.planId; //eslint-disable-line

    this.props.planGet(planId, response => {
      if (response.code && response.code !== 0) {
        bootbox.alert(response.message); // eslint-disable-line
      } else {
        this.setState({
          planDetail: response,
          mode: this.state.mode,
          days: this.state.days,
          markers: this.state.markers,
          directions: this.state.directions,
          data: this.state.data,
          transitsOnDay: this.state.transitsOnDay,
          transits: this.state.transits,
        });
        //eslint-disable-next-line
        const service = new google.maps.places.PlacesService(
          document.createElement('div'),
        );
        const DirectionsService = new google.maps.DirectionsService(); //eslint-disable-line
        const { destinations } = response; //eslint-disable-line
        mapPlaceDetailToDestination(
          destinations,
          service,
          DirectionsService,
          this.callback,
        );
      }
    });

    this.callback = this.callback.bind(this);
    this.setDirectionToState = this.setDirectionToState.bind(this);
    this.setMarkers = this.setMarkers.bind(this);
    this.setDay = this.setDay.bind(this);
  }

  setDirectionToState = (transitOnDay, day) => {
    const transitsOnDay = this.state.transitsOnDay;
    if (Object.prototype.hasOwnProperty.call(transitsOnDay, day)) {
      transitsOnDay[day] = [...transitsOnDay[day], transitOnDay];
    } else {
      transitsOnDay[day] = [transitOnDay];
    }
    this.setState({
      planDetail: this.state.planDetail,
      mode: this.state.mode,
      days: this.state.days,
      markers: this.state.markers,
      directions: this.state.directions,
      data: this.state.data,
      transitsOnDay,
      transits: [...this.state.transits, transitOnDay.direction],
    });
  };

  setMarkers = destination => {
    this.setState({
      planDetail: this.state.planDetail,
      mode: this.state.mode,
      days: this.state.days, //eslint-disable-next-line
      markers: [
        ...this.state.markers,
        {
          position: new google.maps.LatLng( //eslint-disable-line
            destination.map.location.lat(),
            destination.map.location.lng(),
          ),
        },
      ],
      directions: this.state.directions,
      data: this.state.data,
      transitsOnDay: this.state.transitsOnDay,
      transits: this.state.transits,
    });
  };

  setData = data => {
    this.setState({
      planDetail: this.state.planDetail,
      mode: this.state.mode,
      days: this.state.days,
      markers: this.state.markers,
      directions: this.state.directions,
      data,
      transitsOnDay: this.state.transitsOnDay,
      transits: this.state.transits,
    });
  };

  onCommentFn = resp => {
    this.setState({
      planDetail: {
        ...this.state.planDetail,
        ['ratingAverage']: resp.averageRating,
      },
    });
  };

  setDay = day => {
    if (!day) {
      return;
    }
    this.setState({
      planDetail: this.state.planDetail,
      mode: this.state.mode,
      days: [...this.state.days, day],
      markers: this.state.markers,
      directions: this.state.directions,
      data: this.state.data,
      transitsOnDay: this.state.transitsOnDay,
      transits: this.state.transits,
    });
  };

  callback = (DirectionsService, response) => {
    if (!response) {
      return;
    }
    response = oderListOfDestination(response);
    this.setData(response);
    const days = Object.keys(response);
    days.map(day => {
      this.setDay(day);
      const destinations = response[day];

      /* Generating all direction on a day */
      genTransitZenrin(
        this.props.postZenrin,
        destinations,
        this.setDirectionToState,
        day,
      );
      destinations.map(destination => {
        this.setMarkers(destination, day);
      });
      return day;
    });
  };

  onBookmarkChange = cb => {
    const { wished, planId } = this.state.planDetail;
    let action = 'ADD';

    if (wished) {
      action = 'DEL';
    }

    this.props.bookmark(planId, action, 'plans', resp => {
      if (resp.code && resp.code !== 200) {
        bootbox.alert(resp.message);
        return;
      }
      this.setState({
        planDetail: {
          ...this.state.planDetail,
          ['wished']: !this.state.planDetail.wished,
        },
      });
      cb(action);
    });
  };

  render() {
    const { planDetail } = this.state; //eslint-disable-line
    console.log(JSON.stringify(planDetail));
    if (!planDetail) {
      return <div>Loading...</div>;
    } else if (!planDetail.destinations) {
      return <div>Loading...</div>;
    }

    return (
      <div className="wrapMainContent">
        <div className={s.pageTitle}>
          <h1 className="container">
            {planDetail.title}
          </h1>
        </div>
        <div className="container">
          <Title
            plan={this.state.planDetail} //eslint-disable-line
          />
          <div className={s.titleHeader}>
            <div className={s.rowTitle}>
              <strong>Schedule</strong>
            </div>
          </div>
          <EachDay
            days={this.state.days}
            data={this.state.data}
            transitsOnDay={this.state.transitsOnDay}
            isMove={false}
          />
          <div className="row">
            <div className="col-xs-12">
              <GoogleMaps
                markers={this.state.markers}
                directions={this.state.directions}
                polyLines={this.state.transits}
              />
            </div>
          </div>
          <div className="row form-group">
            <div className="col-xs-12 col-md-6">
              <SlideImageGrid images={this.state.planDetail.photos || []} />
            </div>
          </div>
          <hr />

          <SocialBar
            onBookmarkChange={this.onBookmarkChange}
            isBooked={this.state.planDetail.wished}
          />
          <hr />
          <Comment
            dataComment={this.state.planDetail}
            itemId={this.props.planId}
            item={'plans'}
            onComment={this.onCommentFn}
          />
        </div>
      </div>
    );
  }
}

Plan.propTypes = {
  planId: PropTypes.string, // eslint-disable-line
};

const mapState = state => ({
  loading: state.plans.loading,
  planDetail: state.plans.plan,
});

const mapDispatch = {
  planGet,
  postZenrin,
  bookmark,
};

export default connect(mapState, mapDispatch)(withStyles(s)(Plan));
