/**
 * Created by KhangNT on 8/17/2017.
 */

import React from 'react'; //eslint-disable-line
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import s from './PlanDetail.css'; //eslint-disable-line
import data from '../../api/plan_detail.json';
import Title from './component/title/Title';
import EditEachDay from './component/eachDay/EditEachDay';
import editPlan from '../../actions/plan/edit';
import {
  convertDataFollowDate,
  oderListOfDestination,
} from '../../common/common';

class EditPlan extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      mode: 'other',
      days: [],
      markers: [],
      directions: [],
      data: {},
      transitsOnDay: {},
      transits: [],
      planDetail: data,
    };
    this.callback = this.callback.bind(this);
    this.setData = this.setData.bind(this);
    this.setMarkers = this.setMarkers.bind(this);
  }

  componentDidMount() {
    this.callback(this.state.planDetail.destinations);
  }

  setData = data => {
    const days = data ? Object.keys(data) : [];
    days.map(day => {
      data[day].map(destination => {
        return (destination.lock = false);
      });
    });

    this.props.editPlan(data);
    this.setState({
      planDetail: this.state.planDetail,
      mode: this.state.mode,
      days: this.state.days,
      markers: this.state.markers,
      directions: this.state.directions,
      data,
      transitsOnDay: this.state.transitsOnDay,
      transits: this.state.transits,
    });
  };

  callback = response => {
    if (!response) {
      return;
    }
    response = oderListOfDestination(convertDataFollowDate(response));
    this.setData(response);

    const days = response ? Object.keys(response) : [];
    days.map(day => {
      const destinations = response[day];
      destinations.map(destination => {
        this.setMarkers(destination, day);
      });
      return day;
    });
  };

  setMarkers = destination => {
    this.setState({
      planDetail: this.state.planDetail,
      mode: this.state.mode,
      days: this.state.days, //eslint-disable-next-line
      markers: [
        ...this.state.markers,
        {
          position: new google.maps.LatLng( //eslint-disable-line
            destination.place.latitude,
            destination.place.longitude,
          ),
        },
      ],
      directions: this.state.directions,
      data: this.state.data,
      transitsOnDay: this.state.transitsOnDay,
      transits: this.state.transits,
    });
  };

  render() {
    return (
      <div className="wrapMainContent">
        <div className={s.pageTitle}>
          <h1 className="container">
            {this.props.title}
          </h1>
        </div>
        <div className="container">
          <Title
            plan={this.state.planDetail} //eslint-disable-line
          />
          <div className={s.titleHeader}>
            <div className={s.rowTitle}>
              <strong>Schedule</strong>
            </div>
          </div>
          <EditEachDay />
        </div>
      </div>
    );
  }
}

const mapState = state => ({
  loading: state.plans.loading,
  planDetail: state.plans.plan,
  planEdit: state.editPlan.planEdit,
});

const mapDispatch = {
  editPlan,
};

export default connect(mapState, mapDispatch)(withStyles(s)(EditPlan));
