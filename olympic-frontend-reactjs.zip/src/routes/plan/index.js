/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import Plan from './Plan';
import Layout from '../../components/Layout';
// import plan from '../../actions/plan';
import { PLANS } from '../../common/path';

export default {
  path: `${PLANS}/:planId`,

  async action({ params }) {
    const planId = params.planId;
    return {
      title: 'React Starsster Kitđs',
      component: (
        <Layout>
          <Plan planId={planId} />
        </Layout>
      ),
    };
  },
};
