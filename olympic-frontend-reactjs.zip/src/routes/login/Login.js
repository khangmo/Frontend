/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';

import Validation from 'react-validation';
import validator from 'validator';

import AlertMessage from '../../components/AlertMessage';
import Link from '../../components/Link';
import s from './Login.css';

import { google, facebook } from '../../config';
import {
  authenticate,
  authenticateGoogle,
  authenticateFacebook,
} from '../../actions/login';
import { FacebookLogin } from '../../components/Facebook';
import GoogleLogin from '../../components/Google';
import { clearSignup } from '../../actions/signup';

import FacebookIcon from 'react-icons/lib/fa/facebook';
import GooglePlusIcon from 'react-icons/lib/fa/google-plus';

Object.assign(Validation.rules, {
  // Key name maps the rule
  required: {
    // Function to validate value
    // NOTE: value might be a number -> force to string
    rule: value => value.toString().trim(),
    // Function to return hint
    // You may use current value to inject it in some way to the hint
    hint: () => <span className={'formError isVisible'}>Required</span>,
  },
  minLength: {
    rule: (value, component) => {
      const minLength = component.password.props.min;
      if (minLength != null && value.length < minLength) {
        return false;
      }
      return value;
    },
    hint: () =>
      <span className={'formError isVisible'}>
        Password must be at least 8 characters
      </span>,
  },
  maxLength: {
    rule: (value, component) => {
      const maxLength = component.password.props.max;
      if (maxLength != null && value.length > maxLength) {
        return false;
      }
      return value;
    },
    hint: () =>
      <span className={'formError isVisible'}>
        Password must be at most 60 characters
      </span>,
  },
  email: {
    // Example usage with external 'validator'
    rule: value => validator.isEmail(value),
    hint: value =>
      <span className={'formError isVisible'}>
        {value} is not an Email.
      </span>,
  },
  // username: {
  //   rule: value => validator.isEmpty(value),
  //   hint: value =>
  //     <span className={'formError isVisible'}>
  //       {value} is not blank.
  //     </span>,
  // },
  // This example shows a way to handle common task - compare two fields for equality
  password: {
    rule: (value, component) => {
      const password = component.password.state;
      return password;
    },
  },
});

class Login extends React.Component {
  state = {
    username: '',
    password: '',
  };

  constructor(props) {
    super(props);
    this.responseGoogle = this.responseGoogle.bind(this);
    this.responseFacebook = this.responseFacebook.bind(this);
  }

  componentWillMount() {
    this.props.clearSignup();
  }

  responseGoogleError = response => {
    console.log(response);
  };

  responseGoogle(googleUser) {
    const userToken = googleUser.getAuthResponse().id_token;
    const username = googleUser.googleId;
    const email = googleUser.getBasicProfile().getEmail();
    this.props.authenticateGoogle({ username, userToken, email });
  }

  responseFacebook(facebookUser) {
    const userToken = facebookUser.accessToken;
    const username = facebookUser.id;
    const email = facebookUser.email;
    this.props.authenticateFacebook({ username, userToken, email });
  }

  handleSubmit = e => {
    e.preventDefault();
    const { username, password } = this.state;
    this.props.authenticate({ username, password });
  };

  render() {
    const { username, password } = this.state;
    return (
      <div className={'mainContentWrapper'}>
        <div className={s.pageTitle}>
          <h1 className="container">
            {this.props.title}
          </h1>
        </div>
        <div className="container">
          <div className="row">
            <div className={cx('col-xs-12 col-sm-6 col-md-4', s.loginForm)}>
              <AlertMessage />
              <Validation.components.Form
                onSubmit={this.handleSubmit}
                id="loginForm"
              >
                <div className="form-group">
                  <Validation.components.Input
                    className="form-control"
                    value={username}
                    onChange={e => this.setState({ username: e.target.value })}
                    id="username"
                    type="text"
                    name="username"
                    validations={['required']}
                    placeholder="UserName *"
                    errorClassName={'is-invalid-input'}
                    autoFocus
                  />
                </div>
                <div className="form-group">
                  <Validation.components.Input
                    className="form-control"
                    value={password}
                    onChange={e => this.setState({ password: e.target.value })}
                    onFocus={e => this.setState({ password: e.target.value })}
                    id="password"
                    type="password"
                    name="password"
                    validations={['required', 'minLength', 'maxLength']}
                    placeholder="Password *"
                    errorClassName={'is-invalid-input'}
                    min="8"
                    max="60"
                  />
                </div>
                <div className="form-group text-center">
                  <a>Forgot username or password?</a>
                </div>
                <div className="form-group">
                  <Validation.components.Button
                    className={cx('btn btn-primary', s.btnIcon)}
                    type="submit"
                  >
                    Log in
                  </Validation.components.Button>
                </div>
                <div className="form-group">
                  <Link to={'/signup'}>
                    <button
                      className={cx('btn btn-default', s.btnIcon)}
                      type="button"
                    >
                      Sign up
                    </button>
                  </Link>
                </div>
              </Validation.components.Form>

              <div className="form-group text-center">
                <span>Or login with</span>
              </div>
              <div className="form-group">
                <FacebookLogin
                  socialId={facebook.clientId}
                  scope="public_profile,email"
                  responseHandler={this.responseFacebook.bind(this)}
                  version="v2.9"
                  cookie
                  xfbml
                  s={s}
                  buttonText="Facebook"
                />
              </div>
              <div className="form-group">
                <GoogleLogin
                  clientId={google.clientId}
                  onSuccess={this.responseGoogle.bind(this)}
                  onFailure={this.responseGoogleError.bind(this)}
                  offline={false}
                  s={s}
                  approvalPrompt="force"
                  responseType="id_token"
                  isSignedIn
                >
                  <span>Google</span>
                </GoogleLogin>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

Login.propTypes = {
  authenticate: PropTypes.func.isRequired,
  authenticateGoogle: PropTypes.func.isRequired,
  authenticateFacebook: PropTypes.func.isRequired,
  clearSignup: PropTypes.func.isRequired,
};

const mapState = state => ({
  user: state.user,
});

const mapDispatch = {
  clearSignup,
  authenticate,
  authenticateGoogle,
  authenticateFacebook,
};

export default connect(mapState, mapDispatch)(withStyles(s)(Login));
