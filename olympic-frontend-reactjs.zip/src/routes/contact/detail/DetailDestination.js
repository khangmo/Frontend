/**
 * Created by KhangNT on 7/10/2017.
 */
import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Rater from 'react-rater';

import s from './DetailDestination.css';
import { get, getPlaceDetail } from '../../../common/common';
import GoogleMaps from '../../../components/GoogleMaps/GoogleMaps';
import dataTest from '../../../api/destination-detail.json';

class DetailDestination extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      markers: [],
      destination: {},
      rating: 0,
      placeName: '',
    };
    const service = new google.maps.places.PlacesService(
      document.createElement('div'),
    ); //eslint-disable-line
    if (!service) {
      bootbox.alert('Can not initialize PlacesService of Google Maps!'); //eslint-disable-line
      return;
    }
    const destinationId = this.getDestinationIdFromUrl(window.location.href);

    get(
      `http://10.17.22.63:8080/api/v1/destination/detail/${destinationId}`,
      {},
    )
      .then(response => {
        if (response) {
          this.setState({
            markers: this.state.markers,
            destination: this.state.destination,
          });
          getPlaceDetail(
            service,
            response.place.googleId,
            this.setMarkerToState,
          );
        }
      })
      .catch(response => {
        //eslint-disable-line
        bootbox.alert('Connect to Server API fail!', () => {
          //eslint-disable-line
          console.log(response); //eslint-disable-line
        });

        if (dataTest) {
          this.setState({
            markers: this.state.markers,
            destination: dataTest,
            rating: this.state.rating,
            placeName: this.state.placeName,
          });
          getPlaceDetail(
            service,
            dataTest.place.googleId,
            this.setMarkerToState,
          );
        }
      });
  }

  setMarkerToState = response => {
    const location = response.geometry.location;
    this.setState({
      markers: [
        {
          position: new google.maps.LatLng(location.lat(), location.lng()), //eslint-disable-line
        },
      ],
      destination: this.state.destination,
      rating: response.rating,
      placeName: response.name,
    });
  };

  getDestinationIdFromUrl = url => {
    if (url) {
      const tokens = url.split('destination/detail/');
      if (tokens && tokens.length > 1) {
        return tokens[1];
      }
    }
    return '';
  };

  render() {
    if (!this.state.destination) {
      return <div>Loading Destination Detail fail...</div>;
    }
    return (
      <div className="root">
        <h1 className={s.title}>DETAIL DESTINATION</h1>
        <div className="wrap-main-content">
          <div className="container">
            <div className="row">
              <div className="col-xs-12 col-sm-6">
                <label htmlFor="Title">Title</label>
                <input
                  className="form-control"
                  type="text"
                  value={this.state.destination.title}
                  readOnly
                />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12 col-sm-6">
                <label htmlFor="Title">Date</label>
                <input
                  className="form-control"
                  type="text"
                  value={this.state.destination.startDate}
                  readOnly
                />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12 col-sm-6">
                <label htmlFor="Title">Start Time</label>
                <input
                  className="form-control"
                  type="text"
                  value={this.state.destination.startTime}
                  readOnly
                />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12 col-sm-6">
                <label htmlFor="Title">Stay</label>
                <input
                  className="form-control"
                  type="text"
                  value={this.state.destination.stay}
                  readOnly
                />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12">
                <label htmlFor="Title">Summary</label>
                <textarea
                  className="form-control"
                  type="text"
                  value={this.state.destination.startTime}
                  readOnly
                  rows={5}
                />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12">
                <label htmlFor="View Place info">{`Place: ${this.state
                  .placeName}`}</label>
              </div>
            </div>
            <div className="row" style={{ marginTop: '10px' }}>
              <div className="col-xs-12">
                {this.state.destination.title
                  ? this.state.destination.title
                  : ''}
              </div>
            </div>
            <div className="row" style={{ marginTop: '10px' }}>
              <div className="col-xs-12">
                <Rater interactive={false} rating={this.state.rating} />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12">
                <GoogleMaps markers={this.state.markers} directions={[]} />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(DetailDestination);
