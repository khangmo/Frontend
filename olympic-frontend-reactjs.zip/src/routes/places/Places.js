/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react'; //eslint-disable-line
import PropTypes from 'prop-types';
import Rater from 'react-rater';
import { connect } from 'react-redux';

import cx from 'classnames';
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import placesGet from '../../actions/places/get';
import bookmark from '../../actions/bookmark';

import { getPlaceDetail, getRandomPhoto } from '../../common/common';

import s from './Places.css'; //eslint-disable-line

import GoogleMaps from '../../components/GoogleMaps/GoogleMaps';
import Comment from '../../components/Comment/Comment';
import SlideImages from '../../components/SlideImages/SlideImages';
import SocialBar from '../../components/SocialBar';
import SlideImageGrid from '../../components/SlideImageGrid/SlideImageGrid';

class Places extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fetching: false,
      marker: [],
      photos: [],
      reviews: {},
      defaultAvatar: getRandomPhoto(),
    };
  }

  componentDidMount() {
    this.drawPlaceDetail();
  }

  onSubmitComment = resp => {
    this.setState({ ratingAverage: resp.averageRating });
  };

  drawPlaceDetail = () => {
    /* Parser URL to get placeId */
    const placeId = this.props.placeId; //eslint-disable-line
    this.props.placesGet(placeId, dataPlaces => {
      if (dataPlaces.code && dataPlaces.code !== 0) {
        bootbox.alert(dataPlaces.message); // eslint-disable-line
      } else {
        const placeService = new google.maps.places.PlacesService(
          document.createElement('div'),
        ); //eslint-disable-line
        getPlaceDetail(placeService, dataPlaces.googleId, resp => {
          let types = '';
          let rating = 0;
          let location = '';
          let page = '';
          let title = '';
          if (Object.prototype.hasOwnProperty.call(resp, 'types')) {
            const currentType = resp.types;
            for (let i = 0; i < currentType.length; i++) {
              if (types) {
                types = `${types}, ${currentType[i]}`;
              } else {
                types = currentType[i];
              }
            }
          }
          if (Object.prototype.hasOwnProperty.call(resp, 'rating')) {
            rating = resp.rating;
          }
          if (Object.prototype.hasOwnProperty.call(resp, 'formatted_address')) {
            location = resp.formatted_address;
          }
          if (Object.prototype.hasOwnProperty.call(resp, 'website')) {
            page = resp.website;
          }
          if (Object.prototype.hasOwnProperty.call(resp, 'name')) {
            title = resp.name;
          }
          this.setState({
            marker: [
              {
                position: new google.maps.LatLng( //eslint-disable-line
                  resp.geometry.location.lat(),
                  resp.geometry.location.lng(),
                ),
              },
            ],
            googleRating: resp.rating,
            type: types,
            rating,
            location,
            page,
            title,
          });
        });
        this.setState({
          placeDetail: dataPlaces,
          placeId: dataPlaces.placeId,
          type: dataPlaces.type,
          location: dataPlaces.location,
          title: dataPlaces.title,
          ratingAverage: parseFloat(dataPlaces.ratingAverage),
          totalUserRating: parseFloat(dataPlaces.totalUserRating),
          url: dataPlaces.url,
          summary: dataPlaces.summary,
          photos: dataPlaces.photos,
          googleId: dataPlaces.googleId,
          reviews: dataPlaces.reviews,
          myReview: dataPlaces.myReview || '',
        });
      }
    });
  };

  onBookmarkChange = cb => {
    const { wished, placeId } = this.state.placeDetail;
    let action = 'ADD';

    if (wished) {
      action = 'DEL';
    }

    this.props.bookmark(placeId, action, 'places', resp => {
      if (resp.code && resp.code !== 200) {
        bootbox.alert(resp.message);
        return;
      }

      this.setState({
        placeDetail: {
          ...this.state.placeDetail,
          ['wished']: !this.state.placeDetail.wished,
        },
      });
      cb(action);
    });
  };

  render() {
    if (!this.state.title) {
      return <div>Loading...</div>;
    }
    let slideImage = [];
    if (this.state.photos) {
      slideImage = Object.values(this.state.photos).map(v =>
        <div className={cx(s.padding, 'col-xs-6')}>
          <div data-toggle="modal" data-target="#viewImage">
            <img
              className="thumbnail"
              src={v || this.state.defaultAvatar}
              alt="Photo of place"
            />
          </div>
        </div>,
      );
    }
    return (
      <div>
        <div className={s.pageTitle}>
          <h1 className="container">
            {this.state.title}
          </h1>
        </div>
        <div className="main-content-wrapper">
          <div className="container">
            <div className="placeContent">
              <div className={cx('row', s.placeContentItem)}>
                <div className="form-group">
                  <label htmlFor="type" className="col-xs-4 col-sm-3 col-md-2">
                    Type
                  </label>
                  <div className="col-xs-8 col-sm-9 col-md-10">
                    <span>
                      {this.state.type}
                    </span>
                  </div>
                </div>
              </div>
              <div className={cx('row', s.placeContentItem)}>
                <div className="form-group">
                  <label
                    htmlFor="view location"
                    className="col-xs-4 col-sm-3 col-md-2"
                  >
                    Location
                  </label>
                  <div className="col-xs-8 col-sm-9 col-md-10">
                    <span>
                      {this.state.location}
                    </span>
                  </div>
                </div>
              </div>

              <div className={cx('row', s.placeContentItem)}>
                <div className="form-group">
                  <label htmlFor="title" className="col-xs-4 col-sm-3 col-md-2">
                    Title
                  </label>
                  <div className="col-xs-8 col-sm-9 col-md-10">
                    <span>
                      {this.state.title}
                    </span>
                  </div>
                </div>
              </div>

              <div className={cx('row', s.placeContentItem)}>
                <div className="form-group">
                  <label
                    htmlFor="view rating"
                    className="col-xs-4 col-sm-3 col-md-2"
                  >
                    Rating
                  </label>
                  <div className="col-xs-8 col-sm-9 col-md-10">
                    <Rater
                      className="react-rater notChoose"
                      rating={
                        this.state.ratingAverage || this.state.googleRating
                      }
                      interactive={false}
                    />
                  </div>
                </div>
              </div>

              <div className={cx('row', s.placeContentItem)}>
                <div className="form-group">
                  <label htmlFor="page" className="col-xs-4 col-sm-3 col-md-2">
                    Page reference
                  </label>
                  <div
                    className={cx(
                      'col-xs-8 col-sm-9 col-md-10',
                      s.pageReference,
                    )}
                  >
                    <span>
                      {this.state.page}
                    </span>
                  </div>
                </div>
              </div>

              <div className="row">
                <div className="col-xs-12">
                  <hr />
                  <div className="form-group">
                    <label htmlFor="summary">Summary</label>
                    <p />
                  </div>
                </div>
              </div>
            </div>

            <div className="schedule">
              {/* <!-- Google Maps -->*/}
              <div id="map" className="map">
                <GoogleMaps markers={this.state.marker} />
              </div>
              {/* <!--
              <div className="row" style={{ margin: '10px' }}>
                {slideImage}
                <button
                  className={cx('btn btn-primary')}
                  data-toggle="modal"
                  data-target="#insertImage"
                >
                  <span className="glyphicon glyphicon-camera" aria-hidden="true" />
                </button>
              </div>
              -->*/}
              <div className="row form-group">
                <div className="col-xs-12 col-md-6">
                  <SlideImageGrid
                    images={this.state.placeDetail.photos || []}
                  />
                </div>
              </div>
              <hr />
              <SocialBar
                onBookmarkChange={this.onBookmarkChange}
                isBooked={this.state.placeDetail.wished}
              />
            </div>
            <hr />
            <Comment
              dataComment={this.state.placeDetail}
              itemId={this.props.placeId}
              item={'places'}
              onComment={this.onSubmitComment}
            />
          </div>
        </div>
        <SlideImages images={this.state.photos} />
      </div>
    );
  }
}

Places.propTypes = {
  placeId: PropTypes.string, // eslint-disable-line
};

const mapState = state => ({
  loading: state.places.loading,
  dataPlaces: state.places.places,
  user: state.user,
});

const mapDispatch = {
  placesGet,
  bookmark,
};

export default connect(mapState, mapDispatch)(withStyles(s)(Places));
