/**
 * Created by TungDK on 7/31/2017.
 */
import React from 'react';
import Layout from '../../components/Layout';
import CreatePlace from './create/CreatePlace';
import { PLACE_ADD } from '../../common/path';

const title = 'Create a place';

export default {
  path: PLACE_ADD,

  action() {
    return {
      title,
      component: (
        <Layout>
          <CreatePlace title={title} />
        </Layout>
      ),
    };
  },
};
