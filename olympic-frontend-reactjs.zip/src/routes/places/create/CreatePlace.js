/**
 * Created by KhangNT on 6/8/2017.
 */
import React from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { connect } from 'react-redux';
import cx from 'classnames';
import DatePicker from 'react-datepicker';
import FaMarker from 'react-icons/lib/fa/map-marker';
import FaHeart from 'react-icons/lib/fa/heart';
import RecommendIcon from 'react-icons/lib/fa/lightbulb-o';
import NumericInput from 'react-numeric-input';

import GoogleMaps from '../../../components/GoogleMaps/GoogleMaps';
import s from '../../../components/common.css';
import history from '../../../history';
import place from '../../../actions/places/post';
import { LOGIN, PLACE_ADD } from '../../../common/path';
import { isLogin, trimStr } from '../../../common/common';

import {
  validateStay,
  parserJson,
  setSummaryToState,
  setTitleToState,
} from '../../destination/commons';

const dataConfig = {
  zoom: 14,
  mode: 'TRANSIT',
  center: {
    lat: 35.700487869791004,
    lng: 139.77720737457275,
  },
  timeDefault: '',
};

class CreatePlace extends React.Component {
  constructor(props) {
    super(props);

    this.changeTitle = this.changeTitle.bind(this);
    this.changeSummary = this.changeSummary.bind(this);
    this.save = this.save.bind(this);
  }

  state = {
    mode: dataConfig.mode,
    markers: [],
    data: {
      title: '',
      summary: '',
      googleId: '',
      placeId: '',
      map: {
        location: {
          lat: '',
          lng: '',
        },
        place_id: '',
        reference: '',
        rating: '',
        website: '',
        name: '',
        icon: '',
        id: '',
        input_address: '',
        post_code: '',
        international_phone_number: '',
        formatted_address: '',
        types: [],
      },
    },
  };

  componentWillMount() {
    const container = document.getElementsByClassName('pac-container')[0];
    if (container) container.remove();

    const user = this.props.user;
    if (!user.loading && !this.state.fetching) {
      if (!isLogin(user.user)) {
        history.push(LOGIN);
      }
    }
  }

  componentDidMount() {
    const destinationInput = document.getElementById('destinationInput');

    // Stop process of the touchend event
    if (navigator.userAgent.match(/(iPad|iPhone|iPod)/g)) {
      setTimeout(() => {
        const container = document.getElementsByClassName('pac-container')[0];
        container.addEventListener('touchend', e => {
          e.stopPropagation();
        });
      }, 500);
    }

    // eslint-disable-next-line
    const autocomplete = new google.maps.places.Autocomplete(destinationInput, {
      componentRestrictions: { country: 'jp' },
    });

    autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();
      const destination = this.refs.destination; // eslint-disable-line
      if (!destination) return;
      const map = parserJson(place, destination.value);
      if (!place.geometry) return;

      this.setState({
        mode: this.state.mode,
        stores: this.state.stores,
        nodes: this.state.nodes,
        markers: [
          {
            // eslint-disable-next-line
            position: new google.maps.LatLng({
              lat: place.geometry.location.lat(),
              lng: place.geometry.location.lng(),
            }),
          },
        ],
        start: this.state.start,
        data: {
          title: this.state.data.title,
          summary: this.state.data.summary,
          googleId: this.state.data.map.place_id,
          map,
        },
      });
    });
  }

  componentWillReceiveProps(nextProps) {
    const user = nextProps.user;
    if (!user.loading && !this.state.fetching) {
      if (!isLogin(user.user)) {
        history.push(LOGIN);
      }
    }
  }

  changeSummary(event) {
    this.setState(setSummaryToState(this.state, event.target.value));
  }

  changeTitle(event) {
    this.setState(setTitleToState(this.state, event.target.value));
  }

  handleTimeChange(newTime) {
    this.setState(setTimeToState(this.state, newTime.formatted24));
  }

  myFormat = num => {
    this.setState(setStayToState(this.state, num));
    return `${num} hour`;
  };

  save = event => {
    if (!this.state.data.map.location.lat) {
      bootbox.alert('Please input a address'); //eslint-disable-line
      return;
    }
    if (!trimStr(this.state.data.title)) {
      bootbox.alert('Please input your Title'); //eslint-disable-line
      return;
    }

    const container = document.getElementsByClassName('pac-container')[0];
    if (container) container.remove();

    const placeDataPost = {};
    (placeDataPost.googleId = this.state.data.map.place_id), (placeDataPost.title = this.state.data.title), (event.target.disabled = true);
    this.props
      .destination(placeDataPost, this.state.data, response => {
        if (response.code && response.code !== 0) {
          this.state.data.placeId = response.id;
          bootbox.alert(response.message); //eslint-disable-line
          this.refs.btnApply.disabled = false;
        } else {
          this.refs.btnApply.disabled = false;
          history.push(PLAN_ADD);
        }
      })
      .catch(error => {
        bootbox.alert('Add new Destiantion fail.'); // eslint-disable-line
        this.refs.btnApply.disabled = false;
      });
  };

  render() {
    const { places } = this.props;
    return (
      <div className={s.destination}>
        <div className={s.pageTitle}>
          <h1 className="container">Create a place</h1>
        </div>
        <div className="wrap-main-content">
          <div className="container">
            <div className={s.formData}>
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="Title">Title *</label>
                    <input
                      className="form-control"
                      type="text"
                      id="titleInput"
                      placeholder="Input your title"
                      onChange={this.changeTitle}
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="Destination">Destination *</label>
                    <input
                      ref="destination"
                      id="destinationInput"
                      className="form-control"
                      type="text"
                      placeholder="Search place in Google"
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12">
                  <GoogleMaps markers={this.state.markers} />
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="Type">Type *</label>
                    <select className="form-control">
                      <option>Restaurant</option>
                      <option>Hotel</option>
                      <option>Musium</option>
                      <option> Park</option>
                      <option>Station</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="Page reference">Page reference</label>
                    <input
                      onChange={this.changeStart}
                      type="text"
                      className="form-control"
                      placeholder="http://example.com"
                      value={this.state.start}
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12">
                  <div className="form-group">
                    <label htmlFor="Summary">Summary</label>
                    <textarea
                      onChange={this.changeSummary}
                      className="form-control"
                      type="text"
                      placeholder="Input Your Summary"
                      rows="5"
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-5">
                  <button
                    ref="btnApply"
                    className={cx('btn btn-primary', s.btnIcon)}
                    onClick={this.save}
                  >
                    <span>Save</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

CreatePlace.propTypes = {
  user: PropTypes.object, // eslint-disable-line
  place: PropTypes.func, // eslint-disable-line
};

const mapStateToProps = state => ({
  // places: state.place.createPlace,
  user: state.user,
});

const mapDispatch = {
  place,
};

export default connect(mapStateToProps, mapDispatch)(
  withStyles(s)(CreatePlace),
);
