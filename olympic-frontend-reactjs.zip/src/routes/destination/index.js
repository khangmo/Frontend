/**
 * Created by KhangNT on 6/8/2017.
 */
import React from 'react';
import Layout from '../../components/Layout';
import Destination from './Destination';
import { PLAN_DESTINATION } from '../../common/path';

const title = 'Create Destination';

export default {
  path: PLAN_DESTINATION,

  action() {
    return {
      title,
      component: (
        <Layout>
          <Destination title={title} />
        </Layout>
      ),
    };
  },
};
