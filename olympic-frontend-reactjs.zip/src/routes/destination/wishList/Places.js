/**
 * Places screen
 */

import React from 'react'; //eslint-disable-line
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Rater from 'react-rater';
import cx from 'classnames';

import getPlaceList from '../../../actions/main/places/get';
import getMorePlace from '../../../actions/main/places/getMorePlace';

import s from '../../../components/common.css'; //eslint-disable-line

class ListItem extends React.Component {
  render() {
    const { place } = this.props;
    if (
      place &&
      Object.prototype.hasOwnProperty.call(place, 'googleId') &&
      Object.prototype.hasOwnProperty.call(place, 'ratingAverage') &&
      Object.prototype.hasOwnProperty.call(place, 'avatar') &&
      Object.prototype.hasOwnProperty.call(place, 'title')
    ) {
      const googleId = place.googleId;
      const ratingAverage = place.ratingAverage;
      const avatar = place.avatar;
      const title = place.title;
      const result = {
        googleId,
        title,
      };
      return (
        <div
          className={cx('col-md-6 col-sm-6 col-xs-12', s.itemList)}
          style={{ paddingLeft: '2px', paddingRight: '2px' }}
        >
          <div className={s.itemListImage}>
            <img
              className="thumbnail"
              src={avatar}
              alt={title}
              data-dismiss="modal"
              onClick={this.props.getGoogleIdFromWishList.bind(this, result)}
            />
          </div>
          <div className={s.itemListSumary}>
            <span className={s.itemListTitle}>
              {title}
            </span>
            <Rater rating={ratingAverage || 0} interactive={false} />
          </div>
        </div>
      );
    }
  }
}

class Places extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataPlaces: [],
      pageNumber: 1,
      size: 12,
    };
  }

  clickIntoPage = pageIndex => {};

  componentDidMount() {
    $('#pagination-place').pagination({
      items: 500,
      itemsOnPage: 12,
      cssStyle: 'light-theme',
      callback: this.clickIntoPage,
    });
  }

  componentWillMount() {
    this.props.getPlaceList(dataPlaces => {
      this.setState({ dataPlaces });
    });
  }

  handleInfiniteLoad = (loading, callback) => {
    //Call current page on state via number
    let pageNumber = parseInt(this.state.pageNumber + 1);
    const size = parseInt(this.state.size);
    const totalPage = parseInt(this.state.dataPlaces.totalPages);

    if (loading) {
      if (totalPage >= pageNumber) {
        this.props.getMorePlace(pageNumber, size, resp => {
          const htm = Object.values(resp.content).map((place, index) => {
            return (
              <ListItem
                key={index}
                place={place}
                getGoogleIdFromWishList={this.props.getGoogleId}
              />
            );
          });
          callback(htm);
        });
      } else {
        callback({});
      }
    }
  };

  render() {
    let placesList = [];
    let html;
    if (
      Object.prototype.hasOwnProperty.call(this.state.dataPlaces, 'content')
    ) {
      const places = this.state.dataPlaces.content;
      if (places.length === 0) {
        placesList.push(
          <div key={0} className="col-xs-12">
            <p>No data found.</p>
          </div>,
        );
        html = placesList;
      } else {
        for (let i = 0; i < places.length; i++) {
          placesList.push(
            <ListItem
              key={i}
              place={places[i]}
              getGoogleIdFromWishList={this.props.getGoogleId}
            />,
          );
        }
        html = placesList;
      }
    }

    return (
      <div className="mainContentWrapper">
        {html}
      </div>
    );
  }
}

Places.propTypes = {
  user: PropTypes.object, // eslint-disable-line
  getPlaceList: PropTypes.func, // eslint-disable-line
  getMorePlace: PropTypes.func, // eslint-disable-line
  getGoogleId: PropTypes.func, //eslint-disable-line
};

const mapState = state => ({
  userAgent: state.userAgent.userAgent,
  places: state.placeList.data,
});
const mapDispatch = {
  getPlaceList,
  getMorePlace,
};

export default connect(mapState, mapDispatch)(withStyles(s)(Places));
