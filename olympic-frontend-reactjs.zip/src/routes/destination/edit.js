/**
 * Created by KhangNT on 6/8/2017.
 */
import React from 'react';
import Layout from '../../components/Layout';
import EditDestination from './EditDestination';
import { DESTINATION_EDIT } from '../../common/path';

const title = 'Edit Destination';

export default {
  path: `${DESTINATION_EDIT}/:desId`,

  async action({ params }) {
    const destinationId = params.desId;
    return {
      title,
      component: (
        <Layout>
          <EditDestination title={title} destinationId={destinationId} />
        </Layout>
      ),
    };
  },
};
