/**
 * Created by KhangNT on 6/8/2017.
 */
import React from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { connect } from 'react-redux';
import cx from 'classnames';
import DatePicker from 'react-datepicker';
import FaMarker from 'react-icons/lib/fa/map-marker';
import FaHeart from 'react-icons/lib/fa/heart';
import RecommendIcon from 'react-icons/lib/fa/lightbulb-o';
import NumericInput from 'react-numeric-input';

import GoogleMaps from '../../components/GoogleMaps/GoogleMaps';
import s from './Destination.css';
import history from '../../history';
import destination from '../../actions/destination';
import { LOGIN, PLAN_ADD, PLACE_ADD } from '../../common/path';
import { isLogin, trimStr, getPlaceDetail } from '../../common/common';
import MyWishListPlaces from './wishList/Places';

import {
  validateStay,
  parserJson,
  setDateToState,
  setSummaryToState,
  setTitleToState,
  setTimeToState,
  setStayToState,
  setCreateDestinationIdToState,
} from './commons';

const dataConfig = {
  zoom: 14,
  mode: 'TRANSIT',
  center: {
    lat: 35.700487869791004,
    lng: 139.77720737457275,
  },
  timeDefault: '',
};

class Destination extends React.Component {
  constructor(props) {
    super(props);

    const modalBackdrop = document.getElementsByClassName('modal-backdrop');
    if (modalBackdrop.length > 0) {
      modalBackdrop[0].parentNode.removeChild(modalBackdrop[0]);
    }

    this.changeTitle = this.changeTitle.bind(this);
    this.changeDate = this.changeDate.bind(this);
    this.changeStart = this.changeStart.bind(this);
    this.changeSummary = this.changeSummary.bind(this);
    this.save = this.save.bind(this);
    this.changeStay = this.changeStay.bind(this);
    this.getCreateDestinationId = this.getCreateDestinationId.bind(this);
    this.getGoogleIdFromWishList = this.getGoogleIdFromWishList.bind(this);
  }

  state = {
    mode: dataConfig.mode,
    markers: [],
    data: {
      createDestinationId: '',
      title: '',
      date: '',
      start: '',
      stay: '',
      summary: '',
      googleId: '',
      placeId: '',
      map: {
        location: {
          lat: '',
          lng: '',
        },
        place_id: '',
        reference: '',
        rating: '',
        website: '',
        name: '',
        icon: '',
        id: '',
        input_address: '',
        post_code: '',
        international_phone_number: '',
        formatted_address: '',
        types: [],
      },
    },
  };

  componentWillMount() {
    const container = document.getElementsByClassName('pac-container')[0];
    if (container) container.remove();

    const user = this.props.user;
    if (!user.loading && !this.state.fetching) {
      if (!isLogin(user.user)) {
        history.push(LOGIN);
      }
    }
  }

  componentDidMount() {
    this.getCreateDestinationId();

    const destinationInput = document.getElementById('destinationInput');

    // Stop process of the touchend event
    if (navigator.userAgent.match(/(iPad|iPhone|iPod)/g)) {
      setTimeout(() => {
        const container = document.getElementsByClassName('pac-container')[0];
        container.addEventListener('touchend', e => {
          e.stopPropagation();
        });
      }, 500);
    }

    // eslint-disable-next-line
    const autocomplete = new google.maps.places.Autocomplete(destinationInput, {
      componentRestrictions: { country: 'jp' },
    });

    autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();
      const destination = this.refs.destination; // eslint-disable-line
      if (!destination) return;
      const map = parserJson(place, destination.value);
      if (!place.geometry) return;

      this.setState({
        mode: this.state.mode,
        stores: this.state.stores,
        nodes: this.state.nodes,
        markers: [
          {
            // eslint-disable-next-line
            position: new google.maps.LatLng({
              lat: place.geometry.location.lat(),
              lng: place.geometry.location.lng(),
            }),
          },
        ],
        start: this.state.start,
        data: {
          createDestinationId: this.state.data.createDestinationId,
          title: this.state.data.title,
          date: this.state.data.date,
          start: this.state.data.start,
          stay: this.state.data.stay,
          summary: this.state.data.summary,
          googleId: this.state.data.map.place_id,
          map,
        },
      });
    });
  }

  componentWillReceiveProps(nextProps) {
    const user = nextProps.user;
    if (!user.loading && !this.state.fetching) {
      if (!isLogin(user.user)) {
        history.push(LOGIN);
      }
    }
  }

  getGoogleIdFromWishList = result => {
    if (result) {
      document.getElementById('titleInput').value = result.title;
      //eslint-disable-next-line
      const placeService = new google.maps.places.PlacesService(document.createElement('div'));
      getPlaceDetail(placeService, result.googleId, response => {
        const map = parserJson(response, null);
        if (!response.geometry) return;
        this.setState({
          mode: this.state.mode,
          stores: this.state.stores,
          nodes: this.state.nodes,
          markers: [
            {
              // eslint-disable-next-line
              position: new google.maps.LatLng({
                lat: response.geometry.location.lat(),
                lng: response.geometry.location.lng(),
              }),
            },
          ],
          start: this.state.start,
          data: {
            createDestinationId: this.state.data.createDestinationId,
            title: result.title,
            date: this.state.data.date,
            start: this.state.data.start,
            stay: this.state.data.stay,
            summary: this.state.data.summary,
            googleId: this.state.data.map.place_id,
            map,
          },
        });
      });
    }
  };

  getCreateDestinationId() {
    const createDestinationId = new Date().getTime();
    this.setState(
      setCreateDestinationIdToState(this.state, createDestinationId),
    );
  }

  changeDate(date) {
    this.setState(setDateToState(this.state, date));
  }

  changeSummary(event) {
    this.setState(setSummaryToState(this.state, event.target.value));
  }

  changeTitle(event) {
    this.setState(setTitleToState(this.state, event.target.value));
  }

  handleTimeChange(newTime) {
    this.setState(setTimeToState(this.state, newTime.formatted24));
  }

  changeStay() {
    this.setState(
      setStayToState(this.state, document.getElementById('stayInput').value),
    );
  }

  changeStart(event) {
    this.setState({
      mode: this.state.mode,
      stores: this.state.stores,
      nodes: this.state.nodes,
      markers: this.state.markers,
      center: this.state.center,
      zoom: this.state.zoom,
      data: {
        createDestinationId: this.state.data.createDestinationId,
        title: this.state.data.title,
        date: this.state.data.date,
        start: event.target.value,
        stay: this.state.data.stay,
        summary: this.state.data.summary,
        googleId: this.state.data.map.place_id,
        map: this.state.data.map,
      },
    });
  }

  myFormat = num => {
    this.setState(setStayToState(this.state, num));
    return `${num} hour`;
  };

  save = event => {
    if (!this.state.data.map.location.lat) {
      bootbox.alert('Please input your Destination'); //eslint-disable-line
      return;
    }
    if (!trimStr(this.state.data.title)) {
      bootbox.alert('Please input your Title'); //eslint-disable-line
      return;
    }
    if (!this.state.data.date) {
      bootbox.alert('Please select your Date'); //eslint-disable-line
      return;
    }

    if (!validateStay(this.props.destinations, this.state.data)) {
      //eslint-disable-line
      bootbox.alert('Your total time stay in a day greater than 24 hours'); //eslint-disable-line
    }

    const container = document.getElementsByClassName('pac-container')[0];
    if (container) container.remove();

    const placeDataPost = {};
    (placeDataPost.googleId = this.state.data.map.place_id), (placeDataPost.title = this.state.data.title), (event.target.disabled = true);
    this.props
      .destination(placeDataPost, this.state.data, response => {
        if (response.code && response.code !== 0) {
          this.state.data.placeId = response.placeId;
          bootbox.alert(response.message); //eslint-disable-line
          this.refs.btnApply.disabled = false;
        } else {
          this.refs.btnApply.disabled = false;
          history.push(PLAN_ADD);
        }
      })
      .catch(error => {
        bootbox.alert('Add new Destiantion fail.'); // eslint-disable-line
        this.refs.btnApply.disabled = false;
      });
  };

  render() {
    const { destinations } = this.props;
    return (
      <div className={s.destination}>
        <div className={s.pageTitle}>
          <h1 className="container">NEW DESTINATION</h1>
        </div>
        <div className="wrap-main-content">
          <div className="container">
            <div className={s.formData}>
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="Title">Title *</label>
                    <input
                      className="form-control"
                      type="text"
                      id="titleInput"
                      placeholder="Input your title"
                      onChange={this.changeTitle}
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="Destination">Destination *</label>
                    <input
                      ref="destination"
                      id="destinationInput"
                      className="form-control"
                      type="text"
                      placeholder="Search place in Google"
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12">
                  <GoogleMaps markers={this.state.markers} />
                </div>
              </div>
              <div className={s.divider} />
              <div className={cx('row', s.addPlace)}>
                <div className="col-xs-6 col-sm-4">
                  <div className="form-group">
                    <button
                      type="button"
                      className={cx('btn btn-default', s.btnIcon)}
                    >
                      <span className={s.glyphicon}>
                        <FaMarker />
                      </span>
                      <span>Create New Place</span>
                    </button>
                  </div>
                </div>
                <div className="col-xs-6 col-sm-4">
                  <div className="form-group">
                    <button
                      type="button"
                      className={cx('btn btn-default', s.btnIcon)}
                      data-toggle="modal"
                      data-target="#myWishListPlaces"
                    >
                      <span className={s.glyphicon}>
                        <FaHeart />
                      </span>
                      <span>Choose from wish list</span>
                    </button>
                  </div>
                </div>
                <div className="col-xs-6 col-sm-4">
                  <div className="form-group">
                    <button
                      type="button"
                      className={cx('btn btn-default', s.btnIcon)}
                    >
                      <span className={s.glyphicon}>
                        <RecommendIcon />
                      </span>
                      <span>Recommend</span>
                    </button>
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="Date">Date *</label>
                    <DatePicker
                      style={{ width: '100%' }}
                      className="form-control"
                      selected={this.state.data.date}
                      dateFormat="YYYY/MM/DD"
                      onChange={this.changeDate}
                    />
                    <style
                      // eslint-disable-next-line
                      dangerouslySetInnerHTML={{
                        __html:
                          '.react-datepicker__input-container { width: 100% }',
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="StartTime">Start Time</label>
                    <input
                      onChange={this.changeStart}
                      type="text"
                      className="form-control"
                      value={this.state.start}
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="Stay">Stay</label>
                    <NumericInput
                      onChange={this.changeStay}
                      id="stayInput"
                      style={false}
                      className="form-control"
                      value={this.state.data.stay}
                      min={0}
                      max={24}
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12">
                  <div className="form-group">
                    <label htmlFor="Summary">Summary</label>
                    <textarea
                      onChange={this.changeSummary}
                      className="form-control"
                      type="text"
                      placeholder="Input Your Summary"
                      rows="5"
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-5">
                  <button
                    ref="btnApply"
                    className={cx('btn btn-primary', s.btnIcon)}
                    onClick={this.save}
                  >
                    <span>Apply</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div
          className="modal fade"
          id="myWishListPlaces"
          tabIndex="-1"
          role="dialog"
          aria-hidden="true"
        >
          <div
            className="modal-dialog"
            role="document"
            style={{ maxWidth: '600px' }}
          >
            <div className="modal-content">
              <div className="modal-header">
                <h3 className="modal-title" style={{ float: 'left' }}>
                  My wish list places
                </h3>
                <button
                  type="button"
                  className="close"
                  data-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div
                className="modal-body"
                style={{ height: '400px', padding: '10px 0px' }}
              >
                <div
                  className="row"
                  style={{ marginLeft: '0px', marginRight: '0px' }}
                >
                  <div
                    className="col-sm-12"
                    style={{
                      overflowX: 'hidden',
                      overflowY: 'auto',
                      height: '340px',
                    }}
                  >
                    <MyWishListPlaces
                      getGoogleId={this.getGoogleIdFromWishList}
                    />
                  </div>
                </div>
                <div
                  className="row"
                  style={{ marginLeft: '0px', marginTop: '10px' }}
                >
                  <div className="col-sm-12">
                    <div
                      id="pagination-place"
                      className="light-theme simple-pagination"
                    />
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-default"
                  data-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

Destination.propTypes = {
  user: PropTypes.object, // eslint-disable-line
  destination: PropTypes.func, // eslint-disable-line
};

const mapStateToProps = state => ({
  destinations: state.destination.addDestination,
  user: state.user,
});

const mapDispatch = {
  destination,
};

export default connect(mapStateToProps, mapDispatch)(
  withStyles(s)(Destination),
);
