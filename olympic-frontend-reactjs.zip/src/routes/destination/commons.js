/* eslint-disable no-plusplus */
/**
 * Created by KhangNT on 6/9/2017.
 */
const getPostCode = info => {
  if (info) {
    let temp = info;
    while (temp.indexOf(',') >= 0) {
      temp = temp.replace(',', '');
    }

    const res = temp.split('</span>');
    for (let i = 0; i < res.length; i++) {
      // eslint-disable-line no-plusplus
      if (res[i].indexOf('postal-code') >= 0) {
        return res[i].replace('<span class="postal-code">', '');
      }
    }
  }
  return '';
};

export const parserJson = (dataInput, inputAddress) => {
  const map = {};
  if (dataInput) {
    if (dataInput.hasOwnProperty('geometry')) {
      // eslint-disable-line
      const geometry = dataInput.geometry;
      map.location = geometry.location;
    }
    if (dataInput.hasOwnProperty('place_id')) {
      // eslint-disable-line
      map.place_id = dataInput.place_id;
    }
    if (dataInput.hasOwnProperty('id')) {
      // eslint-disable-line
      map.id = dataInput.id;
    }
    if (dataInput.hasOwnProperty('international_phone_number')) {
      // eslint-disable-line
      map.international_phone_number = dataInput.international_phone_number;
    }
    if (dataInput.hasOwnProperty('name')) {
      // eslint-disable-line
      map.name = dataInput.name;
    }
    if (dataInput.hasOwnProperty('rating')) {
      // eslint-disable-line
      map.rating = dataInput.rating;
    }
    if (dataInput.hasOwnProperty('reference')) {
      // eslint-disable-line
      map.reference = dataInput.reference;
    }
    if (dataInput.hasOwnProperty('website')) {
      // eslint-disable-line
      map.website = dataInput.website;
    }
    if (dataInput.hasOwnProperty('types')) {
      // eslint-disable-line
      map.types = dataInput.types;
    }
    if (dataInput.hasOwnProperty('formatted_address')) {
      // eslint-disable-line
      map.formatted_address = dataInput.formatted_address;
    }
    if (dataInput.hasOwnProperty('icon')) {
      // eslint-disable-line
      map.icon = dataInput.icon;
    }
    if (dataInput.hasOwnProperty('adr_address')) {
      // eslint-disable-line
      map.post_code = getPostCode(dataInput.adr_address);
    }
    if (inputAddress) {
      map.input_address = inputAddress;
    }
  }
  return map;
};

export const setCreateDestinationIdToState = (state, createDestinationId) => ({
  mode: state.mode,
  stores: state.stores,
  nodes: state.nodes,
  markers: state.markers,
  center: state.center,
  zoom: state.zoom,
  data: {
    createDestinationId,
    title: state.data.title,
    date: state.data.date,
    start: state.data.start,
    stay: state.data.stay,
    summary: state.data.summary,
    map: state.data.map,
  },
});

export const setStayToState = (state, stay) => ({
  mode: state.mode,
  stores: state.stores,
  nodes: state.nodes,
  markers: state.markers,
  center: state.center,
  zoom: state.zoom,
  start: state.start,
  data: {
    createDestinationId: state.data.createDestinationId,
    title: state.data.title,
    date: state.data.date,
    start: state.data.start,
    stay,
    summary: state.data.summary,
    map: state.data.map,
  },
});

export const setSummaryToState = (state, summary) => ({
  mode: state.mode,
  stores: state.stores,
  nodes: state.nodes,
  markers: state.markers,
  center: state.center,
  zoom: state.zoom,
  data: {
    createDestinationId: state.data.createDestinationId,
    title: state.data.title,
    date: state.data.date,
    start: state.data.start,
    stay: state.data.stay,
    summary,
    map: state.data.map,
  },
});

export const setTimeToState = (state, time) => ({
  mode: state.mode,
  stores: state.stores,
  nodes: state.nodes,
  markers: state.markers,
  center: state.center,
  zoom: state.zoom,
  data: {
    createDestinationId: state.data.createDestinationId,
    title: state.data.title,
    date: state.data.date,
    start: time,
    stay: state.data.stay,
    summary: state.data.summary,
    map: state.data.map,
  },
});

export const setTitleToState = (state, title) => ({
  mode: state.mode,
  stores: state.stores,
  nodes: state.nodes,
  markers: state.markers,
  center: state.center,
  zoom: state.zoom,
  data: {
    createDestinationId: state.data.createDestinationId,
    title,
    date: state.data.date,
    start: state.data.start,
    stay: state.data.stay,
    summary: state.data.summary,
    map: state.data.map,
  },
});

export const setDateToState = (state, date) => ({
  mode: state.mode,
  stores: state.stores,
  nodes: state.nodes,
  markers: state.markers,
  center: state.center,
  zoom: state.zoom,
  data: {
    createDestinationId: state.data.createDestinationId,
    title: state.data.title,
    date,
    start: state.data.start,
    stay: state.data.stay,
    summary: state.data.summary,
    map: state.data.map,
  },
});

export const validateStay = (dataStored, currentData) => {
  if (dataStored && currentData && currentData.stay) {
    if (dataStored.length <= 0) {
      if (Number(currentData.stay) < 24) {
        return true;
      }
      return false;
    }
    let sumOfStay = 0;
    for (let i = 0; i < dataStored.length; i++) {
      // eslint-disable-line
      if (
        new Date(dataStored[i].date).getTime() ===
        new Date(currentData.date).getTime()
      ) {
        sumOfStay += Number(dataStored[i].stay);
      }
    }
    if (sumOfStay + Number(currentData.stay) > 24) {
      return false;
    }
  }
  return true;
};

export const convertData = data => {
  const result = {};
  if (data) {
    for (let i = 0; i < data.length; i++) {
      const dateFormat = formatDate(data[i].date); // eslint-disable-line
      if (dateFormat) {
        if (result.hasOwnProperty(dateFormat)) {
          const keys = Object.keys(result);
          for (let j = 0; j < keys.length; j++) {
            if (keys[j] === dateFormat) {
              result[keys[j]] = [...result[keys[j]], data[i]];
            }
          }
        } else {
          result[dateFormat] = [data[i]];
        }
      }
    }
  }
  return result;
};

const formatDate = date => {
  if (date) {
    const day = new Date(date);
    return `${day.getFullYear()}-${day.getMonth() + 1 < 10
      ? `0${day.getMonth() + 1}`
      : day.getMonth() + 1}-${day.getDate()}`;
  }
  return '';
};
