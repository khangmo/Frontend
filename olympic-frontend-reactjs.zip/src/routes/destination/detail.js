/**
 * Created by KhangNT on 7/10/2017.
 */
/**
 * Created by KhangNT on 6/8/2017.
 */
import React from 'react';
import Layout from '../../components/Layout';
import DetailDestination from './detail/DetailDestination';

const title = 'Detail Destination';

export default {
  path: '/destination/detail/:desId',

  action() {
    return {
      title,
      component: (
        <Layout>
          <DetailDestination title={title} />
        </Layout>
      ),
    };
  },
};
