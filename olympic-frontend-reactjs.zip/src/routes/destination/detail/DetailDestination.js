/**
 * Created by KhangNT on 7/10/2017.
 */
import React from 'react';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Rater from 'react-rater';
import { getPlaceDetail } from '../../../common/common';
import destinationGet from '../../../actions/destination/get';
import GoogleMaps from '../../../components/GoogleMaps/GoogleMaps';
import s from '../../../components/common.css';

class DetailDestination extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      markers: [],
      destination: {},
      rating: 0,
      placeName: '',
    };
    const service = new google.maps.places.PlacesService(
      document.createElement('div'),
    ); //eslint-disable-line
    if (!service) {
      bootbox.alert('Can not initialize PlacesService of Google Maps!'); //eslint-disable-line
      return;
    }
    const destinationId = this.getDestinationIdFromUrl(window.location.href);
    bootbox.alert(`Sorry, your destination ${destinationId} is not ready!`);
    return;
    this.props.destinationGet(destinationId, response => {
      //eslint-disable-line
      if (response.code) {
        bootbox.alert('Connect to Server API fail!', () => {
          //eslint-disable-line
          console.log(response); //eslint-disable-line
        });
      } else {
        this.setState({
          markers: this.state.markers,
          destination: this.state.destination,
        });
        getPlaceDetail(service, response.place.googleId, this.setMarkerToState);
      }
    });
  }

  setMarkerToState = response => {
    const location = response.geometry.location;
    this.setState({
      markers: [
        {
          position: new google.maps.LatLng(location.lat(), location.lng()), //eslint-disable-line
        },
      ],
      destination: this.state.destination,
      rating: response.rating,
      placeName: response.name,
    });
  };

  getDestinationIdFromUrl = url => {
    if (url) {
      const tokens = url.split('destination/detail/');
      if (tokens && tokens.length > 1) {
        return tokens[1];
      }
    }
    return '';
  };

  render() {
    if (!this.state.destination) {
      return <div>Loading Destination Detail fail...</div>;
    }
    return (
      <div className="root">
        <div className={s.pageTitle}>
          <h1 className="container">DETAIL DESTINATION</h1>
        </div>
        <div className="wrap-main-content">
          <div className="container">
            <div className="row">
              <div className="col-xs-12 col-sm-6">
                <label htmlFor="Title">Title</label>
                <input
                  className="form-control"
                  type="text"
                  value={this.state.destination.title}
                  readOnly
                />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12 col-sm-6">
                <label htmlFor="Title">Date</label>
                <input
                  className="form-control"
                  type="text"
                  value={this.state.destination.startDate}
                  readOnly
                />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12 col-sm-6">
                <label htmlFor="Title">Start Time</label>
                <input
                  className="form-control"
                  type="text"
                  value={this.state.destination.startTime}
                  readOnly
                />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12 col-sm-6">
                <label htmlFor="Title">Stay</label>
                <input
                  className="form-control"
                  type="text"
                  value={this.state.destination.stay}
                  readOnly
                />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12">
                <label htmlFor="Title">Summary</label>
                <textarea
                  className="form-control"
                  type="text"
                  value={this.state.destination.startTime}
                  readOnly
                  rows={5}
                />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12">
                <label htmlFor="View Place info">{`Place: ${this.state
                  .placeName}`}</label>
              </div>
            </div>
            <div className="row" style={{ marginTop: '10px' }}>
              <div className="col-xs-12">
                {this.state.destination.title
                  ? this.state.destination.title
                  : ''}
              </div>
            </div>
            <div className="row" style={{ marginTop: '10px' }}>
              <div className="col-xs-12">
                <Rater interactive={false} rating={this.state.rating} />
              </div>
            </div>
            <div className={s.divide} />
            <div className="row">
              <div className="col-xs-12">
                <GoogleMaps markers={this.state.markers} directions={[]} />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapState = state => ({
  loading: state.plans.loading,
  planDetail: state.plans.plan,
});

const mapDispatch = {
  destinationGet,
};

export default connect(mapState, mapDispatch)(withStyles(s)(DetailDestination));
