/**
 * Created by KhangNT on 6/8/2017.
 */
import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { connect } from 'react-redux';
import Rater from 'react-rater';
import cx from 'classnames';
import DatePicker from 'react-datepicker';
import FaFloppyO from 'react-icons/lib/fa/floppy-o';
import GoogleMaps from '../../components/GoogleMaps/GoogleMaps';

import s from './Destination.css';
import history from '../../history';
import updateDestination from '../../actions/updateDestination';
import { PLAN_ADD } from '../../common/path';

import {
  validateStay,
  parserJson,
  setDateToState,
  setSummaryToState,
  setTitleToState,
  setTimeToState,
  setStayToState,
  setCreateDestinationIdToState,
} from './commons';

// const dataConfig = {
//   zoom: 14,
//   mode: 'TRANSIT',
//   center: {
//     lat: 35.700487869791004,
//     lng: 139.77720737457275,
//   },
//   timeDefault: '',
// };

class UpdateDestination extends React.Component {
  constructor(props) {
    super(props);

    // this.handTapInput = this.handTapInput.bind(this);
    this.changeTitle = this.changeTitle.bind(this);
    this.changeDate = this.changeDate.bind(this);
    this.changeStart = this.changeStart.bind(this);
    this.changeSummary = this.changeSummary.bind(this);
    this.save = this.save.bind(this);
    this.changeStay = this.changeStay.bind(this);
    this.onFocusOutStay = this.onFocusOutStay.bind(this);
    this.onFocusStay = this.onFocusStay.bind(this);
    // this.getCreateDestinationId = this.getCreateDestinationId.bind(this);
  }

  // state = {
  //   mode: dataConfig.mode,
  //   markers: [],
  //   data: {
  //     createDestinationId: '',
  //     title: '',
  //     date: '',
  //     start: '',
  //     stay: '',
  //     summary: '',
  //     googleId: '',
  //     map: {
  //       location: {
  //         lat: '',
  //         lng: '',
  //       },
  //       place_id: '',
  //       reference: '',
  //       rating: '',
  //       website: '',
  //       name: '',
  //       icon: '',
  //       id: '',
  //       input_address: '',
  //       post_code: '',
  //       international_phone_number: '',
  //       formatted_address: '',
  //       types: [],
  //     },
  //   },
  // };

  componentWillMount() {
    //Get destinationId from url
    const url = window.location.href;
    const desId = parseInt(url.substring(url.lastIndexOf('/') + 1));

    const desData = this.props;

    if (desData) {
      const destinationData = desData.destinations;
      for (let i = 0; i < destinationData.length; i++) {
        if (destinationData[i].createDestinationId === desId) {
          this.setState({
            data: {
              createDestinationId: destinationData[i].createDestinationId,
              title: destinationData[i].title,
              date: destinationData[i].date,
              start: destinationData[i].start,
              stay: destinationData[i].stay,
              summary: destinationData[i].summary,
              googleId: destinationData[i].map.place_id,
              map: {
                location: {
                  lat: '',
                  lng: '',
                },
                place_id: destinationData[i].map.place_id,
                reference: destinationData[i].map.reference,
                rating: destinationData[i].map.rating,
                website: destinationData[i].map.website,
                name: destinationData[i].map.name,
                icon: destinationData[i].map.icon,
                id: destinationData[i].map.id,
                input_address: destinationData[i].map.input_address,
                post_code: destinationData[i].map.post_code,
                international_phone_number:
                  destinationData[i].map.international_phone_number,
                formatted_address: destinationData[i].map.formatted_address,
                types: destinationData[i].map.types,
              },
            },
          });
        }
      }
    }
  }

  setCreateDestinationId(createDestinationId) {
    this.setState(
      setCreateDestinationIdToState(this.state, createDestinationId),
    );
  }

  changeDate(date) {
    this.setState(setDateToState(this.state, date));
  }

  changeSummary(event) {
    this.setState(setSummaryToState(this.state, event.target.value));
  }

  changeTitle(event) {
    this.setState(setTitleToState(this.state, event.target.value));
  }

  handleTimeChange(newTime) {
    this.setState(setTimeToState(this.state, newTime.formatted24));
  }

  changeStay(event) {
    this.setState(setStayToState(this.state, event.target.value));
  }

  onFocusOutStay(event) {
    if (event.target.value === '0') {
      event.target.value = '';
      this.setState(setStayToState(this.state, ''));
    }
  }

  onFocusStay(event) {
    if (event.target.value === '') {
      event.target.value = '0';
      this.setState(setStayToState(this.state, 0));
    }
  }

  changeStart(event) {
    this.setState({
      mode: this.state.mode,
      stores: this.state.stores,
      nodes: this.state.nodes,
      markers: this.state.markers,
      center: this.state.center,
      zoom: this.state.zoom,
      data: {
        createDestinationId: this.state.data.createDestinationId,
        title: this.state.data.title,
        date: this.state.data.date,
        start: event.target.value,
        stay: this.state.data.stay,
        summary: this.state.data.summary,
        googleId: this.state.data.map.place_id,
        map: this.state.data.map,
      },
    });
  }

  save() {
    if (!this.state.data.title) {
      bootbox.alert('Please input your Title'); //eslint-disable-line
      return;
    }
    if (!this.state.data.date) {
      bootbox.alert('Please select your Date'); //eslint-disable-line
      return;
    }

    if (validateStay(this.props.destinations, this.state.data)) {
      //eslint-disable-line
      this.props.destination(this.state.data); // eslint-disable-line
    } else {
      bootbox.alert('Your total time stay in a day greater than 24 hours'); //eslint-disable-line
    }

    history.push(PLAN_ADD);
  }

  render() {
    if (!this.state.data) {
      return <div>Loading</div>;
    }
    return (
      <div className={s.destination}>
        <div className={s.pageTitle}>
          <h1 className="container">EDIT DESTINATION</h1>
        </div>
        <div className="wrap-main-content">
          <div className="container">
            <div className={s.formData}>
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="Title">Title *</label>
                    <input
                      className="form-control"
                      type="text"
                      id="titleInput"
                      placeholder="Input your title"
                      value={this.state.data.title}
                      onChange={this.changeTitle}
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="Date">Date *</label>
                    <DatePicker
                      style={{ width: '100%' }}
                      className="form-control"
                      selected={this.state.data.date}
                      dateFormat="YYYY/MM/DD"
                      onChange={this.changeDate}
                      value={this.state.date}
                    />
                    <style
                      // eslint-disable-next-line
                      dangerouslySetInnerHTML={{
                        __html:
                          '.react-datepicker__input-container { width: 100% }',
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="StartTime">Start Time</label>
                    <input
                      onChange={this.changeStart}
                      type="text"
                      className="form-control"
                      value={this.state.data.start}
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-6">
                  <div className="form-group">
                    <label htmlFor="Stay">Stay</label>
                    <input
                      value={this.state.data.stay}
                      onChange={this.changeStay}
                      className="form-control"
                      type="number"
                      placeholder="Input stay time"
                      onFocus={this.onFocusStay}
                      onBlur={this.onFocusOutStay}
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12">
                  <div className="form-group">
                    <label htmlFor="Summary">Summary</label>
                    <textarea
                      value={this.state.data.summary}
                      onChange={this.changeSummary}
                      className="form-control"
                      type="text"
                      placeholder="Input Your Summary"
                      rows="5"
                    />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12">
                  <div className="form-group">
                    <label htmlFor="Place">Place</label>
                    <p>
                      <label htmlFor="Place name">
                        {this.state.data.map.name}
                      </label>
                    </p>
                    <p>
                      {this.state.data.map.input_address}
                    </p>
                    <Rater rating={this.state.data.map.rating} />
                    <div />
                  </div>
                </div>
              </div>
              <div className={s.divider} />
              <div className="row">
                <div className="col-xs-12 col-sm-5">
                  <button
                    className={cx('btn btn-primary', s.btnIcon)}
                    onClick={this.save}
                  >
                    <FaFloppyO />
                    SAVE
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  destinations: state.destination.addDestination,
});

export default connect(mapStateToProps)(withStyles(s)(UpdateDestination));
