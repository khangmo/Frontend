/**
 * Search plans screen
 */

import React from 'react';
import Layout from '../../../components/Layout';
import Plans from './Plans';
import { PLANS } from '../../../common/path'; // eslint-disable-line

export default {
  path: PLANS,

  async action() {
    return {
      title: 'Plans',
      component: (
        <Layout>
          <Plans />
        </Layout>
      ),
    };
  },
};
