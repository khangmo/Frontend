/**
 * Plans screen
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Rater from 'react-rater';
import getPlanList from '../../../actions/main/plans/get';
import getMorePlan from '../../../actions/main/plans/getMorePlan';
import { getRandomPhoto } from '../../../common/common';
import ScrollLoader from '../../../components/ScrollLoader/ScrollLoader';

import Link from '../../../components/Link/Link';
import cx from 'classnames';
import s from '../../../components/common.css';

class ListItem extends React.Component {
  render() {
    const { plan } = this.props;
    let shortDescription = '';
    if ('summary' in plan) {
      let summary = plan.summary;
      shortDescription = (
        <div className={s.itemListDescription}>
          <span>
            {summary.substring(0, 100)}
          </span>
        </div>
      );
    } else {
      shortDescription = '';
    }

    return (
      <div className={cx('col-md-3 col-sm-4 col-xs-12', s.itemList)}>
        <Link to={`/plans/${plan.planId}`}>
          <div className={s.itemListImage}>
            <img
              className="thumbnail"
              src={plan.photo || getRandomPhoto()}
              alt={plan.title}
            />
          </div>
        </Link>
        <div className={s.itemListSumary}>
          <Link to={`/plans/${plan.planId}`}>
            <span className={s.itemListTitle}>
              {plan.title}
            </span>
          </Link>
          {shortDescription}
          <Rater
            className="react-rater notChoose"
            rating={plan.ratingAverage}
          />
        </div>
      </div>
    );
  }
}

class Plans extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataPlans: [],
      pageNumber: 1,
      size: 12,
    };
  }

  componentWillMount() {
    this.props.getPlanList(dataPlans => {
      this.setState({ dataPlans });
    });
  }

  handleInfiniteLoad = (loading, cb) => {
    //Call current page on state via pageNumber
    let pageNumber = parseInt(this.state.pageNumber + 1);
    const size = parseInt(this.state.size);
    const totalPage = parseInt(this.state.dataPlans.totalPages);

    if (loading) {
      if (totalPage >= pageNumber) {
        this.props.getMorePlan(pageNumber, size, resp => {
          const htm = Object.values(resp.content).map((plan, index) => {
            return <ListItem key={index} plan={plan} />;
          });
          cb(htm);

          // increase pageNumber up one unit into store
          pageNumber = pageNumber + 1;
          this.setState({ pageNumber });
        });
      } else {
        cb({});
      }
    }
  };

  render() {
    let plansList = [];
    let html;
    if (Object.prototype.hasOwnProperty.call(this.state.dataPlans, 'content')) {
      const plans = this.state.dataPlans.content;
      if (plans.length === 0) {
        plansList.push(
          <div key={0} className="col-xs-12">
            <p>No data found.</p>
          </div>,
        );
        html = plansList;
      } else {
        for (let i = 0; i < plans.length; i++) {
          plansList.push(<ListItem key={i} plan={plans[i]} />);
        }
        html = (
          <ScrollLoader handleInfiniteLoad={this.handleInfiniteLoad}>
            {plansList}
          </ScrollLoader>
        );
      }
    }

    return (
      <div className="mainContentWrapper">
        <div className="container">
          <div className="row">
            <div className={s.pageTitle}>
              <h1 className="container">Plans</h1>
            </div>
          </div>
          <div className="row">
            {html}
          </div>
        </div>
      </div>
    );
  }
}

Plans.propTypes = {
  user: PropTypes.object, // eslint-disable-line
  getPlanList: PropTypes.func, // eslint-disable-line
  getMorePlan: PropTypes.func,
};

const mapState = state => ({
  userAgent: state.userAgent.userAgent,
  plans: state.planList.data,
});
const mapDispatch = {
  getPlanList,
  getMorePlan,
};

export default connect(mapState, mapDispatch)(withStyles(s)(Plans));
