/**
 * Search plans screen
 */

import React from 'react';
import Layout from '../../../components/Layout';
import Places from './Places';
import { PLACES } from '../../../common/path'; // eslint-disable-line

export default {
  path: PLACES,

  async action() {
    return {
      title: 'Places',
      component: (
        <Layout>
          <Places />
        </Layout>
      ),
    };
  },
};
