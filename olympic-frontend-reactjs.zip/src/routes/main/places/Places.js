/**
 * Places screen
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Rater from 'react-rater';
import getPlaceList from '../../../actions/main/places/get';
import getMorePlace from '../../../actions/main/places/getMorePlace';
import { getRandomPhoto } from '../../../common/common';
import ScrollLoader from '../../../components/ScrollLoader/ScrollLoader';

import Link from '../../../components/Link/Link';
import cx from 'classnames';
import s from '../../../components/common.css';

class ListItem extends React.Component {
  render() {
    const { place } = this.props;
    let title = '';
    let shortDescription = '';

    if ('googleId' in place) {
      let googleData = place.googleData;
      let googleDataOb = JSON.parse(googleData);
      let googleAddress = googleDataOb.formattedAddress;
      title = googleDataOb.name;
      shortDescription = (
        <div className={s.itemListDescription}>
          <span>
            {googleAddress.substring(0, 100)}
          </span>
        </div>
      );
    } else {
      let summary = place.summary;
      title = place.title;
      if ('summary' in place) {
        let summary = place.summary;
        shortDescription = (
          <div className={s.itemListDescription}>
            <span>
              {summary.substring(0, 100)}
            </span>
          </div>
        );
      } else {
        shortDescription = '';
      }
    }

    return (
      <div className={cx('col-md-3 col-sm-4 col-xs-12', s.itemList)}>
        <Link to={`/places/${place.placeId}`}>
          <div className={s.itemListImage}>
            <img
              className="thumbnail"
              src={place.photo || getRandomPhoto()}
              alt={title}
            />
          </div>
        </Link>
        <div className={s.itemListSumary}>
          <Link to={`/places/${place.placeId}`}>
            <span className={s.itemListTitle}>
              {title}
            </span>
          </Link>
          {shortDescription}
          <Rater
            className="react-rater notChoose"
            rating={place.ratingAverage}
          />
        </div>
      </div>
    );
  }
}

class Places extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataPlaces: [],
      pageNumber: 1,
      size: 12,
    };
  }

  componentWillMount() {
    this.props.getPlaceList(dataPlaces => {
      this.setState({ dataPlaces });
    });
  }

  handleInfiniteLoad = (loading, cb) => {
    //Call current page on state via number
    let pageNumber = parseInt(this.state.pageNumber + 1);
    const size = parseInt(this.state.size);
    const totalPage = parseInt(this.state.dataPlaces.totalPages);

    if (loading) {
      if (totalPage >= pageNumber) {
        this.props.getMorePlace(pageNumber, size, resp => {
          const htm = Object.values(resp.content).map((place, index) => {
            return <ListItem key={index} place={place} />;
          });
          cb(htm);

          // increase pageNumber up one unit into store
          pageNumber = pageNumber + 1;
          this.setState({ pageNumber });
        });
      } else {
        cb({});
      }
    }
  };

  render() {
    let placesList = [];
    let html;
    if (
      Object.prototype.hasOwnProperty.call(this.state.dataPlaces, 'content')
    ) {
      const places = this.state.dataPlaces.content;
      if (places.length === 0) {
        placesList.push(
          <div key={0} className="col-xs-12">
            <p>No data found.</p>
          </div>,
        );
        html = placesList;
      } else {
        for (let i = 0; i < places.length; i++) {
          placesList.push(<ListItem key={i} place={places[i]} />);
        }
        html = (
          <ScrollLoader handleInfiniteLoad={this.handleInfiniteLoad}>
            {placesList}
          </ScrollLoader>
        );
      }
    }

    return (
      <div className="mainContentWrapper">
        <div className="container">
          <div className="row">
            <div className={s.pageTitle}>
              <h1 className="container">Places</h1>
            </div>
          </div>
          <div className="row">
            {html}
          </div>
        </div>
      </div>
    );
  }
}

Places.propTypes = {
  user: PropTypes.object, // eslint-disable-line
  getPlaceList: PropTypes.func, // eslint-disable-line
  getMorePlace: PropTypes.func, // eslint-disable-line
};

const mapState = state => ({
  userAgent: state.userAgent.userAgent,
  places: state.placeList.data,
});
const mapDispatch = {
  getPlaceList,
  getMorePlace,
};

export default connect(mapState, mapDispatch)(withStyles(s)(Places));
