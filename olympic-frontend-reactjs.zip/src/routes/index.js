/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

/* eslint-disable global-require */

// The top-level (parent) route
export default {
  path: '/',

  // Keep in mind, routes are evaluated in order
  children: [
    require('./home').default,
    require('./login').default,
    require('./signup').default,
    require('./my/profile').default,
    require('./my/home').default,
    require('./my/plan').default,
    require('./my/place').default,
    require('./my/plan/wishlist').default,
    require('./my/place/wishlist').default,
    require('./destination/edit').default,
    require('./destination/detail').default,
    require('./destination').default,
    require('./plan/add').default,
    require('./plan/edit').default,
    require('./plan').default,
    require('./places/add').default,
    require('./places').default,
    require('./search').default,
    require('./main/plans').default,
    require('./main/places').default,

    // Wildcard routes, e.g. { path: '*', ... } (must go last)
    require('./notFound').default,
  ],

  async action({ next }) {
    // Execute each child route until one of them return the result
    const route = await next();

    // Provide default values for title, description etc.
    route.title = `${route.title || 'Untitled Page'} - Olympic`;
    route.description = route.description || 'Olympic website';

    return route;
  },
};
