/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import Validation from 'react-validation';
import {
  rules,
  Form,
  Input,
  Button,
} from 'react-validation/lib/build/validation.rc';

import AlertMessage from '../../components/AlertMessage';
import signup, { clearSignup } from '../../actions/signup';

import s from './Signup.css';

Object.assign(Validation.rules, {
  // This example shows a way to handle common task - compare two fields for equality
  password: {
    // rule function can accept argument:
    // components - components registered to Form mapped by name
    rule: (value, components) => {
      const password = components.password.state;
      const passwordConfirm = components.passwordConfirm.state;
      const isBothUsed =
        password &&
        passwordConfirm &&
        password.isUsed &&
        passwordConfirm.isUsed;
      const isBothChanged =
        isBothUsed && password.isChanged && passwordConfirm.isChanged;

      if (!isBothUsed || !isBothChanged) {
        return true;
      }

      return password.value === passwordConfirm.value;
    },
    hint: () =>
      <span className={'formError isVisible'}>Passwords should be equal.</span>,
  },
});

class Signup extends React.Component {
  static propTypes = {
    title: PropTypes.string.isRequired,
  };

  state = {
    username: '',
    email: '',
    password: '',
    passwordConfirm: '',
  };

  componentWillMount() {
    this.props.clearSignup();
  }

  handleSubmit = e => {
    e.preventDefault();
    const { username, email, password } = this.state;
    this.props.signup({ username, email, password });
  };

  render() {
    const { username, email, password, passwordConfirm } = this.state;

    return (
      <div className="mainContentWrapper">
        <div className={s.pageTitle}>
          <h1 className="container">
            {this.props.title}
          </h1>
        </div>
        <div className="container">
          <div className="row">
            <div className={cx('col-xs-12 col-sm-6 col-md-4', s.signupForm)}>
              <AlertMessage />
              <Validation.components.Form
                onSubmit={this.handleSubmit}
                id="signupForm"
              >
                <div className="form-group">
                  <Validation.components.Input
                    className="form-control"
                    value={username}
                    onChange={e => this.setState({ username: e.target.value })}
                    id="username"
                    type="text"
                    name="username"
                    validations={['required']}
                    placeholder="UserName *"
                    errorClassName={'is-invalid-input'}
                    autoFocus
                  />
                </div>
                <div className="form-group">
                  <Validation.components.Input
                    className="form-control"
                    value={email}
                    onChange={e => this.setState({ email: e.target.value })}
                    id="email"
                    type="text"
                    name="email"
                    validations={['required', 'email']}
                    placeholder="Email *"
                    errorClassName={'is-invalid-input'}
                    autoFocus
                  />
                </div>
                <div className="form-group">
                  <Validation.components.Input
                    className="form-control"
                    value={password}
                    onChange={e => this.setState({ password: e.target.value })}
                    id="password"
                    type="password"
                    name="password"
                    validations={[
                      'required',
                      'minLength',
                      'maxLength',
                      'password',
                    ]}
                    placeholder="Password *"
                    errorClassName={'is-invalid-input'}
                    min="8"
                    max="60"
                  />
                </div>
                <div className="form-group">
                  <Validation.components.Input
                    className="form-control"
                    value={passwordConfirm}
                    onChange={e =>
                      this.setState({ passwordConfirm: e.target.value })}
                    id="passwordConfirm"
                    type="password"
                    name="passwordConfirm"
                    validations={['required', 'password']}
                    placeholder="Confirm password *"
                    errorClassName={'is-invalid-input'}
                  />
                </div>
                <div className="form-group">
                  <Validation.components.Button
                    className={cx('btn btn-primary', s.btnIcon)}
                    type="submit"
                  >
                    <span>Sign up</span>
                  </Validation.components.Button>
                </div>
              </Validation.components.Form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

Signup.propTypes = {
  signup: PropTypes.func.isRequired,
  clearSignup: PropTypes.func, // eslint-disable-line
};

const mapState = state => ({
  user: state.user,
});

const mapDispatch = {
  signup,
  clearSignup,
};

export default connect(mapState, mapDispatch)(withStyles(s)(Signup));
