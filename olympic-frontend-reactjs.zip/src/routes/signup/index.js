/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Sign up screen
 */

import React from 'react';
import Layout from '../../components/Layout';
import Signup from './Signup';

const title = 'Sign up';

export default {
  path: '/signup',

  action() {
    return {
      title,
      component: (
        <Layout>
          <Signup title={title} />
        </Layout>
      ),
    };
  },
};
