/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import MyHome from './MyHome';
import Layout from '../../../components/Layout';
import { MY_HOME } from '../../../common/path';

export default {
  path: MY_HOME,

  async action() {
    return {
      title: 'My home',
      component: (
        <Layout>
          <MyHome />
        </Layout>
      ),
    };
  },
};
