/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from '../../../components/common.css';
import Rater from 'react-rater';
import places from './places.json';

import ScrollLoader from '../../../components/ScrollLoader/ScrollLoader';

class ListItem extends React.Component {
  render() {
    const { place } = this.props;
    return (
      <div className={cx('col-md-3 col-sm-4 col-xs-12', s.itemList)}>
        <a href={place.url}>
          <div className={s.itemListImage}>
            <img className="thumbnail" src={place.image} alt="" />
          </div>
        </a>
        <div className={s.itemListSumary}>
          <span className={s.itemListTitle}>
            {place.title}
          </span>
          <div className={s.itemListDescription}>
            <span>
              {place.location}
            </span>
          </div>
        </div>
        <Rater
          className="react-rater notChoose"
          rating={parseInt(place.rating, 10)}
        />
      </div>
    );
  }
}

class MyHome extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      places: places.places,
    };
  }

  handleInfiniteLoad = (loading, cb) => {
    if (loading) {
      const htm = Object.values([
        this.state.places[1],
        this.state.places[2],
        this.state.places[3],
        this.state.places[4],
      ]).map((place, index) => {
        return <ListItem key={index} place={place} />;
      });
      cb(htm);
    }
  };

  render() {
    const htm = Object.values(this.state.places).map((place, index) => {
      return <ListItem key={index} place={place} />;
    });

    return (
      <div className="mainContentWrapper">
        <div className="container">
          <div className="row">
            <ScrollLoader handleInfiniteLoad={this.handleInfiniteLoad}>
              {htm}
            </ScrollLoader>
          </div>
        </div>
      </div>
    );
  }
}

MyHome.propTypes = {
  userAgent: PropTypes.object, // eslint-disable-line
};

const mapStateToProps = state => ({ userAgent: state.userAgent.userAgent });

export default connect(mapStateToProps)(withStyles(s)(MyHome));
