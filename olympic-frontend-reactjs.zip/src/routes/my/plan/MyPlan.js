/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Rater from 'react-rater';
import getMyPlan from '../../../actions/my/plan/get';
import history from '../../../history';
import { LOGIN, PLAN_ADD } from '../../../common/path';
import { isLogin, getRandomPhoto } from '../../../common/common';
import ScrollLoader from '../../../components/ScrollLoader/ScrollLoader';

import Link from '../../../components/Link/Link';
import cx from 'classnames';
import s from '../../../components/common.css';

class ListItem extends React.Component {
  render() {
    const { plan } = this.props;
    let summary = plan.summary;
    let shortDescription = '';
    if (summary === null) {
      shortDescription = '';
    } else if (summary && summary.length > 100) {
      shortDescription = (
        <span>
          {summary.substring(0, 100)}
        </span>
      );
    } else {
      shortDescription = (
        <span>
          {summary}
        </span>
      );
    }

    return (
      <div className={cx('col-md-3 col-sm-4 col-xs-12', s.itemList)}>
        <Link to={`/plans/${plan.planId}`}>
          <div className={s.itemListImage}>
            <img
              className="thumbnail"
              src={plan.photo || getRandomPhoto()}
              alt="avatar"
            />
          </div>
        </Link>
        <div className={s.itemListSumary}>
          <Link to={`/plans/${plan.planId}`}>
            <span className={s.itemListTitle}>
              {plan.planTitle}
            </span>
          </Link>
          <div className={s.itemListDescription}>
            {shortDescription}
          </div>
          <Rater className="react-rater notChoose" rating={plan.rating} />
        </div>
      </div>
    );
  }
}

class MyPlan extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fetching: false,
      dataMyPlan: [],
    };
  }

  componentWillMount() {
    const user = this.props.user;
    if (!user.loading && !this.state.fetching) {
      if (isLogin(user.user)) {
        this.setState({
          fetching: true,
        });
        this.props.getMyPlan(dataMyPlan => {
          this.setState({ dataMyPlan });
        });
      } else {
        history.push(LOGIN);
      }
    }
  }

  componentWillReceiveProps(nextProps) {
    const user = nextProps.user;
    if (!user.loading && !this.state.fetching) {
      if (isLogin(user.user)) {
        this.setState({
          fetching: true,
        });
        this.props.getMyPlan(dataMyPlan => {
          this.setState({ dataMyPlan });
        });
      } else {
        history.push(LOGIN);
      }
    }
  }

  handleInfiniteLoad = (loading, cb) => {
    if (loading) {
      //# Dummy data [this.state.dataMyPlan.content[0]]
      const htm = Object.values([
        this.state.dataMyPlan.content[0],
      ]).map((plan, index) => {
        return <ListItem key={index} plan={plan} />;
      });
      cb(htm);
    }
  };

  render() {
    let myPlanList = [];
    let html;
    if (
      Object.prototype.hasOwnProperty.call(this.state.dataMyPlan, 'content')
    ) {
      const plans = this.state.dataMyPlan.content;
      if (plans.length === 0) {
        myPlanList.push(
          <div key={0} className="col-xs-12">
            <p>You have no plan yet.</p>
            <p>
              <Link to={PLAN_ADD}>Create plan for your trips</Link>
            </p>
          </div>,
        );
        html = myPlanList;
      } else {
        for (let i = 0; i < plans.length; i++) {
          myPlanList.push(<ListItem key={i} plan={plans[i]} />);
        }
        html = (
          <ScrollLoader handleInfiniteLoad={this.handleInfiniteLoad}>
            {myPlanList}
          </ScrollLoader>
        );
      }
    }

    return (
      <div className="mainContentWrapper">
        <div className="container">
          <div className="row">
            <div className={s.pageTitle}>
              <h1 className="container">My plans</h1>
            </div>
          </div>
          <div className="row">
            {html}
          </div>
        </div>
      </div>
    );
  }
}

MyPlan.propTypes = {
  user: PropTypes.object, // eslint-disable-line
  getMyPlan: PropTypes.func, // eslint-disable-line
};

const mapState = state => ({
  userAgent: state.userAgent.userAgent,
  user: state.user,
  plans: state.myPlan.data,
});
const mapDispatch = {
  getMyPlan,
};

export default connect(mapState, mapDispatch)(withStyles(s)(MyPlan));
