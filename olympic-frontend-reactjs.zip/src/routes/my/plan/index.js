/**
 * My Plan screen
 * Display all plans is created by user
 * 
 */

import React from 'react';
import Layout from '../../../components/Layout';
import MyPlan from './MyPlan';
import { MY_PLAN } from '../../../common/path';

const title = 'My plans';

export default {
  path: MY_PLAN,

  action() {
    return {
      title,
      component: (
        <Layout>
          <MyPlan title={title} />
        </Layout>
      ),
    };
  },
};
