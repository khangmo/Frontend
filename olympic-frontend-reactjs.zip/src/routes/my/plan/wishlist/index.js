/**
 * My Plan screen
 * Display all plans is created by user
 * 
 */

import React from 'react';
import Layout from '../../../../components/Layout';
import MyWishListPlan from './MyWishListPlan';
import { MY_WISHLIST_PLAN } from '../../../../common/path';

const title = 'My wish list plan';

export default {
  path: MY_WISHLIST_PLAN,

  action() {
    return {
      title,
      component: (
        <Layout>
          <MyWishListPlan title={title} />
        </Layout>
      ),
    };
  },
};
