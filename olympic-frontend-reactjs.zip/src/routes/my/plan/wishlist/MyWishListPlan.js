/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import cx from 'classnames';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import history from '../../../../history';
import { LOGIN, PLAN_ADD } from '../../../../common/path';
import { isLogin } from '../../../../common/common';
import Link from '../../../../components/Link/Link';
import s from '../../../../components/common.css';

class MyWishListPlan extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fetching: false,
    };
  }

  componentWillMount() {
    const user = this.props.user;
    if (!user.loading && !this.state.fetching) {
      if (isLogin(user.user)) {
        this.setState({
          fetching: true,
        });
        // Set state of places after get my wish list plan
      } else {
        history.push(LOGIN);
      }
    }
  }

  componentWillReceiveProps(nextProps) {
    const user = nextProps.user;
    if (!user.loading && !this.state.fetching) {
      if (isLogin(user.user)) {
        this.setState({
          fetching: true,
        });
        // Set state of places after get my wish list plan
      } else {
        history.push(LOGIN);
      }
    }
  }

  render() {
    return (
      <div className="mainContentWrapper">
        <div className="container">
          <div className="row">
            <div className={s.pageTitle}>
              <h1 className="container">My plan wish list</h1>
            </div>
            <div className="col-xs-12">
              <p>No plan on wish list.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

MyWishListPlan.propTypes = {
  user: PropTypes.object, // eslint-disable-line
};

const mapState = state => ({
  userAgent: state.userAgent.userAgent,
  user: state.user,
});

export default connect(mapState)(withStyles(s)(MyWishListPlan));
