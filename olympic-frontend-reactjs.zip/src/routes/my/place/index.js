/**
 * My Plan screen
 * Display all plans is created by user
 * 
 */

import React from 'react';
import Layout from '../../../components/Layout';
import MyPlace from './MyPlace';
import { MY_PLACE } from '../../../common/path';

const title = 'My places';

export default {
  path: MY_PLACE,

  action() {
    return {
      title,
      component: (
        <Layout>
          <MyPlace title={title} />
        </Layout>
      ),
    };
  },
};
