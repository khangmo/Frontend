/**
 * My Plan screen
 * Display all plans is created by user
 * 
 */

import React from 'react';
import Layout from '../../../../components/Layout';
import MyWishListPlace from './MyWishListPlace';
import { MY_WISHLIST_PLACE } from '../../../../common/path';

const title = 'My wish list place';

export default {
  path: MY_WISHLIST_PLACE,

  action() {
    return {
      title,
      component: (
        <Layout>
          <MyWishListPlace title={title} />
        </Layout>
      ),
    };
  },
};
