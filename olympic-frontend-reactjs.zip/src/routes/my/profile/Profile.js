/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright � 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import cx from 'classnames';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Validation from 'react-validation';
import DatePicker from 'react-datepicker';
import moment from 'moment';
import FacebookIcon from 'react-icons/lib/fa/facebook';
import GooglePlusIcon from 'react-icons/lib/fa/google-plus';
import profileGet from '../../../actions/profile/get';
import profilePut from '../../../actions/profile/put';
import updateAvatar from '../../../actions/profile/avatar';
import ShowPublication from '../../../components/ShowPublication/ShowPublication';
import Upload from '../../../components/Upload/Upload';
import history from '../../../history';
import { LOGIN } from '../../../common/path';
import { isLogin } from '../../../common/common';

import { google, facebook } from '../../../config';
import { mappingGoogle, mappingFacebook } from '../../../actions/login';
import { FacebookLogin } from '../../../components/Facebook';
import GoogleLogin from '../../../components/Google';

import s from './Profile.css';
import UploadS3 from '../../../components/UploadS3/UploadS3';
import config from '../../../config';

/* Validate */
Object.assign(Validation.rules, {
  firstName: {
    rule: value => (value ? value.trim() : ''),
    hint: value =>
      <span className={'formError isVisible'}>First name is required.</span>,
  },
  lastName: {
    rule: value => (value ? value.trim() : ''),
    hint: value =>
      <span className={'formError isVisible'}>Last name is required.</span>,
  },
  birthday: {
    rule: value => (value ? value.trim() : ''),
    hint: value =>
      <span className={'formError isVisible'}>Birthday is required.</span>,
  },
});

class Profile extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      fetching: false,
      dataForm: {},
      required: {
        firstName: 'First name',
        lastName: 'Last name',
        birthday: 'Birthday',
      },
    };

    this.setDataForm = this.setDataForm.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.responseGoogle = this.responseGoogle.bind(this);
    this.responseFacebook = this.responseFacebook.bind(this);
  }

  componentWillMount() {
    const user = this.props.user;
    if (!user.loading && !this.state.fetching) {
      if (isLogin(user.user)) {
        this.getProfile(user.user.userId);
      } else {
        history.push(LOGIN);
      }
    }
  }

  componentWillReceiveProps(nextProps) {
    const user = nextProps.user;
    if (!user.loading && !this.state.fetching) {
      if (isLogin(user.user)) {
        this.getProfile(user.user.userId);
      } else {
        history.push(LOGIN);
      }
    }
  }

  getProfile = userId => {
    this.setState({
      fetching: true,
    });
    this.props.profileGet(userId, response => {
      if (response.code && response.code !== 0) {
        bootbox.alert(response.message); //eslint-disable-line
      } else {
        const profile = this.props.dataProfile.profile; // eslint-disable-line
        const birth = profile.birthday
          ? moment(profile.birthday).format('YYYY-MM-DD')
          : '';
        this.setState({
          dataForm: {
            ...this.state.dataForm,
            firstName: profile.firstName,
            lastName: profile.lastName,
            // nickName: profile.nickName,
            birthday: birth,
            sex: profile.sex,
            language: profile.language,
            income: profile.income,
            currency: profile.currency,
            country: profile.country,
            religion: profile.religion,
            job: profile.job,
            publicLevel: profile.publicLevel,
            avatar: profile.avatar || 'images/avatar.png',
          },
        });
      }
    });
  };

  setDataForm(e) {
    if (e.target.name === 'income') {
      this.checkNumber(e.target);
    }
    this.setState({
      dataForm: {
        ...this.state.dataForm,
        [e.target.name]: e.target.value,
      },
    });
  }

  setPublication = publicValue => {
    this.setState({
      dataForm: {
        ...this.state.dataForm,
        publicLevel: publicValue,
      },
    });
  };

  responseGoogle(googleUser) {
    const userToken = googleUser.getAuthResponse().id_token;
    const username = googleUser.googleId;
    this.props.mappingGoogle({ username, userToken });
  }

  responseFacebook(facebookUser) {
    const userToken = facebookUser.accessToken;
    const username = facebookUser.id;
    this.props.mappingFacebook({ username, userToken });
  }

  handleChange(date) {
    this.setState({
      dataForm: {
        ...this.state.dataForm,
        birthday: moment(date).format('YYYY-MM-DD'),
      },
    });
  }

  handleSubmit = e => {
    e.preventDefault();
    let isPost = true;
    const objKey = Object.keys(Validation.rules);
    const data = this.state.dataForm;
    const error = [];
    Object.keys(data).map(i => {
      if (
        objKey.indexOf(i) !== -1 &&
        (!data[i] || data[i].trim() === '' || data[i].trim() === 'Invalid date')
      ) {
        isPost = false;
        error.push(`${this.state.required[i]} is required.`);
      }
    });

    if (data.income && parseFloat(data.income) > 99999999999) {
      isPost = false;
      error.push('Income are too large.');
    }

    if (isPost) {
      this.props.profilePut(
        this.props.user.user.userId,
        this.state.dataForm,
        resp => {
          if (resp.code && resp.code !== 0) {
            bootbox.alert(resp.message); //eslint-disable-line
          } else {
            bootbox.alert('Updated profile success'); //eslint-disable-line
          }
        },
      );
    } else {
      bootbox.alert(error.join('<br />')); //eslint-disable-line
    }
  };

  checkNumber = e => {
    $(e).keyup(function() {
      $(e).val(this.value.match(/[0-9]*/));
    });
  };

  onChange = resp => {
    if (resp.message) {
      bootbox.alert(resp.message);
      return;
    }
    this.props.updateAvatar({ avatar: resp.Key }, resp => {
      if (resp.code && resp.code !== 0) {
        bootbox.alert(resp.message); //eslint-disable-line
      } else {
        bootbox.alert('Updated avatar success'); //eslint-disable-line
      }
    });
    this.setState({
      dataForm: {
        ...this.state.dataForm,
        ['avatar']: resp.Location,
      },
    });
  };

  render() {
    const { dataProfile } = this.props; // eslint-disable-line

    if (dataProfile === null || dataProfile.length === 0) {
      return (
        <div className="mainContentWrapper">
          <div className="container text-center">
            <h1>No data ... </h1>
          </div>
        </div>
      );
    }

    const profiles = dataProfile.profile;
    const obGender = dataProfile.dataSelect.gender;
    const obCurrency = dataProfile.dataSelect.currency;
    const obLanguage = dataProfile.dataSelect.language;
    const obNational = dataProfile.dataSelect.country;
    const obReligion = dataProfile.dataSelect.religion;
    const obJob = dataProfile.dataSelect.job;
    let email = '';
    let userName = '';

    if (this.props.user && !this.props.user.error) {
      if (this.props.user.user != null) {
        email = this.props.user.user.email;
        userName = this.props.user.user.username;
      }
    }

    const gender = Object.keys(obGender).map(i => {
      let selected = '';
      if (this.state.dataForm.sex) {
        selected = this.state.dataForm.sex === i;
      }
      return (
        <option key={i} value={i} selected={selected}>
          {obGender[i]}
        </option>
      );
    });

    const currency = Object.keys(obCurrency).map(i => {
      let selected = '';
      if (this.state.dataForm.currency) {
        selected = parseFloat(this.state.dataForm.currency) === parseFloat(i);
      }
      return (
        <option key={i} value={i} selected={selected}>
          {obCurrency[i]}
        </option>
      );
    });

    const language = Object.keys(obLanguage).map(i => {
      let selected = '';
      if (this.state.dataForm.language) {
        selected = parseFloat(this.state.dataForm.language) === parseFloat(i);
      }
      return (
        <option key={i} value={i} selected={selected}>
          {obLanguage[i]}
        </option>
      );
    });

    const country = Object.keys(obNational).map(i => {
      let selected = '';
      if (this.state.dataForm.country) {
        selected = parseFloat(this.state.dataForm.country) === parseFloat(i);
      }
      return (
        <option key={i} value={i} selected={selected}>
          {obNational[i]}
        </option>
      );
    });

    const religion = Object.keys(obReligion).map(i => {
      let selected = '';
      if (this.state.dataForm.religion) {
        selected = parseFloat(this.state.dataForm.religion) === parseFloat(i);
      }
      return (
        <option key={i} value={i} selected={selected}>
          {obReligion[i]}
        </option>
      );
    });

    const job = Object.keys(obJob).map(i => {
      let selected = '';
      if (this.state.dataForm.job) {
        selected = parseFloat(this.state.dataForm.job) === parseFloat(i);
      }
      return (
        <option key={i} value={i} selected={selected}>
          {obJob[i]}
        </option>
      );
    });

    let pageTitle = '';

    if (this.state.dataForm.firstName || this.state.dataForm.lastName) {
      pageTitle = (
        <div className={s.pageTitle}>
          <h1 className={'container'}>
            {this.state.dataForm.firstName} {this.state.dataForm.lastName}
          </h1>
        </div>
      );
    } else {
      pageTitle = '';
    }

    let uploadS3Html;

    if (this.props.user && !this.props.user.error) {
      if (this.props.user.user != null) {
        uploadS3Html = (
          <UploadS3
            s3Path={`${config.imageFolder.userAvatar}/${this.props.user.user
              .identityId}`}
            onChange={this.onChange}
          />
        );
      }
    }

    return (
      <div className="main-content-wrapper">
        {pageTitle}
        <div className="container">
          <Validation.components.Form
            ref={c => {
              this.form = c;
            }}
            onSubmit={this.handleSubmit}
          >
            <div className={s.userProfileItem}>
              <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <div className={s.center}>
                    <div className={s.imgPreview}>
                      <div
                        className={s.imgProfile}
                        style={{
                          backgroundImage:
                            'url("' + this.state.dataForm.avatar + '")',
                          backgroundSize: 'cover',
                          backgroundPosition: 'center',
                          backgroundRepeat: 'no-repeat',
                        }}
                      />
                      <div className={cx(s.btnUpload, s.center)}>
                        {uploadS3Html}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className={s.userProfileItem}>
              <label htmlFor="label" className={s.label}>
                NAME
              </label>
              <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <Validation.components.Input
                    value={this.state.dataForm.firstName || ''}
                    name="firstName"
                    validations={['firstName']}
                    className="form-control"
                    autoFocus
                    placeholder="First name *"
                    errorClassName={'is-invalid-input'}
                    onChange={this.setDataForm}
                  />
                </div>
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <Validation.components.Input
                    value={this.state.dataForm.lastName || ''}
                    name="lastName"
                    validations={['lastName']}
                    className="form-control"
                    placeholder="Last name *"
                    errorClassName={'is-invalid-input'}
                    onChange={this.setDataForm}
                  />
                </div>
              </div>
              {/*<div className="row">
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <input
                    type="text"
                    className="form-control"
                    name="nickName"
                    placeholder="Nick name"
                    value={this.state.dataForm.nickName || ''}
                    onChange={this.setDataForm}
                  />
                </div>
              </div>*/}
            </div>

            <div className={s.userProfileItem}>
              <label htmlFor="label" className={s.label}>
                CONTACT
              </label>
              <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <input
                    disabled
                    type="text"
                    className="form-control"
                    name="contact"
                    value={userName || ''}
                  />
                </div>
              </div>
              <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <input
                    disabled
                    type="text"
                    className="form-control"
                    name="contact"
                    value={email || ''}
                  />
                </div>
              </div>
            </div>

            <div className={s.userProfileItem}>
              <label htmlFor="label" className={s.label}>
                OTHER INFOMATION
              </label>
              <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <div className="has-feedback">
                    <DatePicker
                      type="text"
                      aria-describedby="inputSuccess2Status"
                      className="form-control"
                      name="birthday"
                      dateFormat="YYYY/MM/DD"
                      selected={
                        this.state.dataForm.birthday
                          ? moment(this.state.dataForm.birthday)
                          : ''
                      }
                      placeholderText="Select date *"
                      readOnly
                      onChange={this.handleChange}
                    />
                    <style
                      // eslint-disable-next-line
                      dangerouslySetInnerHTML={{
                        __html:
                          '.react-datepicker__input-container { width: 100% }',
                      }}
                    />
                    <span
                      className="glyphicon glyphicon-calendar form-control-feedback"
                      aria-hidden="true"
                    />
                  </div>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <select
                    className={cx('form-control')}
                    name="sex"
                    onChange={this.setDataForm}
                    defaultValue={this.state.dataForm.sex}
                  >
                    {gender}
                  </select>
                </div>
              </div>

              <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <select
                    className={cx('form-control')}
                    defaultValue={this.state.dataForm.country}
                    name="country"
                    placeholder="Nationality"
                    onChange={this.setDataForm}
                  >
                    {country}
                  </select>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <div className="row">
                    <div className="col-xs-7 col-sm-7 col-md-7">
                      <input
                        type="text"
                        className="form-control"
                        name="income"
                        placeholder="Annual income"
                        value={this.state.dataForm.income || ''}
                        onChange={this.setDataForm}
                      />
                    </div>
                    <div className="col-xs-5 col-sm-5 col-md-5">
                      <select
                        className={cx('form-control')}
                        defaultValue={this.state.dataForm.currency}
                        name="currency"
                        placeholder="Currency"
                        onChange={this.setDataForm}
                      >
                        {currency}
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <select
                    className={cx('form-control')}
                    defaultValue={this.state.dataForm.language}
                    name="language"
                    placeholder="Language"
                    onChange={this.setDataForm}
                  >
                    {language}
                  </select>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <select
                    className={cx('form-control')}
                    defaultValue={this.state.dataForm.religion}
                    name="religion"
                    onChange={this.setDataForm}
                    placeholder="Religion"
                  >
                    {religion}
                  </select>
                </div>
              </div>

              <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-6 form-group">
                  <select
                    className={cx('form-control')}
                    defaultValue={this.state.dataForm.job}
                    name="job"
                    onChange={this.setDataForm}
                    placeholder="Job"
                  >
                    {job}
                  </select>
                </div>
              </div>
            </div>

            <div className={s.userProfileItem}>
              <label htmlFor="label" className={s.label}>
                MY PRIVACY
              </label>
              <div className="row">
                <div className="col-xs-12 col-sm-5 col-md-5 form-group">
                  <ShowPublication
                    setPub={this.setPublication}
                    publicLevel={profiles.publicLevel}
                  />
                </div>
              </div>
            </div>

            <div className={s.userProfileItem}>
              <label htmlFor="label" className={s.label}>
                CONNECT TO ME VIA
              </label>
              <div className="row">
                <div className="col-xs-12 col-sm-5 col-md-5 form-group">
                  <FacebookLogin
                    socialId={facebook.clientId}
                    scope="public_profile,email"
                    responseHandler={this.responseFacebook.bind(this)}
                    version="v2.9"
                    cookie
                    xfbml
                    s={s}
                    buttonText="Facebook"
                  />
                </div>
                <div className="col-xs-12 col-sm-1" />
                <div className="col-xs-12 col-sm-5 col-md-5 form-group">
                  <GoogleLogin
                    clientId={google.clientId}
                    onSuccess={this.responseGoogle.bind(this)}
                    offline={false}
                    s={s}
                    approvalPrompt="force"
                    responseType="id_token"
                    isSignedIn
                  >
                    <span>Google</span>
                  </GoogleLogin>
                </div>
                <div className="col-xs-12 col-sm-1" />
              </div>
            </div>

            <div className="row">
              <div className="col-xs-12 col-sm-5 col-md-5 form-group">
                <button
                  className={cx(s.btnIcon, s.btnSave, 'btn btn-primary')}
                  type="button"
                  onClick={this.handleSubmit}
                >
                  <span
                    className={cx(
                      'glyphicon glyphicon-floppy-save',
                      s.glyphicon,
                    )}
                    aria-hidden="true"
                  />
                  <span>Save</span>
                </button>
              </div>
            </div>
          </Validation.components.Form>
        </div>
      </div>
    );
  }
}

Profile.propTypes = {
  user: PropTypes.object, // eslint-disable-line
  profileGet: PropTypes.func,
  profilePut: PropTypes.func,
  updateAvatar: PropTypes.func,
  mappingGoogle: PropTypes.func.isRequired,
  mappingFacebook: PropTypes.func.isRequired,
};

const mapState = state => ({
  loading: state.profile.loading,
  dataProfile: state.profile.profile,
  user: state.user,
});

const mapDispatch = {
  profileGet,
  profilePut,
  updateAvatar,
  mappingGoogle,
  mappingFacebook,
};

export default connect(mapState, mapDispatch)(withStyles(s)(Profile));
