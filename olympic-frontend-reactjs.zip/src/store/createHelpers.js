export default function createHelpers({ fetch, history }) {
  return {
    fetch,
    history,
  };
}
