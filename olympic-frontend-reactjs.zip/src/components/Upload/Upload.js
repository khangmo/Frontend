/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import s from './Upload.css';

const avatar = 'images/avatar.png';

class ImageUpload extends React.Component {
  constructor(props) {
    super(props);
    this.state = { file: '', imagePreviewUrl: '' };
  }

  _handleSubmit(e) {
    e.preventDefault();
    // TODO: do something with -> this.state.file
    console.log(
      'handle uploading-',
      this.state.file,
      this.state.imagePreviewUrl,
    );
  }

  _handleImageChange(e) {
    e.preventDefault();

    let reader = new FileReader();
    let file = e.target.files[0];

    reader.onloadend = () => {
      this.setState({
        file: file,
        imagePreviewUrl: reader.result,
      });
      this.props.onChangeImage(file, reader.result);
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  }

  render() {
    let { imagePreviewUrl } = this.state;
    let imagePreview = null;
    if (!imagePreviewUrl) {
      imagePreviewUrl = avatar;
    }
    if (imagePreviewUrl) {
      imagePreview = <img src={imagePreviewUrl} />;
    } else {
      // imagePreview = (<div className="previewText">Please select an Image for Preview</div>);
    }

    return (
      <div className="previewComponent">
        {/*<input className="fileInput btn" name="fileImage"
          type="file"
          onChange={(e) => this._handleImageChange(e)} />*/}
        {/*<button className="submitButton"
          type="submit"
          onClick={(e) => this._handleSubmit(e)}>Upload Image</button>*/}
        <div className={s.imgPreview}>
          {imagePreview}
        </div>
      </div>
    );
  }
}

// ReactDOM.render(<ImageUpload />, document.getElementById("mainApp"));

export default withStyles(s)(ImageUpload);
