/**
 * Created by KhangNT on 6/13/2017.
 */
import React from 'react';
import PropTypes from 'prop-types';
import {
  withGoogleMap,
  GoogleMap,
  Marker,
  DirectionsRenderer,
  Polyline,
} from 'react-google-maps';
import config from './config.json';

const SimpleMapExampleGoogleMap = withGoogleMap(props =>
  <GoogleMap zoom={config.zoom} center={props.center}>
    {props.markers.map(
      (marker, index) => <Marker position={marker.position} key={index}/>, // eslint-disable-line
    )}
    {props.polylines.map((polyLine, index) =>
      <Polyline
        path={polyLine.path}
        key={index}
        options={{ strokeColor: polyLine.color, strokeWeight: 4 }}
      />,
    )}
    {props.directions.map((direction, index) =>
      <DirectionsRenderer
        directions={direction.direction}
        key={index} // eslint-disable-line
        options={{
          polylineOptions: { strokeColor: direction.color },
          suppressMarkers: true,
          preserveViewport: false,
        }}
      />,
    )}
  </GoogleMap>,
);

class GoogleMaps extends React.Component {
  render() {
    let center = new google.maps.LatLng({
      // eslint-disable-line
      lat: config.center.lat,
      lng: config.center.lng,
    });
    let { markers } = this.props;
    // Set route to lastest marker position
    if (markers.length >= 1) {
      center = new google.maps.LatLng({
        // eslint-disable-line
        lat: markers[markers.length - 1].position.lat(),
        lng: markers[markers.length - 1].position.lng(),
      });
    }
    return (
      <div className="google-maps">
        <SimpleMapExampleGoogleMap
          containerElement={
            <div
              className="thumbnail"
              style={{ height: '50vh', width: '100%' }}
            />
          }
          mapElement={<div style={{ height: '100%', width: '100%' }} />}
          markers={markers}
          center={center}
          directions={this.props.directions}
          polylines={this.props.polyLines}
        />
      </div>
    );
  }
}

// Specifies the default values for props:
GoogleMaps.defaultProps = {
  markers: [],
  directions: [],
  polyLines: [],
};

GoogleMaps.propTypes = {
  markers: PropTypes.array, // eslint-disable-line
  directions: PropTypes.array, // eslint-disable-line
  polyLines: PropTypes.array, //eslint-disable-line
};

export default GoogleMaps;
