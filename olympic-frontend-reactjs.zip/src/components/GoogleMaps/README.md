### directions
Data type of directions has format JSON like below:
```json
{
  "directions": [
    {
      "direction": direction,
      "color": "red"
    }, {
      "direction": direction,
      "color": "green"
    }, {
      "direction": direction,
      "color": "blue"
    }
  ]
}
```
*direction is result for callback funtion in services of Google Maps, it is likes below:* 
```javascript
  DirectionsService.route({
    origin: originMarker,
    destination: new google.maps.LatLng(place.geometry.location.lat(), place.geometry.location.lng()),
    travelMode: this.state.mode,
  }, (result, status) => {
      //set result to direction of Google Maps
  });
```

### markers
Data type of markers has format JSON like below:
```json
{
  "markers": [
    {
      "location": {
        "lat": 35.700487869791004,
        "lng": 139.77720737457275
      }
    }, {
      "location": {
        "lat": 35.700487869791004,
        "lng": 139.77720737457275
      }
    }, {
      "location": {
        "lat": 35.700487869791004,
        "lng": 139.77720737457275
      }
    }
  ]
 }
```
@Note: if you don't need to set marker, direction on your maps, then set it like below:
```json
{
  "directions": []
}
```

```json
{
  "markers": []
}
```
### Call GoogleMaps Component
```javascript
<GoogleMaps markers={this.props.markers}
 directions={this.props.directions} />
```


