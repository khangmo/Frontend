import React from 'react';
import InfiniteLoader from 'react-infinite-loader';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import s from './ScrollLoader.css';

class ScrollLoader extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [],
    };
  }
  componentDidMount() {
    $('.loader').show();
    this.loadItems(this.props.children);
  }

  loadItems(data) {
    /* just simulating a load of more items from an api here */
    setTimeout(() => {
      let items = this.state.items.slice();
      if (Object.values(data).length) {
        items = items.concat(this.getItems(data));
        this.setState({ items: items });
      }
      $('.loader').hide();
    }, 10);
  }

  handleVisit() {
    $('.loader').show();
    this.props.handleInfiniteLoad(true, resp => {
      if (Object.values(resp).length) {
        this.loadItems(resp);
      } else {
        $('.loader').hide();
      }
    });
  }

  getItems(data) {
    let items = [];
    for (var i = 0; i < Object.values(data).length; i++) {
      items.push(data[i]);
    }

    return items;
  }

  renderList() {
    const { items } = this.state;
    const lists = items.map((item, i) => {
      return (
        <div key={i}>
          {item}
        </div>
      );
    });
    return lists;
  }

  render() {
    return (
      <div>
        <div className={s.contentItems}>
          {this.renderList()}
        </div>
        <div className={s.loaderItems}>
          <InfiniteLoader
            onVisited={() => this.handleVisit()}
            loaderStyle={{ display: 'none' }}
          />
        </div>
      </div>
    );
  }
}

export default withStyles(s)(ScrollLoader);
