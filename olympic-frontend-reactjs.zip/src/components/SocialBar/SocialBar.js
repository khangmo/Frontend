/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import cx from 'classnames';
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import Face from 'react-icons/lib/fa/facebook';
import GooglePlus from 'react-icons/lib/fa/google-plus';
import Globe from 'react-icons/lib/fa/globe';
import Bookmark from 'react-icons/lib/fa/bookmark';
import s from './SocialBar.css'; //eslint-disable-line

class SocialBar extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      classBook: this.props.isBooked ? s.btnBooked : '',
      btn: this.props.isBooked ? 'btn-info' : 'btn-success',
    };
  }

  onBookmarkChange = e => {
    e.preventDefault();
    this.props.onBookmarkChange(action => {
      if (action === 'ADD') {
        this.setState({ classBook: s.btnBooked, btn: 'btn-info' });
      } else {
        this.setState({ classBook: s.btnUnBooked, btn: 'btn-success' });
      }
    });
  };

  render() {
    return (
      <div className="shareOnSocialNetwork">
        <div className="row">
          <div className="col-xs-6 text-left">
            <a>
              <button
                className="btn btn-primary"
                style={{ width: '50px', height: '50px', padding: '6px' }}
              >
                <Face style={{ width: '30px', height: '30px' }} />
              </button>
            </a>
            <a>
              <button
                className="btn btn-danger"
                style={{
                  width: '50px',
                  height: '50px',
                  padding: '6px',
                  marginLeft: '5px',
                }}
              >
                <GooglePlus style={{ width: '30px', height: '30px' }} />
              </button>
            </a>
          </div>
          <div className="col-xs-6 text-right">
            {/*<button
              className={cx(s.btnShare, 'btn btn-primary')}
              data-toggle="modal"
              data-target="#setPublication"
              style={{ width: '50px', height: '50px', padding: '6px' }}
            >
              <Globe style={{ width: '30px', height: '30px' }} />
            </button>*/}
            <button
              className={cx(
                s.btnShare,
                s.btnBookmark,
                this.state.classBook,
                'btn ' + this.state.btn,
              )}
              onClick={this.onBookmarkChange}
            >
              <Bookmark style={{ width: '30px', height: '30px' }} />
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(SocialBar);
