/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

class AlertMessage extends React.Component {
  render() {
    let errorAlert = null;
    if (this.props.user && this.props.user.error) {
      errorAlert = (
        <div className="alert alert-danger">
          {this.props.user.error.message
            ? this.props.user.error.message
            : this.props.user.error}
        </div>
      );
    }
    return (
      <div>
        {errorAlert}
      </div>
    );
  }
}

AlertMessage.propTypes = {
  user: PropTypes.object.isRequired, // eslint-disable-line
};

const mapState = state => ({
  user: state.user,
});

export default connect(mapState)(AlertMessage);
