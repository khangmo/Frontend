/**
 * Modal component
 */

import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from './SlideImages.css';

class SlideImages extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    $('#myCarousel').carousel({
      pause: true,
      interval: false,
    });
  }

  render() {
    const { images } = this.props;
    let slideImage = [];
    if (images) {
      slideImage = Object.values(images).map(function(v, i) {
        let active = 'item';
        if (i === 0) {
          active = 'item active';
        }
        return (
          <div key={i} className={active}>
            <img src={v} alt={v} />
          </div>
        );
      });
    }

    return (
      <div className="modal fade modal-custom" id="viewImage" role="dialog">
        <div className="modal-dialog">
          {/*<!-- Modal content-->*/}
          <div className="modal-content">
            <div className="container">
              <h2>Slide Images</h2>
              <div
                id="myCarousel"
                className={cx(s.slideImage, 'carousel slide')}
                data-ride="carousel"
              >
                {/*<!-- Indicators -->*/}
                <ol className="carousel-indicators">
                  <li
                    data-target="#myCarousel"
                    data-slide-to="0"
                    className="active"
                  />
                  <li data-target="#myCarousel" data-slide-to="1" />
                  <li data-target="#myCarousel" data-slide-to="2" />
                  <li data-target="#myCarousel" data-slide-to="3" />
                </ol>
                {/*<!-- Wrapper for slides -->*/}
                <div className="carousel-inner">
                  {slideImage}
                </div>

                {/*<!-- Left and right controls -->*/}
                <a
                  className="left carousel-control"
                  href="#myCarousel"
                  data-slide="prev"
                >
                  <span className="glyphicon glyphicon-chevron-left" />
                  <span className="sr-only">Previous</span>
                </a>
                <a
                  className="right carousel-control"
                  href="#myCarousel"
                  data-slide="next"
                >
                  <span className="glyphicon glyphicon-chevron-right" />
                  <span className="sr-only">Next</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(SlideImages);
