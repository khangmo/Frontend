import React from 'react';
import ReactList from 'react-list';

class ListScroll extends React.Component {
  // state = {
  //   list: []
  // };

  constructor(props) {
    super(props);
    this.state = {
      list: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    };
  }

  componentWillMount() {
    // loadAccounts(::this.handleAccounts);
    this.setState({ list: [...this.state.list, this.state.list.length + 1] });
  }

  handleScroll = () => {
    this.setState({ list: [...this.state.list, this.state.list.length + 1] });
  };

  renderItem = (index, key) => {
    return <ListItem key={key} number={this.state.list[index]} />;
  };

  render() {
    console.log('this', this.state);
    return (
      <div>
        <h1>Accounts</h1>
        <div style={{ overflow: 'auto', maxHeight: 100 }}>
          <ReactList
            scrollTo={10}
            onScroll={this.handleScroll}
            itemRenderer={this.renderItem}
            length={this.state.list.length}
            type="uniform"
          />
        </div>
      </div>
    );
  }
}

class ListItem extends React.Component {
  render() {
    return (
      <div className="infiniteListItem">
        List item {this.props.number}
      </div>
    );
  }
}

export default ListScroll;
