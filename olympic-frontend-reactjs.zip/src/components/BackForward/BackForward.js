/**
 * Created by KhangNT on 7/11/2017.
 */
import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import FaAngleLeft from 'react-icons/lib/fa/angle-left';

import history from '../../history';

import {
  HOME,
  MY_PROFILE,
  LOGIN,
  SIGNUP,
  PLANS,
  PLAN_ADD,
  PLAN_DESTINATION,
  PLACES,
} from '../../common/path';
import clearPlan from '../../actions/plan/clear';

class BackForward extends React.Component {
  handleClickBackForward = () => {
    const currentPage = history.location.pathname;
    if (currentPage) {
      /* If profile screen then back to Home screen */
      if (currentPage.indexOf(MY_PROFILE) >= 0) {
        history.push(HOME);
      }
      /* If Login screen then back to Home screen */
      if (currentPage.indexOf(LOGIN) >= 0) {
        history.push(HOME);
      }
      /* If Signup screen then back to Home screen */
      if (currentPage.indexOf(SIGNUP) >= 0) {
        history.goBack();
      }
      /* If Create Destination screen then back to Create Plan screen */
      if (currentPage.indexOf(PLAN_DESTINATION) >= 0) {
        history.push(PLAN_ADD);
      } else if (currentPage.indexOf('/destination') >= 0) {
        history.goBack();
      } else if (
        currentPage.indexOf(PLANS) >= 0 ||
        currentPage.indexOf(PLAN_ADD) >= 0
      ) {
        /* If Create Plan screen or Plan Detail screen then back to Home screen */
        history.push(HOME);
      }
      /* If Place Detail screen then back to forward screen */
      if (currentPage.indexOf(PLACES) >= 0) {
        history.goBack();
      }
      /* If Home screen then do nothing */
      if (
        currentPage === '' ||
        currentPage === '/' ||
        currentPage === '/#/' ||
        currentPage === '/home'
      ) {
        /* Do nothing here */
      }
    }
  };

  render() {
    return (
      <FaAngleLeft
        style={{ width: '35px', height: '35px', color: 'white' }}
        onClick={this.handleClickBackForward}
      />
    );
  }
}

BackForward.propTypes = {
  clearPlan: PropTypes.func.isRequired,
  clearSignup: PropTypes.func, // eslint-disable-line
};

const mapState = state => ({
  user: state.user,
});

const mapDispatch = {
  clearPlan,
};

export default connect(mapState, mapDispatch)(BackForward);
