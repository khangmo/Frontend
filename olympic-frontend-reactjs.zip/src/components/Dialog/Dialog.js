/**
 * Created by KhangNT on 7/10/2017.
 */
import React from 'react';
import { connect } from 'react-redux';

class Dialog extends React.Component {
  render() {
    if (
      this.props.spinner &&
      this.props.spinner.loading &&
      this.props.spinner.loading === true
    ) {
      //eslint-disable-line
      return (
        <div className="view-dialog-processing">
          <div
            className="modal modal-static in"
            aria-hidden="true"
            role="dialog"
            id="pleaseWaitDialog"
            data-backdrop="static"
            data-keyboard="false"
            style={{ display: 'block', paddingRight: '17px' }}
          >
            <div
              className="modal-dialog"
              style={{
                marginTop: '20%',
                borderRadius: '5px',
              }}
            >
              <img
                src="/images/curved-bars.svg"
                style={{ width: '50px' }}
                alt="Spinner"
              />
            </div>
          </div>
          <div className="modal-backdrop in" />
        </div>
      );
    }
    return <div />;
  }
}

const mapState = state => ({
  spinner: state.spinner,
});

export default connect(mapState)(Dialog);
