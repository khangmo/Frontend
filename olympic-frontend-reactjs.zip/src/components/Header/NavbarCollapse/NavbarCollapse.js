/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import { connect } from 'react-redux';
import cx from 'classnames';

import { PLACES, PLANS, LOGIN, SIGNUP, SEARCH } from '../../../common/path'; // eslint-disable-line
import s from '../Header.css'; // eslint-disable-line
import MenuLink from '../MenuLink/MenuLink';
import Link from '../../Link/Link';
import { siteName } from '../../../config';

class NavbarCollapse extends React.Component {
  render() {
    let userMenuMobile = '';
    // if((this.props.userAgent.isMobile === true) || (this.props.userAgent.isTable === true)) {
    if (this.props.user.user === null) {
      userMenuMobile = (
        <li className={s.borderNone}>
          <ul className={s.userMenuLink}>
            <li className={s.userMenuItem}>
              <Link to={LOGIN}>LOG IN</Link>
            </li>
            <li className={s.userMenuItem}>
              <Link to={SIGNUP}>
                or SIGN UP to discover Japan on {siteName}
              </Link>
            </li>
          </ul>
        </li>
      );
    } else {
      userMenuMobile = <MenuLink />;
    }
    // }

    return (
      <ul className={cx('nav navbar-nav', s.navbarNav)}>
        <li className={cx(s.menuItem, s.active)}>
          <Link to={PLACES}>Places</Link>
        </li>
        <li className={s.menuItem}>
          <Link to={PLANS}>Plans</Link>
        </li>
        <li className={cx(s.borderNone, s.userMenuItem, s.textNone)}>
          <a />
        </li>
        {userMenuMobile}
      </ul>
    );
  }
}

NavbarCollapse.propTypes = {
  user: PropTypes.object, // eslint-disable-line
};

const mapState = state => ({
  userAgent: state.userAgent.userAgent,
  user: state.user,
});

export default connect(mapState)(withStyles(s)(NavbarCollapse));
