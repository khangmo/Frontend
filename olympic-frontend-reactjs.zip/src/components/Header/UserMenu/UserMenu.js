/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import cx from 'classnames';
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import MenuLink from '../MenuLink/MenuLink';
import s from '../Header.css'; // eslint-disable-line

class UserMenu extends React.Component {
  render() {
    let userEmail;
    if (this.props.user.user) {
      userEmail = this.props.user.user.username;
    }
    return (
      <ul className={cx('nav navbar-nav', s.navbarNav, s.userMenu)}>
        <li className="dropdown">
          <a
            className="dropdown-toggle"
            data-toggle="dropdown"
            role="button"
            aria-haspopup="true"
            aria-expanded="false"
          >
            {userEmail}
            <span className="caret" />
          </a>
          <ul className={cx('dropdown-menu', s.dropdownMenu)}>
            <MenuLink />
          </ul>
        </li>
      </ul>
    );
  }
}

UserMenu.propTypes = {
  user: PropTypes.object, // eslint-disable-line
};

const mapState = state => ({
  user: state.user,
});

export default connect(mapState)(withStyles(s)(UserMenu));
