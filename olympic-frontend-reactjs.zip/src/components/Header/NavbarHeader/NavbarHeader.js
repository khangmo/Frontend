/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import cx from 'classnames';

import s from '../Header.css'; // eslint-disable-line

class NavbarHeader extends React.Component {
  render() {
    return (
      // eslint-disable-next-line
      <button
        type="button"
        className={cx('navbar-toggle hideMenu', s.navbarToggle, s.hideMenu)}
      >
        <span className="sr-only">Toggle navigation</span>
        <span className="icon-bar" />
        <span className="icon-bar" />
        <span className="icon-bar" />
      </button>
    );
  }
}

export default NavbarHeader;
