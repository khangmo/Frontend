/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import Link from '../../Link/Link';
import s from '../Header.css'; // eslint-disable-line

// import SearchBar from '../SearchBar/SearchBar';
import UserMenu from '../UserMenu/UserMenu';
import { LOGIN, SIGNUP, SEARCH } from '../../../common/path';
import history from '../../../history';
import SearchIcon from 'react-icons/lib/fa/search';

class NavbarRight extends React.Component {
  render() {
    let menuRight = '';
    const currentPage = history.location.pathname;
    let searchIcon = '';
    if (currentPage.indexOf('/search') >= 0) {
      searchIcon = '';
    } else {
      searchIcon = (
        <Link to={SEARCH} className={s.notLoggedIn}>
          <SearchIcon />
        </Link>
      );
    }

    if (this.props.user.user === null) {
      // eslint-disable-line
      if (currentPage != LOGIN || currentPage != SIGNUP) {
        menuRight = (
          <Link to={LOGIN} className={s.notLoggedIn}>
            LOG IN
          </Link>
        );
      } else {
        menuRight = '';
      }
    } else if (
      currentPage.indexOf('/login') >= 0 ||
      currentPage.indexOf('/signup') >= 0
    ) {
      menuRight = '';
    } else {
      menuRight = <UserMenu />;
    }

    return (
      <div className={s.navbarRight}>
        {searchIcon}
        {menuRight}
      </div>
    );
  }
}

const mapState = state => ({
  user: state.user,
  path: state.locationPath,
});

export default connect(mapState)(withStyles(s)(NavbarRight));
