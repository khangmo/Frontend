/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import withStyles from 'isomorphic-style-loader/lib/withStyles';

import { SEARCH, MY_PROFILE, LOGOUT, PLAN_ADD } from '../../../common/path';
import s from '../Header.css'; // eslint-disable-line
import logout from '../../../actions/logout';
import Link from '../../Link/Link';

class MenuLink extends React.Component {
  handleLogout = e => {
    e.preventDefault();
    this.props.logout();
  };
  render() {
    return (
      <li className={s.borderNone}>
        <ul className={s.userMenuLink}>
          <li className={s.userMenuItem}>
            <Link to={SEARCH}>My plans</Link>
          </li>
          <li className={s.userMenuItem}>
            <Link to={SEARCH}>My wish list plan</Link>
          </li>
          <li className={s.userMenuItem}>
            <Link to={SEARCH}>My places</Link>
          </li>
          <li className={s.userMenuItem}>
            <Link to={SEARCH}>My wish list place</Link>
          </li>
          <li className={s.userMenuItem}>
            <Link to={MY_PROFILE}>My profile</Link>
          </li>
          <li className={s.userMenuItem}>
            <Link to={PLAN_ADD}>Add new plan</Link>
          </li>
          <li className={s.userMenuItem}>
            <Link to={LOGOUT} onClick={this.handleLogout}>
              Logout
            </Link>
          </li>
        </ul>
      </li>
    );
  }
}

MenuLink.propTypes = {
  logout: PropTypes.func.isRequired,
};

const mapState = state => ({
  user: state.user,
});

const mapDispatch = {
  logout,
};
export default connect(mapState, mapDispatch)(withStyles(s)(MenuLink));
