/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from './Header.css'; //eslint-disable-line

import NavbarCollapse from './NavbarCollapse/NavbarCollapse';
import NavbarRight from './NavbarRight/NavbarRight';
import BackForward from '../BackForward/BackForward';
import history from '../../history';

import {
  PLAN_ADD,
  SIGNUP,
  PLACES,
  PLANS,
  LOGIN,
  MY_PROFILE,
} from '../../common/path';

class Header extends React.Component {
  constructor(props) {
    super(props);
    this.state = { showMenu: false };
    this.toggleMenu = this.toggleMenu.bind(this);
    this.checkTypeButton = this.checkTypeButton.bind(this);
  }

  componentDidMount() {
    window.addEventListener(
      'click',
      event => {
        const id = event.target.id;
        if (id && id === 'menu') {
          /* Do nothing here */
        } else {
          this.toggleMenu(false);
        }
      },
      false,
    );
  }

  toggleMenu = flag => {
    if (flag) {
      this.setState({
        showMenu: !this.state.showMenu,
      });
    } else {
      this.setState({
        showMenu: false,
      });
    }
  };

  checkTypeButton = () => {
    const currentPage = history.location.pathname;
    if (
      currentPage.indexOf(PLAN_ADD) >= 0 ||
      // currentPage.indexOf(PLACES) >= 0 ||
      currentPage.indexOf(LOGIN) >= 0 ||
      currentPage.indexOf(SIGNUP) >= 0 ||
      currentPage.indexOf('/destination') >= 0 ||
      currentPage.indexOf(MY_PROFILE) >= 0 ||
      currentPage.indexOf(PLANS) >= 0
    ) {
      return (
        <div
          className={cx('navbar-toggle', s.navbarToggle)}
          style={{
            float: 'left',
            padding: '0px',
            marginLeft: '-10px',
            border: 'none',
          }}
        >
          <BackForward />
        </div>
      );
    }
    return (
      <button
        id="menu"
        className={cx(
          'navbar-toggle',
          s.navbarToggle,
          s.buttonMenu,
          this.state.showMenu ? s.showMenu : s.hideMenu,
        )} //eslint-disable-line
        onClick={this.toggleMenu.bind(this, true)} //eslint-disable-line
      >
        <span className="sr-only">Toggle navigation</span>
        <span className="icon-bar" />
        <span className="icon-bar" />
        <span className="icon-bar" />
      </button>
    );
  };

  render() {
    const element = this.checkTypeButton();
    return (
      <div className={s.headerWrapper}>
        <div className="container">
          <nav
            className={cx('navbar navbar-default form-group', s.navbarDefault)}
          >
            <div className="">
              <div className="navbar-header">
                {element}
              </div>
              <div
                className={cx(
                  'navbar-collapse',
                  s.navbarCollapse,
                  this.state.showMenu ? s.showMenu : s.hideMenu,
                )}
                id="main-menu"
                onClick={this.toggleMenu}
              >
                <NavbarCollapse />
              </div>
            </div>
            <NavbarRight />
          </nav>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(Header);
