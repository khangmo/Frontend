/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import cx from 'classnames';
import s from '../Header.css';

class SearchBar extends React.Component {
  constructor(props) {
    super(props);
    this.state = { showSearch: false };
  }

  toggleSearch() {
    this.setState({
      showSearch: !this.state.showSearch,
    });
  }

  render() {
    self = this;
    return (
      <div
        className={cx(
          s.searchBar,
          this.state.showSearch ? s.showSearch : s.hideSearch,
        )}
      >
        <div className={cx('search hide', s.search)}>
          <form action="">
            <div className={s.iconSearchLeft}>
              <span className="glyphicon glyphicon-search" />
            </div>
            <input
              className={cx('form-control', s.inputSearch)}
              type="text"
              name="search"
            />
            <div className={s.iconSearchRight}>
              <span className="glyphicon glyphicon-remove-sign" />
            </div>
          </form>
        </div>
        <button
          className={cx(
            s.iconSearch,
            this.state.showSearch ? s.showSearch : s.hideSearch,
          )}
          onClick={() => {
            self.toggleSearch();
          }}
        >
          <span className="glyphicon glyphicon-search" />
        </button>
      </div>
    );
  }
}

export default SearchBar;
