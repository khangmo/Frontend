/**
 * Modal component
 */

import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from './PublicModal.css';
import LockIcon from 'react-icons/lib/fa/lock';
import UnLockIcon from 'react-icons/lib/fa/unlock';

class PublicModal extends React.Component {
  constructor(props) {
    super(props);
    // const { formData } = this.props;
    // this.state = {
    //   publicOption: 'public'
    // };
    // this.publicOption = this.setPublicOption.bind(this);
  }

  setPublicOption = e => {
    this.props.selectPublication($(e.target).data('value'));
  };

  render() {
    return (
      <div
        className={cx('modal fade', s.modalCustom)}
        id="setPublication"
        role="dialog"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-body">
              <button type="button" className="close" data-dismiss="modal">
                &times;
              </button>
              <div className={s.puplicOption}>
                <ul className="menu-item">
                  <li className={s.puplicOptionItem}>
                    <a
                      onClick={this.setPublicOption}
                      data-value="PUBLIC"
                      className="text-uppercase"
                      data-dismiss="modal"
                    >
                      <span className={cx(s.glyphicon, s.disableEventPointer)}>
                        <UnLockIcon />
                      </span>
                      <span className={s.disableEventPointer}>Public</span>
                    </a>
                  </li>
                  <li className={s.puplicOptionItem}>
                    <a
                      onClick={this.setPublicOption}
                      data-value="ONLY_ME"
                      className="text-uppercase"
                      data-dismiss="modal"
                    >
                      <span className={cx(s.glyphicon, s.disableEventPointer)}>
                        <LockIcon />
                      </span>
                      <span className={s.disableEventPointer}>Only me</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(PublicModal);
