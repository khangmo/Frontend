/**
 * Transit component
 */

import React from 'react'; //eslint-disable-line
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import s from '../../routes/plan/Plan.css'; //eslint-disable-line
import { checkTransitType, getFormatInfoZenrin } from '../../common/common';
import FaTrain from 'react-icons/lib/fa/train';
import { NEW_ICON_TRANSIT } from '../../constants/icons';

class Transit extends React.Component {
  convertMinutes = time => {
    if (time) {
      let minutes = time % 60;
      let hours = (time - minutes) / 60;
      minutes = minutes < 10 ? `0${minutes}` : minutes;
      hours = hours < 10 ? `0${hours}` : hours;
      return `${hours}:${minutes}`;
    }
    return '00:00';
  };

  render() {
    const { isIdTarget, transit, location } = this.props;
    if (
      !transit ||
      !Object.prototype.hasOwnProperty.call(transit, 'response')
    ) {
      return <div />;
    }
    const response = transit.response;
    const values = response.nodes;
    if (!values) {
      return <div />;
    }
    const title = `Distance ${response.distance /
      1000} km in ${this.convertMinutes(response.totalTime)}`;
    let listItems = [];
    Object.values(values).map((value, index) => {
      const transitType = checkTransitType(value.nodeType);
      const formatText = getFormatInfoZenrin(value);
      return listItems.push(
        <div
          className="list-group-item"
          style={{
            padding: '5px 2px',
            fontSize: '11px',
            border: '1px solid #f3f3f3',
          }}
          key={index}
        >
          <img src={transitType.icon} width="20" high="20" />
          {`  ${formatText}`}
        </div>,
      );
    });
    const valueHtml = (
      <div
        className="row"
        key={transit.place_id}
        data-key={'dataKey-' + transit.place_id}
      >
        <div className="col-xs-12 col-sm-12 col-md-12">
          <div
            className="row"
            style={{ marginRight: '0px', marginLeft: '0px' }}
          >
            <div
              className="timeline-panel"
              style={{
                padding: '5px 5px',
                border: '1px solid #d4d4d4',
                borderRadius: '5px',
                backgroundColor: '#f5f5f5',
                marginLeft: '30px',
                marginRight: '15px',
              }}
            >
              <div
                className="timeline-heading"
                style={{
                  backgroundColor: 'rgb(228, 228, 228)',
                  borderRadius: '3px',
                }}
              >
                <div
                  className="timeline-title"
                  style={{
                    padding: '5px',
                    fontWeight: 'bold',
                    color: '#676767',
                    height: '40px',
                  }}
                >
                  <div style={{ margin: '5px', float: 'left' }}>
                    {title}
                  </div>
                  <div className="dropdown pull-right">
                    <button
                      className="btn btn-primary btn-sm dropdown-toggle"
                      type="button"
                      data-toggle="dropdown"
                    >
                      <FaTrain />
                    </button>
                    <ul className="dropdown-menu">
                      <li>
                        <a
                          onClick={this.props.selectTransit.bind(this, {
                            destinationId: location.createDestinationId,
                            transitType: 'walk',
                          })}
                        >
                          <img
                            src={NEW_ICON_TRANSIT.WALK}
                            style={{
                              height: '20px',
                              width: '20px',
                              marginRight: '10px',
                            }}
                            alt="Walk"
                          />Walk
                        </a>
                      </li>
                      <li role="presentation" className="divider" />
                      <li>
                        <a
                          onClick={this.props.selectTransit.bind(this, {
                            destinationId: location.createDestinationId,
                            transitType: 'drive',
                          })}
                        >
                          <img
                            src={NEW_ICON_TRANSIT.DRIVE}
                            style={{
                              height: '20px',
                              width: '20px',
                              marginRight: '10px',
                            }}
                            alt="Drive"
                          />Drive
                        </a>
                      </li>
                      <li role="presentation" className="divider" />
                      <li>
                        <a
                          onClick={this.props.selectTransit.bind(this, {
                            destinationId: location.createDestinationId,
                            transitType: 'other',
                          })}
                        >
                          <img
                            src={NEW_ICON_TRANSIT.RAIL}
                            style={{
                              height: '20px',
                              width: '20px',
                              marginRight: '10px',
                            }}
                            alt="Other"
                          />Other
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="timeline-body">
                <div className="list-group" style={{ margin: '2px 0px' }}>
                  {listItems}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );

    return (
      <div>
        <div className="row" style={{ marginTop: '10px'}}>
          <div className="col-xs-2 col-sm-2 col-md-2" />
          <div className="col-xs-10 col-sm-10 col-md-10">
            <div
              className="out collapse"
              id={'target-' + isIdTarget}
              aria-expanded="false"
            >
              {valueHtml}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

Transit.propTypes = {
  isDisplay: PropTypes.bool,
  isIdTarget: PropTypes.string,
  transition: PropTypes.array,
  selectTransit: PropTypes.func,
};

export default withStyles(s)(Transit);
