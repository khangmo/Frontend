/**
 * Modal component
 */

import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from './ShowPublication.css';

import PublicModal from '../PublicModal/PublicModal';
import LockIcon from 'react-icons/lib/fa/lock';
import UnLockIcon from 'react-icons/lib/fa/unlock';

class ShowPublication extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      setPublic: (
        <button
          type="button"
          className={cx(s.btnIcon, 'btn btn-default')}
          data-toggle="modal"
          data-target="#setPublication"
        >
          <span className={s.glyphicon}>
            <UnLockIcon />
          </span>
          <span>Public</span>
        </button>
      ),
    };
  }

  componentWillMount() {
    const { publicLevel } = this.props;
    const onlyMe = (
      <button
        type="button"
        className={cx(s.btnIcon, 'btn btn-default')}
        data-toggle="modal"
        data-target="#setPublication"
      >
        <span className={s.glyphicon}>
          <LockIcon />
        </span>
        <span>Only me</span>
      </button>
    );
    if (publicLevel === 'ONLY_ME') {
      this.setState({ setPublic: onlyMe });
    }
  }

  selectPublicItem = data => {
    const pr = (
      <button
        type="button"
        className={cx(s.btnIcon, 'btn btn-default')}
        data-toggle="modal"
        data-target="#setPublication"
      >
        <span className={s.glyphicon}>
          <LockIcon />
        </span>
        <span>Only me</span>
      </button>
    );
    const pb = (
      <button
        type="button"
        className={cx(s.btnIcon, 'btn btn-default')}
        data-toggle="modal"
        data-target="#setPublication"
      >
        <span className={s.glyphicon}>
          <UnLockIcon />
        </span>
        <span>Public</span>
      </button>
    );

    if (data === 'ONLY_ME') {
      this.setState({ setPublic: pr });
    } else this.setState({ setPublic: pb });
    //Set publication value
    this.props.setPub(data);
  };

  render() {
    return (
      <div>
        {this.state.setPublic}
        <PublicModal selectPublication={this.selectPublicItem} />
      </div>
    );
  }
}

export default withStyles(s)(ShowPublication);
