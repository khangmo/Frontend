/**
 * Day component
 */

import React from 'react'; //eslint-disable-line
import PropTypes from 'prop-types';
import Location from '../Location/Location';
import Transit from '../Transit/Transit';
import s from '../../routes/plan/Plan.css';

class Day extends React.Component {
  render() {
    const { dayData } = this.props;
    const fullDate = new Date(dayData[0].date);
    const date =
      fullDate.getFullYear() +
      '/' +
      (fullDate.getMonth() + 1 < 10
        ? `0${fullDate.getMonth() + 1}`
        : fullDate.getMonth() + 1) +
      '/' +
      (fullDate.getDate() < 10 ? `0${fullDate.getDate()}` : fullDate.getDate());

    const details = [];

    for (var i = 0; i < Object.values(dayData).length; i++) {
      const currentDay = dayData[i];
      let transitObject = '';
      let isDisplayTransit = false;
      Object.values(this.props.transits).map(transit => {
        if (transit.placeId == currentDay.map.place_id) {
          isDisplayTransit = true;
          transitObject = transit;
        }
      });
      const targetId = Math.random()
        .toString(36)
        .replace(/[^a-z]+/g, '')
        .substr(0, 11);
      details.push(
        <DayDetail
          key={i}
          location={currentDay}
          targetId={targetId}
          transitObject={transitObject}
          isDisplayTransit={isDisplayTransit}
          selectTransit={this.props.selectTransit}
        />,
      );
    }

    return (
      <div>
        <div className="row">
          <div className="col-sm-12">
            <div className="out">
              <h4 className={s.dayHeader}>
                {date}
              </h4>
              {details}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

class DayDetail extends React.Component {
  render() {
    const {
      location,
      transitObject,
      targetId,
      isDisplayTransit,
      selectTransit,
    } = this.props;
    return (
      <div>
        <Location
          location={location}
          isIdTaget={targetId}
          isDisplayTransit={isDisplayTransit}
        />
        <Transit
          transit={transitObject}
          isIdTarget={targetId}
          location={location}
          selectTransit={selectTransit}
        />
      </div>
    );
  }
}

Day.propTypes = {
  data: PropTypes.array,
};

export default Day;
