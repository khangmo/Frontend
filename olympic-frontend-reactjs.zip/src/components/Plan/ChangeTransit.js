/**
 * Created by KhangNT on 8/25/2017.
 */
import React from 'react'; //eslint-disable-line
import FaTrain from 'react-icons/lib/fa/train';
import { NEW_ICON_TRANSIT } from '../../constants/icons';

class ChangeTransit extends React.Component {
  render() {
    return (
      <div
        className="dropdown pull-right change-transit-component"
        id={this.props.id}
        style={{
          position: 'inherit',
          bottom: '-80px',
        }}
      >
        <button
          className="btn btn-primary btn-sm dropdown-toggle"
          type="button"
          data-toggle="dropdown"
        >
          <FaTrain />
        </button>
        <ul className="dropdown-menu" style={{ left: '0px' }}>
          <li style={{ padding: '0px' }}>
            <a
              onClick={this.props.selectTransit.bind(this, {
                destinationId: location.createDestinationId,
                transitType: 'walk',
              })}
            >
              <img
                src={NEW_ICON_TRANSIT.WALK}
                style={{
                  height: '20px',
                  width: '20px',
                  marginRight: '10px',
                }}
                alt="Walk"
              />Walk
            </a>
          </li>
          <li className="divider" style={{ padding: '0px' }} />
          <li style={{ padding: '0px' }}>
            <a
              onClick={this.props.selectTransit.bind(this, {
                destinationId: location.createDestinationId,
                transitType: 'drive',
              })}
            >
              <img
                src={NEW_ICON_TRANSIT.DRIVE}
                style={{
                  height: '20px',
                  width: '20px',
                  marginRight: '10px',
                }}
                alt="Drive"
              />Drive
            </a>
          </li>
          <li className="divider" style={{ padding: '0px' }} />
          <li style={{ padding: '0px' }}>
            <a
              onClick={this.props.selectTransit.bind(this, {
                destinationId: location.createDestinationId,
                transitType: 'other',
              })}
            >
              <img
                src={NEW_ICON_TRANSIT.RAIL}
                style={{
                  height: '20px',
                  width: '20px',
                  marginRight: '10px',
                }}
                alt="Other"
              />Other
            </a>
          </li>
        </ul>
      </div>
    );
  }
}

export default ChangeTransit;
