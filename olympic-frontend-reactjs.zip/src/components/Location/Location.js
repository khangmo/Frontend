/**
 * Location component
 */

import React from 'react';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from '../../routes/plan/Plan.css';
import history from '../../history';

class Location extends React.Component {
  constructor(props) {
    super(props);
    this.updateDetination = this.updateDetination.bind(this);
  }

  updateDetination() {
    const locationData = this.props.location;
    const destinationId = locationData.createDestinationId;
    //move destination with it's self id
    history.push('/destination/edit/' + destinationId);
  }

  // Fill data vao man hinh create destination

  render() {
    const data = this.props.location;
    const isIdTaget = this.props.isIdTaget;

    var btnPlus = '';
    if (this.props.isDisplayTransit) {
      btnPlus = (
        <div
          className={cx(s.avt, 'collapsed')}
          data-toggle="collapse"
          data-target={'#target-' + isIdTaget}
          aria-expanded="false"
          style={{ marginTop: '20px' }}
        >
          <span className="glyphicon glyphicon-plus-sign" />
        </div>
      );
    }

    let stay = '';
    if (parseFloat(data.stay)) {
      stay =
        parseFloat(data.stay) === 1
          ? data.stay + ' hour'
          : data.stay + ' hours';
    }

    return (
      <div style={{ marginTop: '10px' }}>
        <div className="row">
          <div className="col-xs-2 col-sm-2 col-md-2">
            {btnPlus}
          </div>
          <div className="col-xs-10 col-sm-10 col-md-10">
            <div
              className={s.rowLocation}
              onClick={this.updateDetination.bind(
                this,
                data.createDestinationId,
              )}
            >
              <div className="rowLocationInfo">
                <label>Location: &nbsp;</label>
                <div className={s.inline}>
                  {data.title}
                </div>
              </div>
              <div className="rowLocationInfo">
                <label>Start time: &nbsp;</label>
                <div className={s.inline}>
                  {data.start || '09:00'}
                </div>
              </div>
              <div className="rowLocationInfo">
                <label>Stay: &nbsp;</label>
                <div className={s.inline}>
                  {stay}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default withStyles(s)(Location);
