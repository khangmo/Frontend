/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 * use: <Comment dataComment={this.state.planDetail || placesDetail}
          item={'plans' || 'places'} />
 */

import React from 'react';
import { connect } from 'react-redux';
import Rater from 'react-rater';
import moment from 'moment';
// import PropTypes from 'prop-types';
import history from '../../history';

import commentPost from '../../actions/comment/update';
import commentGet from '../../actions/comment/get';
import commentTemp from '../../actions/comment/temp';
import clearComment from '../../actions/comment/clear';
import { LOGIN } from '../../common/path';
import { isLogin } from '../../common/common';

import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import s from './Comment.css';

import CameraIcon from 'react-icons/lib/fa/camera';

const avt = 'images/avatar.png';

class Comment extends React.Component {
  constructor(props) {
    super(props);
    const { dataComment, item, dataTemp, itemId } = this.props;
    this.state = {
      fetching: false,
      content: dataTemp ? dataTemp.content : '',
      rating: dataTemp ? dataTemp.rating : 0,
      photo: '',
      myReview: dataComment.myreview || {},
      editMyReview: false,
      isDelete: false,
      item,
      itemId,
      reviews: dataComment.reviews ? dataComment.reviews.content : [],
      page: dataComment.reviews ? dataComment.reviews.number : 0,
      totalPages: dataComment.reviews ? dataComment.reviews.totalPages : 0,
      size: 10,
      totalUserRating: dataComment.totalUserRating || 0,
      ratingAverage: dataComment.ratingAverage || 0,
    };
  }

  checkLogin = () => {
    const user = this.props.user;
    if (!user.loading && !this.state.fetching) {
      if (!isLogin(user.user)) {
        return false;
      } else {
        return true;
      }
    }
  };

  setDataComment = e => {
    const { itemId } = this.state;
    this.setState({
      content: e.target.value,
      itemId: itemId,
    });
  };

  deleteComment = e => {
    if (!this.checkLogin()) {
      return;
    }

    const { item, itemId } = this.state;
    const that = e.target;
    const userId = $(that).data('userid');
    const data = {
      itemId: itemId,
      userId: userId,
    };

    bootbox.confirm(
      'Are you sure you want to delete?',
      function(flag) {
        if (flag) {
          this.props.commentPost(
            data,
            item,
            'delete',
            function(resp) {
              if (resp.code && resp.code !== 0) {
                this.setState({
                  isDelete: true,
                  myReview: resp,
                  editMyReview: false,
                  totalUserRating: resp.totalRating,
                  ratingAverage: resp.averageRating,
                });
                this.props.onComment(resp);
              } else {
                bootbox.alert('Delete not success');
              }
            }.bind(this),
          );
        }
      }.bind(this),
    );
  };

  editCommentForm = e => {
    if (!this.checkLogin()) {
      return;
    }

    const { myReview, itemId } = this.state;
    this.setState({
      editMyReview: true,
      itemId: itemId,
      content: myReview.content,
      rating: myReview.rating,
      photo: myReview.photo,
    });
  };

  handleRating = rating => {
    this.setState({ rating: rating.rating });
  };

  handleSubmit = e => {
    e.preventDefault();
    if (!this.state.rating) {
      bootbox.alert('Rating is not empty');
      return;
    }
    if (
      !this.state.content ||
      (this.state.content && !this.state.content.trim())
    ) {
      bootbox.alert('Comment is not empty');
      return;
    }

    //# Check Login to write review
    if (!this.checkLogin()) {
      const temp = {
        content: this.state.content,
        rating: this.state.rating,
      };
      bootbox.confirm(
        'You must login to write review. Do you want to login?',
        function(flag) {
          if (flag) {
            this.props.commentTemp(temp);
            history.push(LOGIN);
          }
        }.bind(this),
      );
      return;
    }

    if (this.props.dataTemp && this.props.dataTemp.length) {
      this.props.clearComment();
    }

    const { item, itemId } = this.state;
    let action = 'add';
    if (this.state.editMyReview) {
      action = 'edit';
    }
    this.props.commentPost(
      this.state,
      item,
      action,
      function(resp) {
        if (action === 'edit') {
          this.setState({
            isDelete: false,
            myReview: resp,
            editMyReview: false,
            totalUserRating: resp.totalRating,
            ratingAverage: resp.averageRating,
            rating: 0,
            content: '',
          });
        } else {
          this.setState({
            isDelete: false,
            myReview: resp,
            totalUserRating: resp.totalRating,
            ratingAverage: resp.averageRating,
            rating: 0,
            content: '',
          });
        }
        this.props.onComment(resp);
      }.bind(this),
    );
  };

  showMoreComment = e => {
    const { item, itemId, page, size, totalPages } = this.state;
    const pageNumber = parseFloat(page + 1);
    if (totalPages > pageNumber) {
      this.props.commentGet(itemId, item, pageNumber, size, resp => {
        if (resp && resp.content.length) {
          this.setState({
            reviews: [...this.state.reviews, resp.content],
            page: resp.number,
            totalPages: resp.totalPages,
          });
        }
      });
    }
  };

  render() {
    const { isDelete, reviews, page, totalPages } = this.state;
    const { dataComment } = this.props;
    let myReview = Object.keys(this.state.myReview).length
      ? this.state.myReview
      : dataComment.myreview;
    if (isDelete || !this.checkLogin()) {
      myReview = {};
    }

    //# if (currentComment && Object.values(currentComment).length) {
    //#   dataComment.unshift(currentComment);
    //#   this.clearState();
    //# }

    let htm = '';
    if (reviews && Object.values(reviews).length > 0) {
      let count = 0;
      htm = Object.values(reviews).map(
        function(v) {
          count++;
          let img = '';
          if (v.photo) {
            img = <img src={v.photo} className={s.imgComment} />;
          }

          return (
            <EachComment
              key={count}
              data={v}
              image={img}
              count={count}
              delFn={this.deleteComment}
            />
          );
        }.bind(this),
      );
    }

    let form = (
      <form className={cx('form-group')} onSubmit={this.handleSubmit}>
        <div className="row form-group">
          <div className="col-xs-2 col-sm-2 col-md-2">
            <div className="plan-label">Rate</div>
          </div>
          <div className="col-xs-10 col-sm-10 col-md-10">
            <div className={cx('text-left')}>
              <Rater rating={this.state.rating} onRate={this.handleRating} />
            </div>
          </div>
        </div>
        <hr />
        <div className="row form-group">
          <div className="col-xs-12 col-sm-12 col-md-12">
            <table className={s.tb}>
              <tbody>
                <tr>
                  <td>
                    <button
                      data-toggle="modal"
                      data-target="#insertImage"
                      className="btn btn-primary"
                      type="button"
                    >
                      <span className={s.glyphicon}>
                        <CameraIcon />
                      </span>
                    </button>
                  </td>
                  <td>
                    <div className="input-group inputTextComment pull-right">
                      <input
                        type="text"
                        name="content"
                        className="form-control"
                        value={this.state.content}
                        placeholder="Write a comment"
                        onChange={this.setDataComment}
                      />
                      <span className="input-group-btn">
                        <button
                          className="btn btn-primary"
                          type="button"
                          onClick={this.handleSubmit}
                        >
                          Send
                        </button>
                      </span>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <hr />
      </form>
    );

    if (
      myReview &&
      Object.keys(myReview).length > 0 &&
      !this.state.editMyReview
    ) {
      let image = '';
      if (myReview.photo) {
        image = <img src={myReview.photo} className={s.imgComment} />;
      }
      form = (
        <EachComment
          key={1}
          data={myReview}
          image={image}
          count={1}
          isReview={true}
          editFn={this.editCommentForm}
          delFn={this.deleteComment}
        />
      );
    }

    let btnShowMore = '';
    const pageNumber = parseFloat(page + 1);

    if (totalPages > pageNumber) {
      btnShowMore = (
        <button
          className={cx(s.btn, 'btn btn-info')}
          onClick={this.showMoreComment}
          type="button"
        >
          <span
            className="glyphicon glyphicon-retweet"
            aria-hidden="true"
          />{' '}
          Show more
        </button>
      );
    }

    return (
      <div className={s.rate}>
        <div className={s.titleHeader}>
          <div className={s.rowTitle}>
            <strong>Rating</strong>
          </div>
        </div>
        <div className="ratingContent">
          <div>
            <div className="row">
              <div className="col-xs-12 col-sm-12 col-md-12">
                <div className="row">
                  <div className="col-xs-12 col-sm-12 col-md-12">
                    <div className="">
                      <div className="plan-label">
                        {this.state.totalUserRating || 0} USER RATED
                      </div>
                    </div>
                  </div>
                </div>
                <div className={cx('row form-group')}>
                  <div className="col-xs-12 col-sm-12 col-md-12">
                    <div className={cx('text-left')}>
                      <Rater
                        className="react-rater notChoose"
                        rating={this.state.ratingAverage || 0}
                        interactive={false}
                      />
                    </div>
                  </div>
                </div>
                <hr />
                {form}
                <div className="comments">
                  {htm}
                </div>

                <div className="row form-group">
                  <div className="col-xs-12 col-md-5">
                    {btnShowMore}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

class EachComment extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { data, image, count, isReview, editFn, delFn } = this.props;
    let editBtn = '';
    let delBtn = '';
    if (isReview) {
      editBtn = (
        <button type="button" className="btn btn-default">
          <span
            title="Edit"
            onClick={editFn}
            className="glyphicon glyphicon-pencil"
          />
        </button>
      );

      delBtn = (
        <button type="button" className="btn btn-default">
          <span
            data-userid={data.userId}
            title="Remove"
            onClick={delFn}
            className="glyphicon glyphicon-remove"
          />
        </button>
      );
    }

    return (
      <div key={count} className="col-xs-12 col-sm-12 col-md-12">
        <div className={cx('row form-group', isReview ? s.myReview : '')}>
          <div className="col-xs-3 col-sm-3 col-md-3">
            <img className={s.avatarCircle} src={data.avatar || avt} />
          </div>
          <div className="col-xs-9 col-md-9 col-md-9">
            <div className="row">
              <div className="col-xs-10">
                <div className="plan-label">
                  <label>
                    {data.username}
                  </label>
                </div>
              </div>
              <div className={cx(s.inlineFlex, s.btnGroup)}>
                <div
                  className="btn-group btn-group-xs"
                  role="group"
                  aria-label="..."
                >
                  {delBtn}
                  {editBtn}
                </div>
              </div>
            </div>
            <div className="row form-group">
              <div className={cx('col-xs-12 text-left')}>
                <div className={cx('text-left')}>
                  <Rater
                    className="react-rater notChoose"
                    rating={data.rating}
                    interactive={false}
                  />
                </div>
              </div>
            </div>
            <div className="row form-group">
              <div className="col-xs-12">
                <div className="">
                  {data.content}
                </div>
              </div>
            </div>
            <div className="row form-group">
              <div className="col-xs-12">
                {image}
              </div>
            </div>
            <div className="row">
              <div className="col-xs-6">
                <small>
                  {moment(data.date).format('YYYY/MM/DD')}
                </small>
              </div>
              {/*<div className="col-xs-3">
                    <button className="btn btn-primary btn-xs">Reply</button>
                  </div>*/}
            </div>
          </div>
        </div>
        {isReview ? '' : <hr />}
      </div>
    );
  }
}

// Rating.propTypes = {
//   rating: PropTypes.number.isRequired,
// };

const mapState = state => ({
  loading: state.comments.loading,
  user: state.user,
  dataTemp: state.comments.comment,
});

const mapDispatch = {
  commentPost,
  commentGet,
  commentTemp,
  clearComment,
};

export default connect(mapState, mapDispatch)(withStyles(s)(Comment));
