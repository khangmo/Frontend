import FacebookLogin from './FacebookLogin.js';

export { FacebookLogin };
