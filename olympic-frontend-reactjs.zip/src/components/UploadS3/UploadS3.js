/**
 * Created by KhangNT on 8/1/2017.
 */
import AWS from 'aws-sdk';
import React from 'react';
import PropTypes from 'prop-types';
import withStyles from 'isomorphic-style-loader/lib/withStyles';
import cx from 'classnames';
import { connect } from 'react-redux';
import uuidv4 from 'uuid/v4';

import uploadS3 from '../../actions/upload/upload';
import s from './UploadS3.css'; //eslint-disable-line

import Cognito from '../../lib/Cognito';
import config from '../../config';
import CameraIcon from 'react-icons/lib/fa/camera';

const cognito = new Cognito(config);

class UploadS3 extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      display: false,
      process: 0,
    };

    this.uploadS3 = this.uploadS3.bind(this);
    this.handSelectFile = this.handSelectFile.bind(this);
    this.setPercentComplete = this.setPercentComplete.bind(this);
    this.setStateDialog = this.setStateDialog.bind(this);
  }

  setPercentComplete(percent) {
    this.setState({
      display: this.state.display,
      process: Math.round(percent),
    });
  }

  setStateDialog(show) {
    this.setState({
      display: show,
      process: this.state.process,
    });
  }

  uploadS3 = (file, photoId, path, headers, callback) => {
    const s3 = new AWS.S3({
      params: {
        Bucket: config.aws.Bucket,
      },
    });
    const filename = `${path}/${photoId}.png`;
    const paramUpload = {
      Key: filename,
      Body: file,
      ContentType: file.type,
      ACL: 'public-read',
      headers,
    };

    try {
      cognito.getSession(headers['X-Auth-UserName']).then(() => {
        AWS.config.credentials.refresh(() =>
          s3
            .upload(paramUpload, (err, result) => callback(err, result))
            .on('httpUploadProgress', evt => {
              this.setPercentComplete(evt.loaded * 100 / evt.total);
            }),
        );
      });
    } catch (error) {
      bootbox.alert('Please login before!');
    }
  };

  handSelectFile = event => {
    event.preventDefault();
    const file = event.target.files[0];
    if (file) {
      const photoId = uuidv4();
      console.log(photoId);
      this.setStateDialog(true);
      this.props.uploadS3(
        this.uploadS3,
        file,
        photoId,
        this.props.s3Path,
        this.callback,
      );
    }
  };

  callback = (error, response) => {
    if (error) {
      console.log(JSON.stringify(error)); //eslint-disable-line
      this.props.onChange(error);
    } else if (
      response &&
      Object.prototype.hasOwnProperty.call(response, 'Location')
    ) {
      console.log(JSON.stringify(response.Location)); //eslint-disable-line
      this.props.onChange(response);
    }
    this.setStateDialog(false);
    this.setPercentComplete(0);
  };

  render() {
    return (
      <div className="upload-s3">
        <span className={s.btnFile}>
          <CameraIcon /> {this.props.title || ''}
          <input type="file" onChange={this.handSelectFile} />
        </span>
        {/* Dialog processing upload */}
        {this.state.display
          ? <div className="view-dialog-processing">
              <div
                className="modal modal-static in"
                aria-hidden="true"
                role="dialog"
                id="pleaseWaitDialog"
                data-backdrop="static"
                data-keyboard="false"
                style={{ display: 'block', paddingRight: '17px' }}
              >
                <div
                  className="modal-dialog"
                  style={{
                    marginTop: '20%',
                    borderRadius: '5px',
                    padding: '10px',
                  }}
                >
                  <div
                    className="progress"
                    style={{
                      marginRight: '20%',
                      marginLeft: '20%',
                      padding: '30px 20px',
                    }}
                  >
                    <div
                      className="progress-bar progress-bar-striped active"
                      role="progressbar"
                      aria-valuenow={this.state.process}
                      aria-valuemin="0"
                      aria-valuemax="100"
                      style={{
                        width: `${this.state.process}%`,
                        height: '20px',
                        borderRadius: '4px',
                        marginTop: '-10px',
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className="modal-backdrop in" />
            </div>
          : <div style={{ display: 'none' }} />}
      </div>
    );
  }
}

UploadS3.propTypes = {
  user: PropTypes.object, // eslint-disable-line
  loading: PropTypes.bool, // eslint-disable-line
  s3Path: PropTypes.string,
  uploadS3: PropTypes.func,
};

const mapState = state => ({
  loading: state.places.loading,
  user: state.user,
});

const mapDispatch = {
  uploadS3,
};

export default connect(mapState, mapDispatch)(withStyles(s)(UploadS3));
