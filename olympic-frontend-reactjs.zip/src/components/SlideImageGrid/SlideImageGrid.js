/*
  eg: images slide
  const images = [
    'https://unsplash.it/1300/800?image=875',
    'https://unsplash.it/1300/800?image=874',
    'https://unsplash.it/1300/800?image=872',
    'https://unsplash.it/1300/800?image=868',
    'https://unsplash.it/1300/800?image=839',
    'https://unsplash.it/1300/800?image=838',
    'https://unsplash.it/1300/800?image=868',
    'https://unsplash.it/1300/800?image=839',
    'https://unsplash.it/1300/800?image=838',
  ];
  <SlideImageGrid id={'gallery'} images={images}/>
  id: can is null (not props)
*/

import React from 'react';

class SlideImageGrid extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    const { images } = this.props;
    let targetId = Math.random()
      .toString(36)
      .replace(/[^a-z]+/g, '')
      .substr(0, 11);

    if (this.props.id) {
      targetId = this.props.id;
    }

    $(function() {
      $('#' + targetId).imagesGrid({
        images: images,
      });
    });
    return <div id={targetId} />;
  }
}

export default SlideImageGrid;
