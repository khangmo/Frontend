/**
 * JPA domain objects.
 */
package com.lawer.domain;
