/**
 * View Models used by Spring MVC REST controllers.
 */
package com.lawer.web.rest.vm;
