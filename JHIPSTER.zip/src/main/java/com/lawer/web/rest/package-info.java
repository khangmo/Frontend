/**
 * Spring MVC REST controllers.
 */
package com.lawer.web.rest;
