/**
 * Spring Data JPA repositories.
 */
package com.lawer.repository;
