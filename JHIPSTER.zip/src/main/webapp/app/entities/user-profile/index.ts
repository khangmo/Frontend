export * from './user-profile.service';
export * from './user-profile-update.component';
export * from './user-profile-delete-dialog.component';
export * from './user-profile-detail.component';
export * from './user-profile.component';
export * from './user-profile.route';
