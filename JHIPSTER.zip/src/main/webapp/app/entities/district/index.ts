export * from './district.service';
export * from './district-update.component';
export * from './district-delete-dialog.component';
export * from './district-detail.component';
export * from './district.component';
export * from './district.route';
